import java.awt.Point;
import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;



public class SensorLoader {

	public static void fillOfficesWithDesktopThings(String filePath) {
		
		try{
			File xmlFile = new File(filePath);
			DocumentBuilderFactory documentBuilderFactorySensors = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilderSensors = documentBuilderFactorySensors.newDocumentBuilder();
			Document documentSensors = documentBuilderSensors.parse(xmlFile);
			
			NodeList sensorsList = documentSensors.getElementsByTagName("sensors");
			Node sensorsNode = sensorsList.item(0);
			Element sensorsElem = (Element) sensorsNode;
						
			NodeList sensorList = sensorsElem.getElementsByTagName("sensor");
			
			
			//System.out.println("Number of Sensors: " + sensorList.getLength());
			for (int sensorIndx = 0; sensorIndx < sensorList.getLength(); ++sensorIndx)
			{
				Node sensor = sensorList.item(sensorIndx);
				Element sensorElem = (Element) sensor;
				
				String[] pointArr = sensorElem.getElementsByTagName("point").item(0).getTextContent().trim().split(" ");
				
				String sensorType = sensorElem.getElementsByTagName("type").item(0).getTextContent().trim();
				int sensrorRadius = Integer.parseInt(sensorElem.getElementsByTagName("radius").item(0).getTextContent().trim());
				String sensorID = sensorElem.getElementsByTagName("id").item(0).getTextContent().trim();
				
				System.out.println("Point Coordinates-> x: " + pointArr[0] + "\ty: " + pointArr[1]);
				System.out.println("Sensdor Type: " + sensorType);
				System.out.println("Sensdor ID: " + sensorID);
				System.out.println("Sensdor Radius: " + sensrorRadius);
				System.out.println("----------------------------------------------------");
			}
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();}
	}
}
