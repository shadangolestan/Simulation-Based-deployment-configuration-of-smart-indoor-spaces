package sensors;

import java.awt.geom.Point2D;
import java.util.HashMap;
import java.util.Hashtable;

import de.uniluebeck.imis.casi.CASi;
import de.uniluebeck.imis.casi.communication.comLogger.MQTTEventLogger;
import de.uniluebeck.imis.casi.communication.mack.MACKProtocolFactory;
import de.uniluebeck.imis.casi.simulation.engine.SimulationClock;
import de.uniluebeck.imis.casi.simulation.engine.SimulationEngine;
import de.uniluebeck.imis.casi.simulation.model.AbstractInteractionComponent;
import de.uniluebeck.imis.casi.simulation.model.Agent;
import de.uniluebeck.imis.casi.simulation.model.actionHandling.AbstractAction;
import objectInterfaces.Pressurable;


public class PressureSensorBinary extends Pressurable {

	Hashtable <Point2D, Double> pressureLocations_now = new Hashtable<Point2D, Double>();
	Hashtable <Point2D, Double> pressureLocations_old = new Hashtable<Point2D, Double>();
	
	
	/** serialization identifier */
	private static final long serialVersionUID = 8750391465421352206L;

	
	

	public PressureSensorBinary(String identifier, Point2D coordinates, int radius) {
		super(identifier, coordinates);
		
		this.radius = radius;
		type = Type.SENSOR;
		pressureLocations_now = new Hashtable<Point2D, Double>();
		pressureLocations_old = new Hashtable<Point2D, Double>();
	}

	
	@Override
	protected boolean handleInternal(AbstractAction action, Agent agent) {
		return false;
	}

	@Override
	public String getHumanReadableValue() {
		return null;//"P: " + currentProgram + ", F: " + currentFrequency;
	}

	/*
	private void send() {
		HashMap<String, String> values = new HashMap<String, String>();
		values.put("Heted", "heated++");
	//	String message = MACKProtocolFactory.generatePushMessage(agent, "daa",values);
		SimulationEngine.getInstance().getCommunicationHandler().send(this, "Heated");
	}
	*/

	@Override
	public String getType() {
		return "PressureSensorBinary";
	}


	@Override
	public void logSensorValue() {
		// TODO Auto-generated method stub
		if (pressureLocations_now.size() > 0){ //CASi.SIM_LOG.info(this.identifier + "\tTRUE");
			//Format--> <deployment name>/sensor_readings/<node id>/<sensor id> <unix timestamp>,<boolean value>,<raw value>
			CASi.SIM_LOG.info("casiSimulator/sensor_readings/" + this.getType() + "/" + this.getIdentifier() + 
					" " + SimulationClock.getInstance().getCurrentTime().getTime() + ",TRUE,TRUE");
		MQTTEventLogger.getInstance().publishMQTT("casiSimulator/sensor_readings/" + this.getType() + "/" + this.getIdentifier()
		, SimulationClock.getInstance().getCurrentTime().getTime() + ",TRUE,TRUE"  );}
	}


	@Override
	public void resetAggregatePressure() {
		// TODO Auto-generated method stub
		pressureLocations_old = pressureLocations_now;
		pressureLocations_now = new Hashtable<Point2D, Double>();
	}


	@Override
	public void setPressureAtPoint(Point2D point, double pressure) {
		// TODO Auto-generated method stub
		// check if the point had been already added to the heat-map
		pressureLocations_now.put(point, pressure);
	}


	@Override
	public Double getPressureAtPoint(Point2D point) {
		// TODO Auto-generated method stub
		return pressureLocations_now.get(point);
	}


	@Override
	public void sensePressure(Point2D point, double pressure) {
		// TODO Auto-generated method stub
		Double registered_pressure = pressureLocations_now.get(point);
		
		if (registered_pressure == null) pressureLocations_now.put(point, pressure);
		else pressureLocations_now.put(point, new Double(pressure + registered_pressure));

	}


	@Override
	public void turnOnFunctionality() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void turnOffFunctionality() {
		// TODO Auto-generated method stub
		
	}


}
