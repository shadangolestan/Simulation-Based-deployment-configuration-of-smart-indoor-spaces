package sensors;

import java.awt.geom.Point2D;
import java.util.Hashtable;

import de.uniluebeck.imis.casi.CASi;
import de.uniluebeck.imis.casi.simulation.model.AbstractInteractionComponent;
import de.uniluebeck.imis.casi.simulation.model.Agent;
import de.uniluebeck.imis.casi.simulation.model.actionHandling.AbstractAction;

public class ElectricityUsageSensor {//extends  Electrical {
	
	public ElectricityUsageSensor(String identifier, Point2D point, Double usage) {
	//	super(identifier, point, usage);
		// TODO Auto-generated constructor stub
	}
	Hashtable <String, Double> functionConsumption;
	Hashtable <String, Boolean> functionOn;
	double currentTotalEnergyConsumption;
/*
	public ElectricityUsageSensor(String identifier, Point2D point) {
		super(identifier, point);
		// TODO Auto-generated constructor stub
		
		functionConsumption = new Hashtable <String, Double>();
		functionOn = new Hashtable <String, Boolean>();
	
		currentTotalEnergyConsumption = 0;
	}

	@Override
	public void turnOnFunctionality(String functionName) {
		// TODO Auto-generated method stub
		functionName = functionName.toUpperCase();
		if ((functionConsumption.get(functionName) != null) && (!functionOn.get(functionName))) {
			functionOn.put(functionName, new Boolean(true));
			currentTotalEnergyConsumption += functionConsumption.get(functionName);
		}
	}

	
	@Override
	public void turnOffFunctionality(String functionName) {
		// TODO Auto-generated method stub
		functionName = functionName.toUpperCase();
		if ((functionConsumption.get(functionName) != null) && (functionOn.get(functionName))) {
			functionOn.put(functionName, new Boolean(true));
			currentTotalEnergyConsumption -= functionConsumption.get(functionName);
		}
	}

	
	@Override
	public Double getElectricalUsage() {
		// TODO Auto-generated method stub
		return currentTotalEnergyConsumption;
	}

	@Override
	public void logSensorValue() {
		// TODO Auto-generated method stub
		CASi.SIM_LOG.info(this.identifier + "\t" + currentTotalEnergyConsumption);
	}

	@Override
	protected boolean handleInternal(AbstractAction action, Agent agent) {
		// TODO Auto-generated method stub
		return false;
	}
	
	public void addFunctionality(String functionality, Double consumption)
	{
		functionality = functionality.toUpperCase();
		// check if the functionality 
		if (functionConsumption.put(functionality, consumption) != null){
			functionConsumption.put(functionality, new Double(consumption));
			functionOn.put(functionality, new Boolean(false));
		}
	}

	@Override
	public void turnOnFunctionality() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void turnOffFunctionality() {
		// TODO Auto-generated method stub
		
	}
*/
	/*
	@Override
	public void turnOnFunctionality() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void turnOffFunctionality() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public Double getWaterUsage() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void logSensorValue() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public Double getCurrentUsage() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void setUsage(Double usage) {
		// TODO Auto-generated method stub
		
	}
	@Override
	protected boolean handleInternal(AbstractAction action, Agent agent) {
		// TODO Auto-generated method stub
		return false;
	}
	*/
}
