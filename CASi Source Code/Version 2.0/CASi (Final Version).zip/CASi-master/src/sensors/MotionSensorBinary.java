package sensors;

import java.awt.geom.Point2D;
import java.util.HashMap;
import java.util.Hashtable;

import de.uniluebeck.imis.casi.CASi;
import de.uniluebeck.imis.casi.communication.comLogger.MQTTEventLogger;
import de.uniluebeck.imis.casi.communication.mack.MACKProtocolFactory;
import de.uniluebeck.imis.casi.simulation.engine.SimulationClock;
import de.uniluebeck.imis.casi.simulation.engine.SimulationEngine;
import de.uniluebeck.imis.casi.simulation.model.AbstractInteractionComponent;
import de.uniluebeck.imis.casi.simulation.model.Agent;
import de.uniluebeck.imis.casi.simulation.model.actionHandling.AbstractAction;
import objectInterfaces.Heatable;


public class MotionSensorBinary extends Heatable {

	Hashtable <Point2D, Double> heatLocations_now = new Hashtable<Point2D, Double>();
	Hashtable <Point2D, Double> heatLocations_old = new Hashtable<Point2D, Double>();
	
	
	/** serialization identifier */
	private static final long serialVersionUID = 8750391465421352206L;

	
	

	public MotionSensorBinary(String identifier, Point2D coordinates, int radius) {
		super(identifier, coordinates);
		
		this.radius = radius;
		type = Type.SENSOR;
		heatLocations_now = new Hashtable<Point2D, Double>();
		heatLocations_old = new Hashtable<Point2D, Double>();
	}

	
	@Override
	protected boolean handleInternal(AbstractAction action, Agent agent) {
		return false;
	}

	@Override
	public String getHumanReadableValue() {
		return null;//"P: " + currentProgram + ", F: " + currentFrequency;
	}

	/*
	private void send() {
		HashMap<String, String> values = new HashMap<String, String>();
		values.put("Heted", "heated++");
	//	String message = MACKProtocolFactory.generatePushMessage(agent, "daa",values);
		SimulationEngine.getInstance().getCommunicationHandler().send(this, "Heated");
	}
	*/

	@Override
	public String getType() {
		return "MotionSensorBinary";
	}


	@Override
	public void logSensorValue() {
		// TODO Auto-generated method stub
		if (heatLocations_now.size() > 0) {
			//CASi.SIM_LOG.info(this.identifier + "\tTRUE");
			//Format--> <deployment name>/sensor_readings/<node id>/<sensor id> <unix timestamp>,<boolean value>,<raw value>
			CASi.SIM_LOG.info("casiSimulator/sensor_readings/" + this.getType() + "/" + this.getIdentifier() + 
					" " + SimulationClock.getInstance().getCurrentTime().getTime() + ",TRUE,TRUE" );
					//+ " " + performer.getIdentifier() + " " + this.getClass().getSimpleName() + " START");
		MQTTEventLogger.getInstance().publishMQTT("casiSimulator/sensor_readings/" + this.getType() + "/" + this.getIdentifier()
		, SimulationClock.getInstance().getCurrentTime().getTime() + ",TRUE,TRUE" + heatLocations_now.size());
		}
	}


	@Override
	public void resetAggregateTemperature() {
		// TODO Auto-generated method stub
		heatLocations_old = heatLocations_now;
		heatLocations_now = new Hashtable<Point2D, Double>();
	}


	@Override
	public void setTemperatureAtPoint(Point2D point, double temperature) {
		// TODO Auto-generated method stub
		// check if the point had been already added to the heat-map
		heatLocations_now.put(point, temperature);
	}


	@Override
	public Double getTemperatureAtPoint(Point2D point) {
		// TODO Auto-generated method stub
		return heatLocations_now.get(point);
	}


	@Override
	public void senseTemperature(Point2D point, double temperature) {
		// TODO Auto-generated method stub
		Double registered_temperature = heatLocations_now.get(point);
		
		if (registered_temperature == null) heatLocations_now.put(point, temperature);
		else if (temperature > registered_temperature) {
			heatLocations_now.put(point, new Double(temperature));
		}
		// check if the already sensed heat
	}


	@Override
	public void turnOnFunctionality() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void turnOffFunctionality() {
		// TODO Auto-generated method stub
		
	}


}
