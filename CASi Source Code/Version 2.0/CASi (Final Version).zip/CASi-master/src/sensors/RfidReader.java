/*  	CASi Context Awareness Simulation Software
 *   Copyright (C) 2011 2012  Moritz Bürger, Marvin Frick, Tobias Mende
 *
 *  This program is free software. It is licensed under the
 *  GNU Lesser General Public License with one clarification.
 *  
 *  You should have received a copy of the 
 *  GNU Lesser General Public License along with this program. 
 *  See the LICENSE.txt file in this projects root folder or visit
 *  <http://www.gnu.org/licenses/lgpl.html> for more details.
 */
package sensors;

import java.awt.Point;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Set;
import java.util.logging.Logger;

import de.uniluebeck.imis.casi.CASi;
import de.uniluebeck.imis.casi.communication.comLogger.MQTTEventLogger;
import de.uniluebeck.imis.casi.generator.AgentCollector;
import de.uniluebeck.imis.casi.simulation.engine.SimulationClock;

import de.uniluebeck.imis.casi.simulation.model.AbstractInteractionComponent;
import de.uniluebeck.imis.casi.simulation.model.Agent;
import de.uniluebeck.imis.casi.simulation.model.actionHandling.AbstractAction;
import de.uniluebeck.imis.casi.simulations.mate.generator.java.Agents;
import objectInterfaces.Heatable;
import objectInterfaces.Wearable;


public class RfidReader extends Wearable {
	

	private static final Logger log = Logger.getLogger(RfidReader.class
			.getName());



	// (Integer direction, int radius, int opening)
	public RfidReader(String id, Point point, int direction, int radius, int opening) {
		super("RFID_Reader-" + id, point);
		SimulationClock.getInstance().addListener(this);
//		interestingActions.add(Move.class);
//		setShapeRepresentation(door.getShapeRepresentation());
		// (Integer direction, int radius, int opening)
		//this.setMonitoredArea(90, 60, 90);
		this.setMonitoredArea(direction, radius, opening);
		
	}




	@Override
	protected boolean handleInternal(AbstractAction action, Agent agent) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void logSensorValue() {
		ArrayList<Agent> agents = this.getAgents();
		
		if (agents != null){
			System.out.println("Num Agents: " + agents.size());
			
			for (int i = 0; i < agents.size(); ++i){
				CASi.SIM_LOG.info("casiSimulator/sensor_readings/" + this.getType() + "/" + this.getIdentifier() + 
						" " + SimulationClock.getInstance().getCurrentTime().getTime() + ",TRUE," + agents.get(i) );
				
				MQTTEventLogger.getInstance().publishMQTT("casiSimulator/sensor_readings/" + this.getType() + "/" + this.getIdentifier()
					, SimulationClock.getInstance().getCurrentTime().getTime() + ",TRUE," + agents.get(i));
				
		//		System.exit(1);
			}
		}

		
	}



	@Override
	public void addDetectedAgent(Agent newAgent) {
		// TODO Auto-generated method stub
		ArrayList<Agent> agents = this.getAgents();
		
		agents.add(newAgent);
	}

	public String getType(){return "RfidReader";}



	@Override
	public void removeAgent(Agent agentToRemove) {
		// TODO Auto-generated method stub
		ArrayList<Agent> agents = this.getAgents();
		agents.remove(agentToRemove);
	}




	@Override
	public void removeAllAgents() {
		// TODO Auto-generated method stub
		ArrayList<Agent> agents = this.getAgents();
		agents = new ArrayList<Agent>();
	}




	@Override
	public void turnOnFunctionality() {
		// TODO Auto-generated method stub
		
	}




	@Override
	public void turnOffFunctionality() {
		// TODO Auto-generated method stub
		
	}





}
