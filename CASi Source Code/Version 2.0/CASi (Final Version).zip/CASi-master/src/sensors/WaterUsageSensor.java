package sensors;

import java.awt.geom.Point2D;
import java.util.Hashtable;

import de.uniluebeck.imis.casi.CASi;
import de.uniluebeck.imis.casi.simulation.model.AbstractInteractionComponent;
import de.uniluebeck.imis.casi.simulation.model.Agent;
import de.uniluebeck.imis.casi.simulation.model.actionHandling.AbstractAction;

public class WaterUsageSensor {// extends AbstractInteractionComponent {

	public WaterUsageSensor(Agent agent) {
		//super(agent);
		// TODO Auto-generated constructor stub
	}//implements WaterUsable {
	/*
	Hashtable <String, Double> functionConsumption;
	Hashtable <String, Boolean> functionOn;
	double currentTotalWaterConsumption;

	public WaterUsageSensor(String identifier, Point2D point) {
		super(identifier, point);
		// TODO Auto-generated constructor stub
		
		functionConsumption = new Hashtable <String, Double>();
		functionOn = new Hashtable <String, Boolean>();
	
		currentTotalWaterConsumption = 0;
	}

	@Override
	public void turnOnFunctionality(String functionName) {
		// TODO Auto-generated method stub
		functionName = functionName.toUpperCase();
		if ((functionConsumption.get(functionName) != null) && (!functionOn.get(functionName))) {
			functionOn.put(functionName, new Boolean(true));
			currentTotalWaterConsumption += functionConsumption.get(functionName);
		}
	}

	
	@Override
	public void turnOffFunctionality(String functionName) {
		// TODO Auto-generated method stub
		functionName = functionName.toUpperCase();
		if ((functionConsumption.get(functionName) != null) && (functionOn.get(functionName))) {
			functionOn.put(functionName, new Boolean(true));
			currentTotalWaterConsumption -= functionConsumption.get(functionName);
		}
	}

	
	@Override
	public Double getWaterUsage() {
		// TODO Auto-generated method stub
		return currentTotalWaterConsumption;
	}

	@Override
	public void logSensorValue() {
		// TODO Auto-generated method stub
		CASi.SIM_LOG.info(this.identifier + "\t" + currentTotalWaterConsumption);
	}

	@Override
	protected boolean handleInternal(AbstractAction action, Agent agent) {
		// TODO Auto-generated method stub
		return false;
	}
	
	public void addFunctionality(String functionality, Double consumption)
	{
		functionality = functionality.toUpperCase();
		// check if the functionality 
		if (functionConsumption.put(functionality, consumption) != null){
			functionConsumption.put(functionality, new Double(consumption));
			functionOn.put(functionality, new Boolean(false));
		}
	}
	*/
/*
	@Override
	protected boolean handleInternal(AbstractAction action, Agent agent) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void turnOnFunctionality() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void turnOffFunctionality() {
		// TODO Auto-generated method stub
		
	}
	*/
}
