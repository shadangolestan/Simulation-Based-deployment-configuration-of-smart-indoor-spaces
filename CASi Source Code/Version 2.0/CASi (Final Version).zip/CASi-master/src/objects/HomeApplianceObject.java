/*  	CASi Context Awareness Simulation Software
* Author: 		Alexandr Petcovici
* Date: 		10-December-2016
* Description:  This class is represents home apliences object
*/
package objects;

import java.awt.geom.Point2D;

import de.uniluebeck.imis.casi.simulation.model.Agent;
import de.uniluebeck.imis.casi.simulation.model.actionHandling.AbstractAction;
import objectInterfaces.HomeAppliance;

public class HomeApplianceObject extends HomeAppliance{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public HomeApplianceObject(String identifier, Point2D point, Double waterUsage, Double electricityUsage) {
		super(identifier, point, waterUsage, electricityUsage);
		//System.out.println("identifier: " + identifier);
		//System.out.println("point: " + point);
		//System.out.println("waterUsage: " + waterUsage);
		//System.out.println("electricityUsage: " + electricityUsage);
		//System.out.println("");
	//	System.exit(1);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected boolean handleInternal(AbstractAction action, Agent agent) {
		// TODO Auto-generated method stub
		return false;
	}

}
