package objectInterfaces;

import java.awt.geom.Point2D;

import de.uniluebeck.imis.casi.CASi;
import de.uniluebeck.imis.casi.communication.comLogger.MQTTEventLogger;
import de.uniluebeck.imis.casi.simulation.engine.SimulationClock;
import de.uniluebeck.imis.casi.simulation.model.AbstractInteractionComponent;

public abstract class HomeAppliance extends AbstractInteractionComponent {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/*
	 * public Electrical(String identifier, Point2D point) { super(identifier,
	 * point); // TODO Auto-generated constructor stub }
	 */

	protected Double waterUsage, electricityUsage;
	protected boolean usesWater, usesElectricity;

	
	public enum State {
		ON,
		OFF
	}

	State state;
	
	public HomeAppliance(String identifier, Point2D point, Double waterUsage, Double electricityUsage) {
		super(identifier, point);
		// TODO Auto-generated constructor stub
		this.waterUsage = waterUsage;
		usesWater = false;
		if (waterUsage != 0) usesWater = true; 
		
		this.electricityUsage = electricityUsage;
		usesElectricity = false;
		if (electricityUsage != 0) usesElectricity = true;
		
		state = State.OFF;
	}
	
	
	
	
	public void turnOnFunctionality(){
		// TODO Auto-generated method stub
		state = State.ON;
		//System.out.println("\t\t-->Turned On");
		CASi.SIM_LOG.info("casiSimulator/sensor_readings/" + this.getType() + "/" + this.getIdentifier() + 
				" " + SimulationClock.getInstance().getCurrentTime().getTime() + ",TRUE,ON" );
				//+ " " + performer.getIdentifier() + " " + this.getClass().getSimpleName() + " START");
		MQTTEventLogger.getInstance().publishMQTT("casiSimulator/sensor_readings/" + this.getType() + "/" + this.getIdentifier()
			, SimulationClock.getInstance().getCurrentTime().getTime() + ",TRUE,ON");
	}

	public void turnOffFunctionality(){
		// TODO Auto-generated method stub
		state = State.OFF;
		CASi.SIM_LOG.info("casiSimulator/sensor_readings/" + this.getType() + "/" + this.getIdentifier() + 
				" " + SimulationClock.getInstance().getCurrentTime().getTime() + ",TRUE,OFF" );
				//+ " " + performer.getIdentifier() + " " + this.getClass().getSimpleName() + " START");
		MQTTEventLogger.getInstance().publishMQTT("casiSimulator/sensor_readings/" + this.getType() + "/" + this.getIdentifier()
			, SimulationClock.getInstance().getCurrentTime().getTime() + ",TRUE,OFF");
	}
	
	public Double getWaterUsage(){return this.waterUsage;}
	
	
	public void logWaterUsage(){
		if (this.state == state.ON && getCurrentWaterUsage() > 0)
		{
			CASi.SIM_LOG.info("casiSimulator/sensor_readings/" + this.getType() + "/" + this.getIdentifier() + 
					" " + SimulationClock.getInstance().getCurrentTime().getTime() + "," + this.state + "," + (this.getCurrentWaterUsage())/ 3600 + ",L/s");
			
			MQTTEventLogger.getInstance().publishMQTT("casiSimulator/sensor_readings/" + this.getType() + "/" + this.getIdentifier()
			, SimulationClock.getInstance().getCurrentTime().getTime() + "," + this.state + "," + (this.getCurrentWaterUsage()/ 3600) + ",L/s" );
		}
	}
	
	public Double getCurrentWaterUsage(){
		if (this.state.equals(State.ON)){
			return this.waterUsage;
		}
		return (new Double(0));
	}
	
	public void setWaterUsage(Double usage){this.waterUsage = usage;}
	

	public Double getElectricityUsage(){return this.electricityUsage;}
	
	public void logElectricityUsage(){
		if (this.state == state.ON && getCurrentElectricityUsage() > 0){
			CASi.SIM_LOG.info("casiSimulator/sensor_readings/" + this.getType() + "/" + this.getIdentifier() + 
					" " + SimulationClock.getInstance().getCurrentTime().getTime() + "," + this.state + "," + (getCurrentElectricityUsage() / 3600) + ",kW");
		
			MQTTEventLogger.getInstance().publishMQTT("casiSimulator/sensor_readings/" + this.getType() + "/" + this.getIdentifier()
			, SimulationClock.getInstance().getCurrentTime().getTime() + "," + this.state + "," + (getCurrentElectricityUsage() / 3600) + ",kW");
		}
	}
	
	public Double getCurrentElectricityUsage(){
		if (this.state.equals(State.ON)){
			return this.electricityUsage;
		}
		return (new Double(0));
	}
	
	public void setElectricityUsage(Double usage){this.electricityUsage = usage;}
}