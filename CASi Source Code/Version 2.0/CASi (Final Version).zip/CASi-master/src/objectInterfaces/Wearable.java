package objectInterfaces;

import java.awt.geom.Point2D;
import java.util.ArrayList;

import de.uniluebeck.imis.casi.simulation.model.AbstractInteractionComponent;
import de.uniluebeck.imis.casi.simulation.model.Agent;


public abstract  class Wearable extends AbstractInteractionComponent
	{
	
	private ArrayList<Agent> detectedAgents;
	
	public Wearable(String identifier, Point2D point) {
		super(identifier, point);
		
		detectedAgents = new ArrayList<Agent>();
	}

	abstract public void addDetectedAgent(Agent newAgent);

	abstract public void removeAgent(Agent agentToRemove);
	
	abstract public void removeAllAgents();
	
	abstract public void logSensorValue();
	
	public ArrayList<Agent> getAgents() {return detectedAgents;}
	
	
}
