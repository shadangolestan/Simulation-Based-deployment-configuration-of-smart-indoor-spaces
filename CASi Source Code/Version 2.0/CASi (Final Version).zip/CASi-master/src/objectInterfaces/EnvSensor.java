package objectInterfaces;

import java.awt.geom.Point2D;

import de.uniluebeck.imis.casi.simulation.model.AbstractInteractionComponent;

public abstract class EnvSensor extends AbstractInteractionComponent {

	public EnvSensor(String identifier, Point2D coordinates) {
		super(identifier, coordinates);
		// TODO Auto-generated constructor stub
	}

}
