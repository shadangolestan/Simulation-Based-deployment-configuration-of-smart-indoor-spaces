package objectInterfaces;

import java.awt.geom.Point2D;

import de.uniluebeck.imis.casi.simulation.model.AbstractInteractionComponent;

public abstract  class Pressurable extends EnvSensor{
	public Pressurable(String identifier, Point2D point) {
		super(identifier, point);
		// TODO Auto-generated constructor stub
	}

	abstract public void setPressureAtPoint(Point2D point, double pressure);

	abstract public Double getPressureAtPoint(Point2D point);
	
	abstract public void sensePressure(Point2D point, double pressure);
	
	abstract public void logSensorValue();
	
	abstract public void resetAggregatePressure();
}
