/**
 * 
 */
/**
 * @author Alex
 *
 */
package objectInterfaces;