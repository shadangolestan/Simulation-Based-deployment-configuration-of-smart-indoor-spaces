package objectInterfaces;

import java.awt.geom.Point2D;
import de.uniluebeck.imis.casi.simulation.model.AbstractInteractionComponent;


public abstract  class Heatable extends EnvSensor
	{
	
	public Heatable(String identifier, Point2D point) {
		super(identifier, point);
		// TODO Auto-generated constructor stub
	}

	abstract public void setTemperatureAtPoint(Point2D point, double temperature);

	abstract public Double getTemperatureAtPoint(Point2D point);
	
	abstract public void senseTemperature(Point2D point, double temperature);
	
	abstract public void logSensorValue();
	
	abstract public void resetAggregateTemperature();
}
