/**
 * This package contains the implementation of the external communication interface for communicating with the MACK framework
 */
package de.uniluebeck.imis.casi.communication.mack;

