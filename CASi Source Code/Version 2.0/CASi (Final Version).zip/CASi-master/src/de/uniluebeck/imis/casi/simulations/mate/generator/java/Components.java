/*  	CASi Context Awareness Simulation Software
 *   Copyright (C) 2012 2012  Moritz Bürger, Marvin Frick, Tobias Mende
 *
 *  This program is free software. It is licensed under the
 *  GNU Lesser General Public License with one clarification.
 *  
 *  You should have received a copy of the 
 *  GNU Lesser General Public License along with this program. 
 *  See the LICENSE.txt file in this projects root folder or visit
 *  <http://www.gnu.org/licenses/lgpl.html> for more details.
 *  
 *  
 *  ==================================================================
 *  Changed By: 		Alexandr Petcovici
 *  Date:				26-Aug-2016
 *  Description:		Read simulationWorld.xml and creates components 
 *  					based on it content
 *  ==================================================================
 */
package de.uniluebeck.imis.casi.simulations.mate.generator.java;

import java.awt.Point;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import de.uniluebeck.imis.casi.generator.ComponentCollector;
import de.uniluebeck.imis.casi.generator.RoomCollector;
import de.uniluebeck.imis.casi.simulation.model.AbstractInteractionComponent;
import de.uniluebeck.imis.casi.simulation.model.Agent;
import de.uniluebeck.imis.casi.simulation.model.mackComponents.DoorSensor;
import objects.HomeApplianceObject;
import sensors.MotionSensorAnalog;
import sensors.MotionSensorBinary;
import sensors.PressureSensorAnalog;
import sensors.RfidReader;

/**
 * Fills the ComponentCollector with Components. Both Actuators and Sensors.
 * 
 * Put all your Components here!
 * 
 * @author Marvin Frick
 * 
 */
public class Components {

	/**
	 * Fills the ComponentCollector with actuators.
	 * 
	 * Put all your actuators here!
	 */
	public static void generateActuators() {
		// all these things are created directly for their users in the specific
		// methods.
	}

	/**
	 * Fills the ComponentCollector with sensors.
	 * 
	 * Put all your sensors here!
	 */
	public static void generateSensors() {
		// all these things are created directly for their users in the specific
		// methods.
	}

	/**
	 * Fills all offices with a Desktop, a Cube and a Mike. Watch out that the
	 * Agents have their offices (a Room) as defaultPosition
	 */
	public static void fillOfficesWithDesktopThings() {
		ComponentCollector c = ComponentCollector.getInstance();
		RoomCollector rooms = RoomCollector.getInstance();

		try {
			File xmlFile = new File("simulationWorld.xml");
			DocumentBuilderFactory documentBuilderFactorySensors = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilderSensors = documentBuilderFactorySensors.newDocumentBuilder();
			Document documentSensors = documentBuilderSensors.parse(xmlFile);
			
			NodeList sensorsList = documentSensors.getElementsByTagName("sensors");
			Node sensorsNode = sensorsList.item(0);
			Element sensorsElem = (Element) sensorsNode;
			
			
			NodeList sensorList = sensorsElem.getElementsByTagName("sensor");
			
			
			for (int sensorIndx = 0; sensorIndx < sensorList.getLength(); ++sensorIndx)
			{
				Node sensor = sensorList.item(sensorIndx);
				Element sensorElem = (Element) sensor;
				
				Element pointElement = (Element)sensorElem.getElementsByTagName("point").item(0);
				Integer xCoord = Integer.parseInt(pointElement.getElementsByTagName("xcoord").item(0).getTextContent().trim());
				Integer yCoord = Integer.parseInt(pointElement.getElementsByTagName("ycoord").item(0).getTextContent().trim());
			
				Point point = new Point(xCoord, yCoord);
				
				String sensorType = sensorElem.getElementsByTagName("type").item(0).getTextContent().trim();
				String sensorID = sensorElem.getElementsByTagName("id").item(0).getTextContent().trim();
				
				int sensrorRadius = 0;
				String sensorDirection = "0";
				String sensorArcSize = "0";
				String sensorRayLength = "0";
				double consumptionWater = 0;
				double consumptionElectricity = 0;
				
				try{sensrorRadius = Integer.parseInt(sensorElem.getElementsByTagName("radius").item(0).getTextContent().trim());} catch (Exception e){}
				
				
				try{sensorDirection = sensorElem.getElementsByTagName("direction").item(0).getTextContent().trim();} catch (Exception e){};
				try{sensorArcSize = sensorElem.getElementsByTagName("arcSize").item(0).getTextContent().trim();} catch (Exception e){};
				try{sensorRayLength = sensorElem.getElementsByTagName("rayLength").item(0).getTextContent().trim();} catch (Exception e){};
				try{sensorRayLength = sensorElem.getElementsByTagName("rayLength").item(0).getTextContent().trim();} catch (Exception e){};
				try{consumptionWater = Double.parseDouble(sensorElem.getElementsByTagName("consumptionWater").item(0).getTextContent().trim());} catch (Exception e){};
				try{consumptionElectricity = Double.parseDouble(sensorElem.getElementsByTagName("consumptionElectricity").item(0).getTextContent().trim());} catch (Exception e){};
				
				
				if (sensorType.equals("MotionSensorBinary"))
					c.newComponent(new MotionSensorBinary(sensorID, point, sensrorRadius), "HEATABLE");
				else if (sensorType.equals("MotionSensorAnalog"))
					c.newComponent(new MotionSensorAnalog(sensorID, point, sensrorRadius), "HEATABLE");
				else if (sensorType.equals("PressureSensorAnalog"))
					c.newComponent(new PressureSensorAnalog(sensorID, point, sensrorRadius), "PRESSURABLE");
				else if (sensorType.equals("MotionSensorBinary"))
					c.newComponent(new MotionSensorBinary(sensorID, point, sensrorRadius), "PRESSURABLE");
				else if (sensorType.equals("RFID_Reader")){
					c.newComponent(new RfidReader(sensorID, point, Integer.parseInt(sensorDirection), 
							Integer.parseInt(sensorRayLength), 
							Integer.parseInt(sensorArcSize)), "WEARABLE");
				}
				else {
					c.newComponent(new HomeApplianceObject(sensorID, point, consumptionWater, consumptionElectricity), "HOME_APPLIENCE");
				}

			}

		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

	/**
	 * Adds things to given room with a given owner. Used for doorSensors and
	 * DoorLights...
	 * 
	 */
	
	public static void addLightsAndSensorsToDoors() {
		/*
		ComponentCollector cc = ComponentCollector.getInstance();
		AgentCollector ac = AgentCollector.getInstance();
		Agent a;

		
		*/
		// Hermann Matsumbishi
		/*
		a = ac.findAgentByName("Hermann Matsumbishi");
		for (Door d : ((Room) a.getDefaultPosition()).getDoors()) {
			DoorLight dl = new DoorLight(d, (Room) a.getDefaultPosition(), a);
			dl.setMonitoredArea(Face.EAST, 20, 180);
			cc.newComponent(dl);
			cc.newComponent(new DoorSensor(d, a));
			
			System.out.println("~~~~~~~~~~~~~~~~~~~");
			System.out.println("Door: " + d);
		}

		// ##########
		// Zwotah Zwiebel
		// ##########
		a = ac.findAgentByName("Zwotah Zwiebel");
		for (Door d : ((Room) a.getDefaultPosition()).getDoors()) {
			DoorLight dl = new DoorLight(d, (Room) a.getDefaultPosition(), a);
			dl.setMonitoredArea(Face.EAST, 20, 180);
			cc.newComponent(dl);
			cc.newComponent(new DoorSensor(d, a));
		}

		// ##########
		// Dagobert Dreieck
		// ##########
		a = ac.findAgentByName("Dagobert Dreieck");
		for (Door d : ((Room) a.getDefaultPosition()).getDoors()) {
			DoorLight dl = new DoorLight(d, (Room) a.getDefaultPosition(), a);
			dl.setMonitoredArea(Face.EAST, 20, 180);
			cc.newComponent(dl);
			cc.newComponent(new DoorSensor(d, a));
		}

		// ##########
		// Felix Freudentanz
		// ##########
		a = ac.findAgentByName("Felix Freudentanz");
		for (Door d : ((Room) a.getDefaultPosition()).getDoors()) {
			DoorLight dl = new DoorLight(d, (Room) a.getDefaultPosition(), a);
			dl.setMonitoredArea(Face.NORTH, 20, 180);
			cc.newComponent(dl);
			cc.newComponent(new DoorSensor(d, a));
		}

		// ##########
		// Rudi Random
		// ##########
		a = ac.findAgentByName("Rudi Random");
		Door door8 = RoomCollector.getInstance().findDoorByIdentifier(
				"rudis-south-door");
		DoorLight doorlightRudi = new DoorLight(door8,
				(Room) a.getDefaultPosition(), a);
		doorlightRudi.setMonitoredArea(Face.SOUTH, 20, 180);
		cc.newComponent(doorlightRudi);
		cc.newComponent(new DoorSensor(door8, a));

		
		
		Door door9 = RoomCollector.getInstance().findDoorByIdentifier(
				"rudis-west-door");
		doorlightRudi = new DoorLight(door9, (Room) a.getDefaultPosition(), a);
		doorlightRudi.setMonitoredArea(Face.WEST, 20, 180);
		cc.newComponent(doorlightRudi);
		cc.newComponent(new DoorSensor(door9, a));

		// ##########
		// Susi Sekretärin
		// ##########
		Door door = RoomCollector.getInstance().findDoorByIdentifier(
				"susis-outer-door");
		a = ac.findAgentByName("Susi Sekretärin");
		DoorLight dl = new DoorLight(door, (Room) a.getDefaultPosition(), a);
		dl.setMonitoredArea(Face.WEST, 20, 180);
		cc.newComponent(dl);
		cc.newComponent(new DoorSensor(door, a));
		*/
	}
	
	
	public static void addLightsAndSensorsToDoors2() {
		ComponentCollector cc = ComponentCollector.getInstance();
		
		RoomCollector rooms = RoomCollector.getInstance();
		Agent tempAgent = null;

		File xmlFile = new File("sensors.xml");
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(xmlFile);

			NodeList doorSensorList = document.getElementsByTagName("doorsensor");
			
			for (int doorSensorIndx = 0; doorSensorIndx < doorSensorList.getLength(); ++doorSensorIndx)
			{
				Node doorSensor = doorSensorList.item(doorSensorIndx);
				Element doorSensorElem = (Element) doorSensor;
				
				String doorSensorID = doorSensorElem.getElementsByTagName("sensorid").item(0).getTextContent().trim();
				String doorID = doorSensorElem.getElementsByTagName("doorid").item(0).getTextContent().trim();
				
				cc.newComponent(new DoorSensor(doorSensorID, RoomCollector.getInstance().findDoorByIdentifier(doorID)));
			}
		} catch (ParserConfigurationException e) {e.printStackTrace();} 
		catch (SAXException e) {e.printStackTrace();} 
		catch (IOException e) {e.printStackTrace();}
	
	}
}
