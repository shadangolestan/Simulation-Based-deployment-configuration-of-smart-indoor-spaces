/*  	CASi Context Awareness Simulation Software
* Author: 		Alexandr Petcovici
* Date: 		10-December-2016
* Description:  This class is created as a temporary class 
* 				used during room import
*/
package de.uniluebeck.imis.casi.simulations.mate.generator.java;

import java.awt.geom.Point2D;
import java.util.ArrayList;

public class RoomImportTemp {
	private ArrayList<WallImportTemp> wallsTemp;
	private String roomID;
	
	public RoomImportTemp(){
		this.wallsTemp = new ArrayList<WallImportTemp>();
	}
	
	
	public void addWall(WallImportTemp newWall){this.wallsTemp.add(newWall);}
	public void setRoomId(String roomID){this.roomID = roomID;}
	public void setAllWalls(ArrayList<WallImportTemp> newWalls){this.wallsTemp = newWalls;}
	
	public String getRoomId(){return this.roomID;}
	public ArrayList<WallImportTemp> getAllWalls(){return this.wallsTemp;}
	public ArrayList<WallImportTemp> getAllWallsReversed(){
		
		ArrayList<WallImportTemp> wallsTempReverse = new ArrayList<WallImportTemp>();
		
		for(int i = wallsTemp.size() - 1; i >= 0 ; --i){
			wallsTempReverse.add(wallsTemp.get(i).getReversedWall());
		}
		
		return wallsTempReverse;
	}
	
	public void orderWalls(){
		/*
		for(int i = 0; i < this.wallsTemp.size(); ++i){
			WallImportTemp currentWall = wallsTemp.get(i);
			//System.out.println("S: " + currentWall.getStartPoint().toString() + "\tE: " + currentWall.getStartPoint().toString());
		}
		*/
		
		ArrayList<WallImportTemp> wallsTempOrdered = new ArrayList<WallImportTemp>();
		ArrayList<WallImportTemp> wallsTemp_temp = (ArrayList<WallImportTemp>) this.wallsTemp.clone();
		
		if (wallsTemp_temp.size() > 1){
			WallImportTemp firstWall = wallsTemp_temp.get(0);
			wallsTemp_temp.remove(0);
			wallsTempOrdered.add(firstWall);
			
			
			//search for the wall which has start point as the end point of the 
			// previously added wall
			boolean candidateWallNotFound = false;
			//System.out.println("Walls Temp Size: " + wallsTemp_temp.size());
			while ((wallsTemp_temp.size() > 0) && (!candidateWallNotFound)){
				// last point
				Point2D lastPoint = wallsTempOrdered.get(wallsTempOrdered.size() - 1).getEndPoint();
				boolean wallFound = false;
				//System.out.println("Last Point: " + lastPoint);
				for(int i = 0; ((i < wallsTemp_temp.size()) && (!wallFound)); ++i){
					WallImportTemp currentWall = wallsTemp_temp.get(i);
					
					Point2D sPoint = currentWall.getStartPoint();
					Point2D ePoint = currentWall.getEndPoint();
					
					//System.out.println("\t\tfirstPoint: " + sPoint);
					//System.out.println("\t\tendPoint: " + ePoint);
					
					if ((sPoint.getX() == lastPoint.getX()) && 
							(sPoint.getY() == lastPoint.getY())){
						wallsTempOrdered.add(currentWall);
						wallsTemp_temp.remove(currentWall);
						wallFound = true;
					}
					else if ((ePoint.getX() == lastPoint.getX()) && 
							(ePoint.getY() == lastPoint.getY())){
						wallsTempOrdered.add(currentWall.getReversedWall());
						wallsTemp_temp.remove(currentWall);
						wallFound = true;
					}
					
					
					if ((!wallFound) && (i == wallsTemp_temp.size() - 1)){
						System.out.println("Room walls are arranged incorrectly. Invalid room.");
						candidateWallNotFound = true;
					}
					
				}
			}
			
		}
		
		//System.out.println("Before: " + wallsTemp.size());
		//System.out.println("After: " + wallsTempOrdered.size());
		//System.out.println("Walls Temp Size: " + wallsTemp_temp.size());
		this.wallsTemp = wallsTempOrdered;
		//System.exit(1);
		
	}
	
}
