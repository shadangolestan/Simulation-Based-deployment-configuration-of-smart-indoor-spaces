/**
 * The Engine provides the main core of the simulator.
 */
package de.uniluebeck.imis.casi.simulation.engine;

