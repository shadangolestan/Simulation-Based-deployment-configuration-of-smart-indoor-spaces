/*  	CASi Context Awareness Simulation Software
* Author: 		Alexandr Petcovici
* Date: 		10-December-2016
* Description: This is sets turn off timer for home appliance
*/


package de.uniluebeck.imis.casi.simulation.model.actions;

import java.text.ParseException;
import de.uniluebeck.imis.casi.CASi;
import de.uniluebeck.imis.casi.communication.comLogger.MQTTEventLogger;
import de.uniluebeck.imis.casi.generator.ActionCollector;
import de.uniluebeck.imis.casi.generator.ComponentCollector;
import de.uniluebeck.imis.casi.simulation.engine.SimulationClock;
import de.uniluebeck.imis.casi.simulation.model.AbstractComponent;
import de.uniluebeck.imis.casi.simulation.model.AbstractInteractionComponent;
import de.uniluebeck.imis.casi.simulation.model.Agent;
import de.uniluebeck.imis.casi.simulation.model.SimulationTime;
import de.uniluebeck.imis.casi.simulation.model.actionHandling.AtomicAction;
import de.uniluebeck.imis.casi.simulation.model.actionHandling.ComplexAction;

public class SetTurnOffTimer extends AtomicAction{
	private AbstractInteractionComponent target;
	private String parentAction;
	
	public SetTurnOffTimer(AbstractInteractionComponent target, Agent performer, String parentAction)
	{
		this.target = target;
		this.parentAction = parentAction;
		
		ActionCollector actionC = ActionCollector.getInstance();
		ComponentCollector componentC = ComponentCollector.getInstance();
		
		ComplexAction actionToAdd = new ComplexAction();
		
		
		actionToAdd.addSubAction(new TurnOff(componentC.findComponentByIdentifier(target.getIdentifier()), "Turn Off"));
		try {
			actionToAdd.setEarliestStartTime(new SimulationTime(SimulationClock.getInstance().getCurrentTime().toString()));
			actionC.newAction(null, actionToAdd);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		CASi.SIM_LOG.info(SimulationClock.getInstance().getCurrentTime().getTime() + "," + 
				this.parentAction + "/" + this.getClass().getSimpleName() + "," + performer.getIdentifier() + ",[" +  
				performer.getCoordinates().getX() + "," + performer.getCoordinates().getY() + "]," + target.getIdentifier());
	
		MQTTEventLogger.getInstance().publishMQTT("casiSimulator/action_reeding/" + ((Agent)performer).getAgentRole() + "/" + performer.getIdentifier() + "/" + 
				this.parentAction + "/" + this.getClass().getSimpleName()
				, (SimulationClock.getInstance().getCurrentTime().getTime() + ",[" +  performer.getCoordinates().getX() + "," + performer.getCoordinates().getY() + "]"));
		
	}

	@Override
	protected boolean internalPerform(AbstractComponent performer) {
		// TODO Auto-generated method stub
		
		Agent agent = (Agent)performer;
		
		CASi.SIM_LOG.info(SimulationClock.getInstance().getCurrentTime().getTime() + "," + 
				this.parentAction + "/" + this.getClass().getSimpleName() + "," + performer.getIdentifier() + ",[" +  
				performer.getCoordinates().getX() + "," + performer.getCoordinates().getY() + "]," + target.getIdentifier());
	
		MQTTEventLogger.getInstance().publishMQTT("casiSimulator/action_reeding/" + ((Agent)performer).getAgentRole() + "/" + performer.getIdentifier() + "/" + 
				this.parentAction + "/" + this.getClass().getSimpleName()
				, (SimulationClock.getInstance().getCurrentTime().getTime() + ",[" +  performer.getCoordinates().getX() + "," + performer.getCoordinates().getY() + "]"));
		
		target.turnOffFunctionality();
		
		return true;
	}

	@Override
	public String getInformationDescription() {
		// TODO Auto-generated method stub
		return null;
	}
}
