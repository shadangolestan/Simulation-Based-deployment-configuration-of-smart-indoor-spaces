package de.uniluebeck.imis.casi.simulation.model.actions;
/*  	CASi Context Awareness Simulation Software
* Author: 		Alexandr Petcovici
* Date: 		10-December-2016
* Description: This is a class for TurnOn home appliances
*/


import de.uniluebeck.imis.casi.CASi;
import de.uniluebeck.imis.casi.communication.comLogger.MQTTEventLogger;
import de.uniluebeck.imis.casi.simulation.engine.SimulationClock;
import de.uniluebeck.imis.casi.simulation.model.AbstractComponent;
import de.uniluebeck.imis.casi.simulation.model.AbstractInteractionComponent;
import de.uniluebeck.imis.casi.simulation.model.Agent;
import de.uniluebeck.imis.casi.simulation.model.actionHandling.AtomicAction;

public class TurnOff extends AtomicAction{
	private AbstractInteractionComponent target;
	private String parentAction;
	
	public TurnOff(AbstractInteractionComponent target, String parentAction)
	{
		this.parentAction = parentAction;
		this.target = target;
	}

	@Override
	protected boolean internalPerform(AbstractComponent performer) {
		// TODO Auto-generated method stub
		
		Agent agent = (Agent)performer;
		
		CASi.SIM_LOG.info(SimulationClock.getInstance().getCurrentTime().getTime() + "," + 
				this.parentAction + "/" + this.getClass().getSimpleName() + "," + performer.getIdentifier() + ",[" +  
				performer.getCoordinates().getX() + "," + performer.getCoordinates().getY() + "]," + target.getIdentifier());
	
		MQTTEventLogger.getInstance().publishMQTT("casiSimulator/action_reeding/" + ((Agent)performer).getAgentRole() + "/" + performer.getIdentifier() + "/" + 
				this.parentAction + "/" + this.getClass().getSimpleName()
				, (SimulationClock.getInstance().getCurrentTime().getTime() + ",[" +  performer.getCoordinates().getX() + "," + performer.getCoordinates().getY() + "]"));
		
		target.turnOffFunctionality();
		
		return true;
	}

	@Override
	public String getInformationDescription() {
		// TODO Auto-generated method stub
		return null;
	}
}
