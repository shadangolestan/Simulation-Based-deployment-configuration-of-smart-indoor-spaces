/*  	CASi Context Awareness Simulation Software
* Author: 		Alexandr Petcovici
* Date: 		26-August-2016
* Description:  This class is MQTT Logger which allow to connect and
* 				publish MQTT logs
*/

package de.uniluebeck.imis.casi.communication.comLogger;

import java.io.File;
import java.io.IOException;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttPersistenceException;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class MQTTEventLogger {

	private static final Logger log = Logger.getLogger(MQTTEventLogger.class.getName());
	
	private static MQTTEventLogger instance;
	
	int qos             = 2;
	String broker       = "tcp://127.0.0.1:1883";
	String clientId     = "CASi";
	MqttMessage message = null;
	MemoryPersistence persistence = new MemoryPersistence();
	
	MqttClient sampleClient = null;
    MqttConnectOptions connOpts = null;
    
	private MQTTEventLogger() {
		
		try {
			
			File xmlFile = new File("simulationWorld.xml");
			
			
			// reads the content of the simulator description xml and gets connection string
			try {
				DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
				Document document = documentBuilder.parse(xmlFile);
				
				
				NodeList simMqttList = document.getElementsByTagName("mqtt_broker");
				Node simMqtteNode = simMqttList.item(0);
				Element simMqttElem = (Element) simMqtteNode;
				
				//Format example: 2016-08-24
				String ip = simMqttElem.getElementsByTagName("ip_address").item(0).getTextContent().trim();
				String port = simMqttElem.getElementsByTagName("port").item(0).getTextContent().trim();
				String protocol = simMqttElem.getElementsByTagName("protocol").item(0).getTextContent().trim();
				
				if ((ip != null) && (!ip.equals("")) && (port != null) && (!port.equals("")) 
						&& (protocol != null) && (!protocol.equals(""))){
					
					broker = protocol + "://" + ip + ":" + port;
				
				}
			
			} catch (ParserConfigurationException e) {
				//e.printStackTrace();
			} 
			catch (SAXException e) {
				//e.printStackTrace();
			} 
			catch (IOException e) {
				//e.printStackTrace();
			}
			
			
			sampleClient = new MqttClient(broker, clientId, persistence);
			sampleClient.setTimeToWait(2000);
		    connOpts = new MqttConnectOptions();
		    connOpts.setCleanSession(true);
		   
		    sampleClient.connect();
		} catch(MqttException me) {
		    //System.out.println("reason "+me.getReasonCode());
		    //System.out.println("msg "+me.getMessage());
		    //System.out.println("loc "+me.getLocalizedMessage());
		    //System.out.println("cause "+me.getCause());
		    //System.out.println("excep "+me);
		    //me.printStackTrace();
		    }
	}

	/**
	 * Getter for the instance of this singleton
	 * 
	 * @return the instance
	 */
	public static MQTTEventLogger getInstance() {
		if (instance == null) {
			instance = new MQTTEventLogger();
		}
		return instance;
	}
	
	
	/**
	 * Description: This method sends message to the mQTT server
	 * 
	 * @param topic
	 * @param content
	 */
	public void publishMQTT(String topic, String content){
		if (sampleClient.isConnected()){
			message = new MqttMessage(content.getBytes());
		    message.setQos(qos);
		    try {
				sampleClient.publish(topic, message);
			} catch (MqttPersistenceException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			} catch (MqttException e) {
				// TODO Auto-generated catch block
			//	e.printStackTrace();
			}
		}
	}
	
}
