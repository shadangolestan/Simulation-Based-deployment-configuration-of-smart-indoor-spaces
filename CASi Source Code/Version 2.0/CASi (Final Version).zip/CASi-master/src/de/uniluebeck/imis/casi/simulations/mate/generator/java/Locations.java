/*  	CASi Context Awareness Simulation Software
 *   Copyright (C) 2012 2012  Moritz Bürger, Marvin Frick, Tobias Mende
 *
 *  This program is free software. It is licensed under the
 *  GNU Lesser General Public License with one clarification.
 *  
 *  You should have received a copy of the 
 *  GNU Lesser General Public License along with this program. 
 *  See the LICENSE.txt file in this projects root folder or visit
 *  <http://www.gnu.org/licenses/lgpl.html> for more details.
 *  
 *  
*  ==================================================================
 *  Changed By: 		Alexandr Petcovici
 *  Date:				26-Aug-2016
 *  Description:		Read simulationWorld.xml and creates locations 
 *  					based on it content
 *  ==================================================================
 */
package de.uniluebeck.imis.casi.simulations.mate.generator.java;

import java.awt.Point;
import java.awt.geom.Point2D;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import de.uniluebeck.imis.casi.generator.AgentCollector;
import de.uniluebeck.imis.casi.generator.ComponentCollector;
import de.uniluebeck.imis.casi.generator.LocationCollector;
import de.uniluebeck.imis.casi.generator.RoomCollector;
import de.uniluebeck.imis.casi.simulation.engine.SimulationEngine;
import de.uniluebeck.imis.casi.simulation.factory.WorldFactory;
import de.uniluebeck.imis.casi.simulation.model.AbstractInteractionComponent;
import de.uniluebeck.imis.casi.simulation.model.AbstractInteractionComponent.Face;
import de.uniluebeck.imis.casi.simulation.model.Agent;
import de.uniluebeck.imis.casi.simulation.model.Door;
import de.uniluebeck.imis.casi.simulation.model.Location;
import de.uniluebeck.imis.casi.simulation.model.Room;
import de.uniluebeck.imis.casi.simulation.model.mackComponents.Cube;
import de.uniluebeck.imis.casi.simulation.model.mackComponents.Desktop;
import de.uniluebeck.imis.casi.simulation.model.mackComponents.DoorLight;
import de.uniluebeck.imis.casi.simulation.model.mackComponents.DoorSensor;
import de.uniluebeck.imis.casi.simulation.model.mackComponents.Mike;
import sensors.MotionSensorAnalog;
import sensors.MotionSensorBinary;
import sensors.PressureSensorAnalog;

/**
 * Fills the ComponentCollector with Components. Both Actuators and Sensors.
 * 
 * Put all your Components here!
 * 
 * @author Marvin Frick
 * 
 */
public class Locations {


	public static void addRoomsAsLocations() {
		RoomCollector roomC = RoomCollector.getInstance();
		LocationCollector locationC = LocationCollector.getInstance();
		for (Room r : roomC.getAll()) {//newLocation.setCoordinates(pTemp);
			Location locTemp = new Location(r.getIdentifier(), r.getCentralPoint());
			locTemp.setCoordinates(r.getCentralPoint());
			locationC.newLocation(locTemp);
		}
		
		
	}
	public static void addCompoentsAsLocations() {
		ComponentCollector componentC = ComponentCollector.getInstance();
		LocationCollector locationC = LocationCollector.getInstance();
		for (AbstractInteractionComponent c : componentC.getAll()) 
		{
			Location locTemp = new Location(c.getIdentifier(), c.getCentralPoint());
			
			locTemp.setCoordinates(c.getCentralPoint());
			locationC.newLocation(locTemp);
		}
	}
	
	public static void addLocationsFromXML() throws IllegalAccessException {
		LocationCollector locationC = LocationCollector.getInstance();
		File xmlFile = new File("simulationWorld.xml");
		
		RoomCollector roomC = RoomCollector.getInstance();
		
		
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document documentSensors = documentBuilder.parse(xmlFile);
			
			NodeList locationsList = documentSensors.getElementsByTagName("locations");
			Node locations = locationsList.item(0);
			Element locationsElem = (Element) locations;
			NodeList locationList = locationsElem.getElementsByTagName("location");
			
			for (int locationIndx = 0; locationIndx < locationList.getLength(); ++locationIndx){
				Node location = locationList.item(locationIndx);
				Element locationElem = (Element) location;
		
				String locationID = locationElem.getElementsByTagName("id").item(0).getTextContent().trim();
				
				Element pointElement = (Element)locationElem.getElementsByTagName("point").item(0);
				Integer xCoord = Integer.parseInt(pointElement.getElementsByTagName("xcoord").item(0).getTextContent().trim());
				Integer yCoord = Integer.parseInt(pointElement.getElementsByTagName("ycoord").item(0).getTextContent().trim());
				
				Point point = new Point(xCoord, yCoord);
				
				Point2D pTemp = new Point2D.Double(point.getX(), point.getY());
				
				Location newLocation = new Location(locationID, pTemp);
				newLocation.setCoordinates(pTemp);
				locationC.newLocation(newLocation);			
			}
		
		} catch (ParserConfigurationException e) {e.printStackTrace();} 
		catch (SAXException e) {e.printStackTrace();} 
		catch (IOException e) {e.printStackTrace();}
	}
}
