/*  	CASi Context Awareness Simulation Software
 *   Copyright (C) 2012 2012  Moritz Bürger, Marvin Frick, Tobias Mende
 *
 *  This program is free software. It is licensed under the
 *  GNU Lesser General Public License with one clarification.
 *  
 *  You should have received a copy of the 
 *  GNU Lesser General Public License along with this program. 
 *  See the LICENSE.txt file in this projects root folder or visit
 *  <http://www.gnu.org/licenses/lgpl.html> for more details.
 *  
 *  
 *  ==================================================================
 *  Changed By: 		Alexandr Petcovici
 *  Date:				26-Aug-2016
 *  Description:		Read simulationWorld.xml and creates actions 
 *  					based on it content
 *  ==================================================================
 */
package de.uniluebeck.imis.casi.simulations.mate.generator.java;


import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Logger;


import de.uniluebeck.imis.casi.generator.ActionCollector;
import de.uniluebeck.imis.casi.generator.ActivityDefinitionCollector;
import de.uniluebeck.imis.casi.generator.ActivityInstanceCollector;
import de.uniluebeck.imis.casi.generator.ActivityScheduleCollector;
import de.uniluebeck.imis.casi.generator.AgentCollector;
import de.uniluebeck.imis.casi.generator.ComponentCollector;
import de.uniluebeck.imis.casi.generator.LocationCollector;
import de.uniluebeck.imis.casi.generator.RoomCollector;
import de.uniluebeck.imis.casi.simulation.model.ActivityInstance;
import de.uniluebeck.imis.casi.simulation.model.ActivitySchedule;
import de.uniluebeck.imis.casi.simulation.model.Agent;
import de.uniluebeck.imis.casi.simulation.model.Location;
import de.uniluebeck.imis.casi.simulation.model.SimulationTime;
import de.uniluebeck.imis.casi.simulation.model.actionHandling.AbstractAction;
import de.uniluebeck.imis.casi.simulation.model.actionHandling.ComplexAction;
import de.uniluebeck.imis.casi.simulation.model.actions.Move;
import de.uniluebeck.imis.casi.simulation.model.actions.SetTurnOffTimer;
import de.uniluebeck.imis.casi.simulation.model.actions.Sit;
import de.uniluebeck.imis.casi.simulation.model.actions.StayHere;
import de.uniluebeck.imis.casi.simulation.model.actions.TurnOff;
import de.uniluebeck.imis.casi.simulation.model.actions.TurnOn;
/**
 * Action generator file with static methods that generate all the actions for
 * the MATe simulation environment World.
 * 
 * Put all your actions in here!
 * 
 * @author Marvin Frick
 * 
 */
public final class Actions {

	/**
	 * Yep, its the logger.
	 */
	private static final Logger log = Logger.getLogger(WorldGenerator.class
			.getName());

	/**
	 * Fills the ActionGenerator singleton object with all the actions.
	 * 
	 * Put all your actions here!
	 */
	/*
	public static void generateActions(SimulationTime simulationStartTime) {
		RoomCollector roomC = RoomCollector.getInstance();
		AgentCollector agentC = AgentCollector.getInstance();
		ActionCollector actionC = ActionCollector.getInstance();
		ComponentCollector componentC = ComponentCollector.getInstance();
		LocationCollector locationC = LocationCollector.getInstance();
	
		
		File xmlFile = new File("simulationWorld.xml");
		try{
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(xmlFile);
			
			NodeList actionsList = document.getElementsByTagName("actions");
			Node actionsNode = actionsList.item(0);
			Element actionsElem = (Element) actionsNode;
			
			NodeList actionList = actionsElem.getElementsByTagName("action");
			
			
			for (int actionIndx = 0; actionIndx < actionList.getLength(); ++actionIndx){
				Node actionNode = actionList.item(actionIndx);
				Element actionElem = (Element) actionNode;
				
				String actionID = actionElem.getElementsByTagName("id").item(0).getTextContent().trim();
				String agentID = actionElem.getElementsByTagName("agentID").item(0).getTextContent().trim();
				String actionDate = actionElem.getElementsByTagName("actionDate").item(0).getTextContent().trim();
				String actionTime = actionElem.getElementsByTagName("actionTime").item(0).getTextContent().trim();
				
				
				Agent currentAgent = agentC.findAgentByIdentifier(agentID);
				
				ComplexAction actionToAdd = new ComplexAction();
				
				Element subactionsElement = (Element) (actionElem.getElementsByTagName("subactions").item(0));
				NodeList subactionList = subactionsElement.getElementsByTagName("subaction");
				for(int subActionInx = 0; subActionInx < subactionList.getLength(); ++subActionInx){
				
					String actionType = subactionsElement.getElementsByTagName("actionType").item(subActionInx).getTextContent().trim();
					String target = subactionsElement.getElementsByTagName("target").item(subActionInx).getTextContent().trim();
					Location loc = (Location) locationC.findLocationByIdentifier(target);
					if(actionType.equals("Move")){actionToAdd.addSubAction(new Move(loc));}
					else if(actionType.equals("Sit")){actionToAdd.addSubAction(new Sit());}
				}
				

				actionToAdd.setEarliestStartTime(new SimulationTime(actionDate + " " + actionTime));
				actionC.newAction(currentAgent + "_" + actionID, actionToAdd);
			
			}
		} catch (ParserConfigurationException e) {e.printStackTrace();} 
		catch (SAXException e) {e.printStackTrace();} 
		catch (IOException e) {e.printStackTrace();}
		catch (ParseException e) {e.printStackTrace();}
		
	}
	*/

	/**
	 * Generate all the action pools
	 * 
	 * @param startTime
	 */
	public static void generateActionsPools(SimulationTime startTime) {
		// all agents have some ActionPool actions


	}

	/**
	 * Adds a given action to every already created agents action pool. Clones
	 * the action so that everyone has its own.
	 * 
	 * @param action
	 *            the action that everyone should do
	 * @param givenIdentifier
	 *            used to generate the key at which the action should be stored
	 */
	private static void forAllAgentsActionPoolDoThis(AbstractAction action,
			String givenIdentifier) {
		
		for (Agent a : AgentCollector.getInstance().getAll()) {
			AbstractAction clonedAction = action.clone();
			ActionCollector.getInstance().newAction(
					a.getIdentifier() + "_" + givenIdentifier + "_pool",
					clonedAction);
		}
		
	}
	
	
	public static void generateSchedActions(){
		ActivityInstanceCollector instC = ActivityInstanceCollector.getInstance();
		ActivityDefinitionCollector defC = ActivityDefinitionCollector.getInstance();
		ActivityScheduleCollector schedC = ActivityScheduleCollector.getInstance();
		
		HashMap<String, ActivitySchedule> schedActHash = schedC.getAlreadyScheduledActivities();
		HashMap<String, ActivityInstance> instActHash = instC.getAlreadyCreatedActInst();
		HashMap<String, String> defActHash = defC.getAlreadyCreatedActDefs();
		
		
		RoomCollector roomC = RoomCollector.getInstance();
		AgentCollector agentC = AgentCollector.getInstance();
		ActionCollector actionC = ActionCollector.getInstance();
		ComponentCollector componentC = ComponentCollector.getInstance();
		LocationCollector locationC = LocationCollector.getInstance();
		
		
		
		Iterator it = schedActHash.entrySet().iterator();
	    while (it.hasNext()) {
	        Map.Entry pair = (Map.Entry)it.next();
	        //System.out.println(pair.getKey() + " = " + pair.getValue());
	        //System.out.println("Key: " + ((String) pair.getKey()));
	        
	        ActivitySchedule actSched_temp = (ActivitySchedule)pair.getValue();
	        String agentID_str = actSched_temp.getAgentId();
	        String startDay_str = actSched_temp.getSchedStartDay();
	        String startTime_str = actSched_temp.getSchedStartTime();
	        
	        //System.out.println("\tAgent ID: " + agentID_str);
	        //System.out.println("\tSart Day: " + startDay_str);
	        //System.out.println("\tStart Time: " + startTime_str);
	        
	    	
			Agent currentAgent = agentC.findAgentByIdentifier(agentID_str);
			
			ComplexAction actionToAdd = new ComplexAction();
			
	        
	        ArrayList<String> actTypes = actSched_temp.getActionTypes();
	        for(int i = 0; i < actTypes.size(); ++i)
	        {
	        	ActivityInstance actInst = instActHash.get(actTypes.get(i));
	        	
	        	//System.out.println("\t" + actInst.getID() + "->");
	        	
	        	ArrayList<String> actInstIDs = actInst.getActivityIDs();
	        	for (int j = 0; j < actInstIDs.size(); j++)
	        	{
	        		//System.out.println("\t\tActInst: " + actInstIDs.get(j));
	        		
	        		String target = actInst.getSubActTargetByIndex(j);
	        		String parameter = actInst.getSubActParameterByIndex(j);
	        		String actionType = defActHash.get(actInstIDs.get(j));
	        		
	        		//System.out.println("\t\tType: " + actionType);
	        		//System.out.println("\t\tTarget: " + target);
	        		//System.out.println("\t\tTimer: " + timer);
	        		//System.out.println("-->" + defActHash.get(actInst.getID()));
					
	        		//if(actionType == null){actionType = defActHash.get(actInst.getID());}
	        		String parentAction = actInstIDs.get(j);
	        		if(actionType == null){
	        			actionType = actInstIDs.get(j);
	        			parentAction = actInst.getID();
	        		}
	        		//System.out.println("\t\t\t\tPARENT ACTION: " + parentAction);
	        		
					Location loc = (Location) locationC.findLocationByIdentifier(target);
					if(actionType.equals("Move")){actionToAdd.addSubAction(new Move(loc, parentAction));}
					//else if(actionType.equals("Sit")){actionToAdd.addSubAction(new Sit(loc, parentAction));}
					else if(actionType.equals("Turn On")){
						actionToAdd.addSubAction(new TurnOn(componentC.findComponentByIdentifier(target), parentAction));
					}else if(actionType.equals("StayTimer")){
						actionToAdd.addSubAction(new StayHere(Integer.parseInt(parameter), 2, parentAction));
					}else if(actionType.equals("SitTimer")){
						actionToAdd.addSubAction(new Sit(Integer.parseInt(parameter), 2, parentAction));
					}else if(actionType.equals("Turn Off")){
						actionToAdd.addSubAction(new TurnOff(componentC.findComponentByIdentifier(target), parentAction));
					}else if (actionType.equals("Set Turn Off Timer")){
						System.out.println("Set Turn Off Timer");
						actionToAdd.addSubAction(new SetTurnOffTimer(componentC.findComponentByIdentifier(target), currentAgent, parentAction));
						System.exit(1);
					}
	        	}
	        	
	        }
	        //actionC.newAction(identifier, newAction);
	       // System.exit(0);
			try {
				actionToAdd.setEarliestStartTime(new SimulationTime(startDay_str + " " + startTime_str));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			actionC.newAction(currentAgent + "_" + (String) pair.getKey(), actionToAdd);
				
	        it.remove(); // avoids a ConcurrentModificationException
	    }
	}
}
