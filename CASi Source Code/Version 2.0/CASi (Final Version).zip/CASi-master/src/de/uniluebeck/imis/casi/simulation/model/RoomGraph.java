/*  	CASi Context Awareness Simulation Software
* Author: 		Alexandr Petcovici
* Date: 		10-December-2016
* Description:  This class graph for room path
* 				finding algorithms
*/
package de.uniluebeck.imis.casi.simulation.model;

import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import de.uniluebeck.imis.casi.generator.ObstacleCollector;


public class RoomGraph {
	private ArrayList<ArrayList<Double>> adjGraph;
	private ArrayList<ArrayList<List<Point2D>>> paths;
	private Room room;
	private ArrayList<Obstacle> obstacles;
	private Set<Door> doors;
	private int numVertexes;
	private List<Point2D> points;
	private List<Integer> identifiers;
	private ArrayList<ArrayList<Point2D>> distPaths;
	
	
	public RoomGraph(Room room){
		this.room = room;
		this.obstacles = room.getObstacles();
		this.doors = room.getDoors();
		this.points = new ArrayList<Point2D>();
		this.identifiers = new ArrayList<Integer>();
		
		numVertexes = 0;
		
		for (Door d: doors){
			numVertexes++;
			identifiers.add(points.size());
			points.add(d.getCentralPoint());
			
		}
		
		for (Obstacle o: obstacles){
			numVertexes += o.getWallPoints().size();
			List<Point2D> pts = o.getWallPoints();
			
			for(Point2D p : pts){
				identifiers.add(points.size());
				points.add(p);
			}
		}
		
		
		
		adjGraph = new ArrayList<ArrayList<Double>>();
		paths = new ArrayList<ArrayList<List<Point2D>>>();
		
		initializeGraph();
		if (adjGraph.size() > 1) calculateAdjacencies();
		calculatePointDistances();
		precomputeGraphPaths();

	}
	
	
	private void initializeGraph() {
	//	int size = adjGraph.length;
		for (int i = 0; i < numVertexes; i++) {
			ArrayList<Double> line = new ArrayList<Double>();
			for (int j = 0; j < numVertexes; j++) {
				line.add(new Double(1));
				//adjGraph[i][j] = 1;//Double.NEGATIVE_INFINITY;
			}
			adjGraph.add(line);
		}
	}

	
	private void calculateAdjacencies() {
		
		for (Door first : doors) {
			for (Door second : doors) {
				if (first.getCentralPoint().equals(second.getCentralPoint())) {
					adjGraph.get(first.getIntIdentifier()).set(second.getIntIdentifier(), new Double(0));
					continue;
				}
				adjGraph.get(first.getIntIdentifier()).set(second.getIntIdentifier(), new Double(1));
			}
		}

		int obstPointCounter = doors.size();
		for(Obstacle obstacle: obstacles){
			List<Point2D> obstaclePoints = obstacle.getWallPoints();
			int firstPointIndex = obstPointCounter;
			for(Point2D firstObstaclePoint: obstaclePoints){
				int secondPointIndex = obstPointCounter;
				for(Point2D secondObstaclePoint: obstaclePoints){

					if (firstPointIndex == secondPointIndex){
						adjGraph.get(firstPointIndex).set(secondPointIndex, new Double(0));
					}
					else if ((obstaclePoints.indexOf(firstObstaclePoint) + 1 == obstaclePoints.indexOf(secondObstaclePoint)) 
							|| (obstaclePoints.indexOf(firstObstaclePoint) - 1 == obstaclePoints.indexOf(secondObstaclePoint)) 
					) 
					{
						adjGraph.get(firstPointIndex).set(secondPointIndex, new Double(1));
						adjGraph.get(secondPointIndex).set(firstPointIndex, new Double(1));
					}
					else{
						adjGraph.get(firstPointIndex).set(secondPointIndex, Double.POSITIVE_INFINITY);
						adjGraph.get(secondPointIndex).set(firstPointIndex, Double.POSITIVE_INFINITY);
					}
					secondPointIndex++;
				}
				firstPointIndex++;
			}
		
			adjGraph.get(obstPointCounter).set(obstPointCounter + obstaclePoints.size() - 1, new Double(1));
			adjGraph.get(obstPointCounter + obstaclePoints.size() - 1).set(obstPointCounter, new Double(1));
			
			obstPointCounter += obstacle.getWallPoints().size();
		}
		removeLineIntersections();
	}
	
	public void calculatePointDistances(){
		for(int i = 0; i < points.size(); ++i){
			Point2D start = points.get(i);//.getCentralPoint();
			for(int j = 0; j < points.size(); ++j){
				Point2D end = points.get(j);
				if ((adjGraph.get(i).get(j).doubleValue() == 1)){
					double distance =  Math.sqrt((start.getX() - end.getX())*(start.getX()-end.getX()) 
							+ (start.getY() - end.getY())*(start.getY()-end.getY()));

					adjGraph.get(j).set(i, distance);
					adjGraph.get(i).set(j, distance);
					
				}
			}
		}
	}
	

	
	public List<Point2D> getPathBresenhem(Point2D startPoint, Point2D endPoint){
		
		List<Point2D> path_temp = new LinkedList<Point2D>();
		
		int x = (int)startPoint.getX();
		int y = (int)startPoint.getY();
		
		int x2 = (int)endPoint.getX();
		int y2 = (int)endPoint.getY();
		
		int w = x2 - x ;
	    int h = y2 - y ;
	    int dx1 = 0, dy1 = 0, dx2 = 0, dy2 = 0 ;
	    if (w<0) dx1 = -1 ; else if (w>0) dx1 = 1 ;
	    if (h<0) dy1 = -1 ; else if (h>0) dy1 = 1 ;
	    if (w<0) dx2 = -1 ; else if (w>0) dx2 = 1 ;
	    int longest = Math.abs(w) ;
	    int shortest = Math.abs(h) ;
	    if (!(longest>shortest)) {
	        longest = Math.abs(h) ;
	        shortest = Math.abs(w) ;
	        if (h<0) dy2 = -1 ; else if (h>0) dy2 = 1 ;
	        dx2 = 0 ;            
	    }
	    int numerator = longest >> 1 ;
	    for (int i=1;i<=longest - 1;i++) {
	    	Point2D point_temp = new Point2D.Double();
	        point_temp.setLocation(x, y);
	        
	        path_temp.add(point_temp);
	    	numerator += shortest ;
	        if (!(numerator<longest)) {
	            numerator -= longest ;
	            x += dx1 ;
	            y += dy1 ;
	        } else {
	            x += dx2 ;
	            y += dy2 ;
	        }
	    }
	    
	    path_temp.add(endPoint);
	    return path_temp;
	}

	private void printGraph() {
		StringBuffer head = new StringBuffer();
		head.append("\t ");
		for (int j = 0; j < adjGraph.size(); j++) {
			head.append("d-" + j + "\t ");
		}
		StringBuffer b = new StringBuffer();
		b.append(head.toString());
		b.append("\n");
		for (int i = 0; i < adjGraph.size(); i++) {
			b.append("d-" + i + ":\t ");
			for (int j = 0; j < adjGraph.get(i).size(); j++) {
				b.append(adjGraph.get(i).get(j).intValue() + "\t ");
			}
			b.append("\n");
		}
		
	}
	
	
	
	public List<Point2D>  calculateIndoorPath(Point2D source, Point2D destination){
		ArrayList<Point2D> pointsToExclude = new ArrayList<Point2D>();
		Set<String> obstaclesToBypass = new TreeSet<String>();
		
		
		for(Obstacle obstacle: this.obstacles){
			if ((obstacle.contains(destination) || obstacle.contains(source))) {
				for (Point2D pt: obstacle.getWallPoints()){
					obstaclesToBypass.add(obstacle.getIdentifier());
					pointsToExclude.add(pt);
				}
			}
		}
		
		int sourceIndex = isPointInGraph(source);
		int destinationIndex = isPointInGraph(destination);
		
		int numNewPoints = 0;
		
		if (sourceIndex == -1){
			sourceIndex = adjGraph.size() + numNewPoints;
			numNewPoints++;
			identifiers.add(points.size());points.add(source);
		}
		if  (destinationIndex == -1) {
			destinationIndex = adjGraph.size() + numNewPoints;
			numNewPoints++;
			identifiers.add(points.size());points.add(destination);
		}
		
		expandGraph(numNewPoints);		
		removeLineIntersections(obstaclesToBypass);
		calculatePointDistances();
		
		double[][] djkstraGraphAdj = getDijksraArray();
		removeInnerObstcleLines(pointsToExclude, djkstraGraphAdj);
		
		Point[] dist = dijkstra(djkstraGraphAdj, sourceIndex);
		
		List<Point2D> finalPath = new ArrayList<Point2D>();
		ArrayList<Integer> path = getPath(destinationIndex, sourceIndex, dist);

		for(int i = 0; i < path.size() - 1; ++i) {			
			if ((path.get(i) >= paths.size()) || (path.get(i + 1) >= paths.size()))
				finalPath.addAll(getPathBresenhem(points.get(path.get(i)), points.get(path.get(i + 1))));
			else 
				finalPath.addAll(paths.get((path.get(i))).get(path.get(i + 1)));
		}		
		
		clenUp(numNewPoints);
		//printtArray2D(djkstraGraphAdj);
		
		return finalPath;
	}
	
	/*http://www.cs.ucf.edu/~dmarino/ucf/java/dijkstra.java*/
	private ArrayList<Integer> getPath(int e, int s, Point[] dist){
		ArrayList<Integer> graphPath = new ArrayList<Integer>();
		//boolean firstTime = true;
		
		while (e != s) {
				graphPath.add(0, e);
				e = dist[e].last;
			}
		graphPath.add(0, s);
		return graphPath;
	}
	
	
	private int isPointInGraph(Point2D pointToCheck){
		
		for(Point2D point: points){
			if ((pointToCheck.getX() == point.getX()) && 
					(pointToCheck.getY() == point.getY()))
				return points.indexOf(point);
		}
		return -1;
	}
	

    
    /*http://www.cs.ucf.edu/~dmarino/ucf/java/dijkstra.java*/
	public Point[] dijkstra(double[][] djkstraGraphAdj, int source) {
		
		Point[] estimates = new Point[djkstraGraphAdj.length];
		
		// Set up our initial estimates.
		for (int i=0; i<estimates.length; i++)
			estimates[i] = new Point(Double.POSITIVE_INFINITY, source);
			
		estimates[source].distance = 0.0;
		for (int i=0; i<estimates.length-1; i++) {
			int vertex = 0;
			double bestseen = Double.POSITIVE_INFINITY;
			
			for (int j=0; j<estimates.length; j++) {
				if (estimates[j].chosen == false && 
				    estimates[j].distance < bestseen) {
				
					bestseen = estimates[j].distance;
					vertex = j;
				}
			}
			
			estimates[vertex].chosen = true;
			
			for (int j = 0; j<estimates.length; j++) {
				if (estimates[vertex].distance+djkstraGraphAdj[vertex][j] < 
				    estimates[j].distance) {
				    
				    estimates[j].distance = estimates[vertex].distance + djkstraGraphAdj[vertex][j];	
				    estimates[j].last = vertex;
				}
			}
			
		}

		for (int i = 0; i < djkstraGraphAdj.length; ++i){
			djkstraGraphAdj[source][i] = estimates[i].distance;
			djkstraGraphAdj[i][source] = estimates[i].distance;
		}
		
		return estimates;
	}
	
	public void expandGraph(int numNewPoints){
		//START expanding adjacency list graph
		for(int i = 0; i < numNewPoints; ++i){
			ArrayList<Double> line = new ArrayList<Double>();
			for (int j = 0; j < adjGraph.size() - i; ++j)
				line.add(new Double(Double.POSITIVE_INFINITY));	
			adjGraph.add(line);
		}

		for(int i = 0; i < adjGraph.size(); ++i)
			for (int j = 0; j < numNewPoints; ++j)
				adjGraph.get(i).add(new Double(1));
		
	}
	
	public void removeLineIntersections(){
		for(int i = 0; i < points.size(); ++i){
			Point2D start = points.get(i);
			for(int j = 0; j < points.size(); ++j){
				Point2D end = points.get(j);
				if (adjGraph.get(i).get(j).doubleValue() != 0){
					// if there is no direct path, set to 0
					
					for (Obstacle obstacle: obstacles)
					{
						for (Wall wall: obstacle.getWalls())
						{
							// check if the start or end point is not part of the 
							// wall for which we want to check the intersections
							
							Point2D firstPoint = wall.getStartPoint();
							Point2D secondPoint = wall.getEndPoint();
							
							boolean condition1 = ((firstPoint.getX() == start.getX()) && (firstPoint.getY() == start.getY()));
							boolean condition2 = ((firstPoint.getX() == end.getX()) && (firstPoint.getY() == end.getY()));
							
							boolean condition3 = ((secondPoint.getX() == start.getX()) && (secondPoint.getY() == start.getY()));
							boolean condition4 = ((secondPoint.getX() == end.getX()) && (secondPoint.getY() == end.getY()));
							
							if ((!condition1) && (!condition2) && (!condition3) && (!condition4)) {
								
								
								Line2D pathLine = new Line2D.Double(start, end);
								Line2D wallLine = new Line2D.Double(wall.getStartPoint(), wall.getEndPoint());
								boolean isPointOnWall = pathLine.intersectsLine(wallLine);
								if (isPointOnWall) {
									adjGraph.get(i).set(j, Double.POSITIVE_INFINITY);
									adjGraph.get(j).set(i, Double.POSITIVE_INFINITY);
								}
								
							}
						}
					}
					
				}
				
			}
		}
	}
	
	
	public void removeLineIntersections(Set<String> obsToBypass){
		for(int i = 0; i < points.size(); ++i){
			Point2D start = points.get(i);
			for(int j = 0; j < points.size(); ++j){
				Point2D end = points.get(j);
				if (adjGraph.get(i).get(j).doubleValue() != 0){
					// if there is no direct path, set to 0
					
					for (Obstacle obstacle: obstacles)
					{
						if (!obsToBypass.contains(obstacle.getIdentifier()))
						{
							for (Wall wall: obstacle.getWalls())
							{
								// check if the start or end point is not part of the 
								// wall for which we want to check the intersections
								
								Point2D firstPoint = wall.getStartPoint();
								Point2D secondPoint = wall.getEndPoint();
								
								boolean condition1 = ((firstPoint.getX() == start.getX()) && (firstPoint.getY() == start.getY()));
								boolean condition2 = ((firstPoint.getX() == end.getX()) && (firstPoint.getY() == end.getY()));
								
								boolean condition3 = ((secondPoint.getX() == start.getX()) && (secondPoint.getY() == start.getY()));
								boolean condition4 = ((secondPoint.getX() == end.getX()) && (secondPoint.getY() == end.getY()));
								
								if ((!condition1) && (!condition2) && (!condition3) && (!condition4)) {
									
									
									Line2D pathLine = new Line2D.Double(start, end);
									Line2D wallLine = new Line2D.Double(wall.getStartPoint(), wall.getEndPoint());
									boolean isPointOnWall = pathLine.intersectsLine(wallLine);
									if (isPointOnWall) {
										adjGraph.get(i).set(j, Double.POSITIVE_INFINITY);
										adjGraph.get(j).set(i, Double.POSITIVE_INFINITY);
									}
									
								}
							}//
						}
					}
					
				}
				
			}
		}
	}
	
	private void printtArray2D(double[][] arr){
		for(int i = 0; i < arr.length; ++i){
			for(int j = 0; j < arr[i].length; ++j) System.out.print(arr[i][j] + "\t");
			System.out.println("");
		}
	}
	
	
	private void removeInnerObstcleLines(ArrayList<Point2D> excludedPoints, double[][] graph){
		//basically removing obstacle points from graph
		for(int i = 0; i < excludedPoints.size(); ++i){
			
			int pointIndex = points.indexOf(excludedPoints.get(i));// + doors.size();
			if (pointIndex < points.size()){
				for (int j = 0; j < graph.length; ++j){
					if (pointIndex != j){
						graph[j][pointIndex] = Double.POSITIVE_INFINITY;
						graph[pointIndex][j] = Double.POSITIVE_INFINITY;
					}
				}
			}
		}		
	}
	
	public double[][] getDijksraArray() {
		double[][] djkstraGraphAdj = new double[adjGraph.size()][];
		for (int i = 0; i < adjGraph.size(); i++) {
		    ArrayList<Double> row = adjGraph.get(i);
		    djkstraGraphAdj[i] = new double[row.size()];
		    for (int j = 0; j < row.size(); ++j){
		    	djkstraGraphAdj[i][j] = row.get(j).doubleValue();
		    }
		}
		return djkstraGraphAdj;
	}
	
	private void clenUp(int numNewPoints){
		
		
		// cleanUp
		for (int i = 0; i < numNewPoints; ++i) adjGraph.remove(adjGraph.size() - 1);
		
		
		for (int i = 0; i < adjGraph.size(); ++i) 
			for(int j = 0; j < numNewPoints; ++j)
				adjGraph.get(i).remove(adjGraph.get(i).size() - 1);
		
		for (int i = 0; i < numNewPoints; ++i){points.remove(points.size() - 1);}
	}
	
	private void precomputeGraphPaths()
	{
		// initialize Path arrayList
		for (int i = 0; i < points.size(); ++i){
			ArrayList<List<Point2D>> pathLine = new ArrayList<List<Point2D>>();
			for (int j = 0; j < points.size(); ++j){
				pathLine.add(null);
			}
			paths.add(pathLine);
		}
		
		for (int i = 0; i < points.size(); ++i){
			for (int j = 0; j < points.size(); ++j){
				List<Point2D> path = getPathBresenhem(points.get(i), points.get(j));
				paths.get(i).set(j, path);
				//paths.get(j).set(i, path);
			}
		}
	}
}

/*http://www.cs.ucf.edu/~dmarino/ucf/java/dijkstra.java*/
class Point {
	
	public Double distance;
	public boolean chosen;
	public int last;
	
	public Point(double d, int source) {
		distance = new Double(d);
		last = source;
		chosen = false;
	}
}