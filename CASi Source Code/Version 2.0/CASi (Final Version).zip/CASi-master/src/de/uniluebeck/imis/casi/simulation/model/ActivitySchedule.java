package de.uniluebeck.imis.casi.simulation.model;

import java.util.ArrayList;

public class ActivitySchedule {

	String schedID;
	String schedStartDay;
	String schedStartTime;
	String agentId;
	
	ArrayList<String> subAcionType;
	
	public ActivitySchedule(String schedID, String schedStartDay, String schedStartTime, String agentId)
	{
		this.schedID = schedID;
		this.schedStartDay = schedStartDay;
		this.schedStartTime = schedStartTime;
		this.agentId = agentId;
		
		subAcionType = new ArrayList<String>();
	}
	
	public void addSubActivity(String subactivity){this.subAcionType.add(subactivity);}
	public String getSubActByIndex(int index){return this.subAcionType.get(index);}
	
	public String getSchedID(){return this.schedID;}
	public String getSchedStartDay(){return this.schedStartDay;}
	public String getSchedStartTime(){return this.schedStartTime;}
	public String getAgentId(){return this.agentId;}
	
	public ArrayList<String> getActionTypes(){return this.subAcionType;}
	
}
