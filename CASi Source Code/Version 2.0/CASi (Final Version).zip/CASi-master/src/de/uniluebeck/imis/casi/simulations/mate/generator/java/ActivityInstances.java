/*  	CASi Context Awareness Simulation Software
* Author: 		Alexandr Petcovici
* Date: 		10-December-2016
* Description:  This class reads activity instances from input
*/
package de.uniluebeck.imis.casi.simulations.mate.generator.java;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import de.uniluebeck.imis.casi.generator.ActivityInstanceCollector;
import de.uniluebeck.imis.casi.simulation.model.ActivityInstance;


/**
 * Fills the ComponentCollector with Components. Both Actuators and Sensors.
 * 
 * Put all your Components here!
 * 
 * @author Marvin Frick
 * 
 */
public class ActivityInstances {

/*
	public static void addRoomsAsLocations() {
		RoomCollector roomC = RoomCollector.getInstance();
		LocationCollector locationC = LocationCollector.getInstance();
		for (Room r : roomC.getAll()) {//newLocation.setCoordinates(pTemp);
			Location locTemp = new Location(r.getIdentifier(), r.getCentralPoint());
			locTemp.setCoordinates(r.getCentralPoint());
			locationC.newLocation(locTemp);
		}
		
		
	}
	public static void addCompoentsAsLocations() {
		ComponentCollector componentC = ComponentCollector.getInstance();
		LocationCollector locationC = LocationCollector.getInstance();
		for (AbstractInteractionComponent c : componentC.getAll()) 
		{
			Location locTemp = new Location(c.getIdentifier(), c.getCentralPoint());
			
			locTemp.setCoordinates(c.getCentralPoint());
			locationC.newLocation(locTemp);
		}
	}
*/	
	
	public static void addActivityInstancesFromXML() throws IllegalAccessException {
	
		
		File xmlFile = new File("simulationWorld.xml");
		ActivityInstanceCollector actInstCollector = ActivityInstanceCollector.getInstance();
		
		//HashMap <String, String> actDefTemp = new HashMap <String, String>();
		
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document documentSensors = documentBuilder.parse(xmlFile);
			
			NodeList activityDefinietionList = documentSensors.getElementsByTagName("activityInstances");
			Node activityDefinitions = activityDefinietionList.item(0);
			Element activityDefinitionsElem = (Element) activityDefinitions;
			NodeList activityDefinitionList = activityDefinitionsElem.getElementsByTagName("activityInstance");
			
			for (int activityDefinitionIndx = 0; activityDefinitionIndx < activityDefinitionList.getLength(); ++activityDefinitionIndx){
				Node location = activityDefinitionList.item(activityDefinitionIndx);
				Element activityDefinitionElem = (Element) location;
		
				String activityDefinitionName = activityDefinitionElem.getElementsByTagName("activityInstName").item(0).getTextContent().trim();
				
				ActivityInstance newActInst = new ActivityInstance(activityDefinitionName);
				
				Node subActivityDefinitionsParentNode = activityDefinitionElem.getElementsByTagName("SubActivityInstances").item(0);
				Element subActivityDefinitionsParentElement = (Element) subActivityDefinitionsParentNode;
				
				NodeList subActivityDefinitionList = subActivityDefinitionsParentElement.getElementsByTagName("SubActivityInstance");
				
				for (int subActivityIndex = 0; subActivityIndex < subActivityDefinitionList.getLength(); ++subActivityIndex)
				{
					Node subactivityNode = subActivityDefinitionList.item(subActivityIndex);
					Element subactivityElement = (Element) subactivityNode;
					
					
					String activityID = subactivityElement.getElementsByTagName("activityID").item(0).getTextContent().trim();
					
					String activityType = subactivityElement.getElementsByTagName("target").item(0).getTextContent().trim();

					String activityParameter = subactivityElement.getElementsByTagName("actionParameter").item(0).getTextContent().trim();
					
					newActInst.addSubActInst(activityID, activityType, activityParameter);
					
				}
				
				actInstCollector.newActInst(activityDefinitionName, newActInst);
				

			}
		
		} catch (ParserConfigurationException e) {e.printStackTrace();} 
		catch (SAXException e) {e.printStackTrace();} 
		catch (IOException e) {e.printStackTrace();}
		
		/*
		HashMap <String, ActivityInstance> actDefTemp = actInstCollector.getAlreadyCreatedActions();
	    Iterator it = actDefTemp.entrySet().iterator();
	    while (it.hasNext()) {
	        Map.Entry pair = (Map.Entry)it.next();
	        //System.out.println(pair.getKey() + " = " + pair.getValue());
	        ActivityInstance actionInst = (ActivityInstance) pair.getValue();
	        
	        ArrayList<String> ids = actionInst.getActivityIDs();
	        System.out.println(actionInst.getID());
	        for(int i = 0; i < ids.size(); ++i)
	        {
	        	System.out.println("\t\tID:\t" + ids.get(i) + "\ttarget:\t" + actionInst.getSubActTargetByIndex(i) + "\tTimer:\t" + actionInst.getSubActTimeByIndex(i));
	        }
	         	
	        it.remove(); // avoids a ConcurrentModificationException
	    }
	    */
	    
	//	System.exit(0);
		
	}
}
