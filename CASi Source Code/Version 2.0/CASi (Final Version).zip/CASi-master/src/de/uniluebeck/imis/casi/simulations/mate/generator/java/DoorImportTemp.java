package de.uniluebeck.imis.casi.simulations.mate.generator.java;


/*  	CASi Context Awareness Simulation Software
* Author: 		Alexandr Petcovici
* Date: 		10-December-2016
* Description:  This class is used for import doors. It exists only
* 				during room generation and is not used later in the
* 				Simulator
*/

public class DoorImportTemp {
	//doorid, Integer.parseInt(doorX), Integer.parseInt(doorY), Integer.parseInt(doorsize)
	private String doorId;
	private int xCoord;
	private int yCoord;
	private int doorSize;
	
	// to limit default access
	@SuppressWarnings("unused")
	private DoorImportTemp(){}

	public DoorImportTemp(String doorid, int doorX, int doorY, int doorsize){
		this.doorId = doorid;
		this.xCoord = doorX;
		this.yCoord = doorY;
		this.doorSize = doorsize;
	}
	
	
	public void setDoorId(String doorID){this.doorId = doorID;}
	public void setXCoord(int x){this.xCoord = x;}
	public void setYCoord(int y){this.yCoord = y;}
	public void setDoorSize(int doorSize){this.doorSize = doorSize;}
	
	public String getDoorId(){return this.doorId;}
	public int getXCoord(){return this.xCoord;}
	public int getYCoord(){return this.yCoord;}
	public int getDoorSize(){return this.doorSize;}
}
