/*  	CASi Context Awareness Simulation Software
 *   Copyright (C) 2011 2012  Moritz Bürger, Marvin Frick, Tobias Mende
 *
 *  This program is free software. It is licensed under the
 *  GNU Lesser General Public License with one clarification.
 *  
 *  You should have received a copy of the 
 *  GNU Lesser General Public License along with this program. 
 *  See the LICENSE.txt file in this projects root folder or visit
 *  <http://www.gnu.org/licenses/lgpl.html> for more details.
 */
package de.uniluebeck.imis.casi.simulation.model;

/**
 * This interface must be used by components that want to listen to doors
 * @author Tobias Mende
 *
 */
public interface IMovementSensorListener {
	/** Event: door state has changed 
	 * 
	 * @param oldState the state before the change
	 * @param newState the state after the change
	 */
	public void stateChanged(Door.State oldState, Door.State newState);
}
