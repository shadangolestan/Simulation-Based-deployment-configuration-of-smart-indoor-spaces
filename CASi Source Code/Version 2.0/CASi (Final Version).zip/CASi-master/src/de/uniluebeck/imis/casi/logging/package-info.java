/**
 * Provides classes for different logging outputs
 */
package de.uniluebeck.imis.casi.logging;

