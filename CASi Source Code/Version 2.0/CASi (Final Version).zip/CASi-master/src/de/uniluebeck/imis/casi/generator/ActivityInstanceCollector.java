/*  	CASi Context Awareness Simulation Software
* Author: 		Alexandr Petcovici
* Date: 		10-December-2016
* Description:  This class is collector for activity instances
*/
package de.uniluebeck.imis.casi.generator;
import java.util.HashMap;

import de.uniluebeck.imis.casi.simulation.model.ActivityInstance;

public class ActivityInstanceCollector {
	

	
	
	/** The instance of this singleton */
	private static ActivityInstanceCollector instance;

	/**
	 * The List of already created agents.
	 */
	private HashMap<String, ActivityInstance> alreadyCreatedActInst = new HashMap<String, ActivityInstance>();

	/**
	 * The private constructor of this singleton
	 */
	private ActivityInstanceCollector() {
		// just here for prohibiting external access
	}

	/**
	 * Getter for the instance of this singleton
	 * 
	 * @return the instance
	 */
	public static ActivityInstanceCollector getInstance() {
		if (instance == null) {
			instance = new ActivityInstanceCollector();
		}
		return instance;
	}


	public void newActInst(String identifier, ActivityInstance newAction) {
		alreadyCreatedActInst.put(identifier, newAction);
	}

	/**
	 * Simple getter that returns the HashMap of all Actions
	 * 
	 * @return all the Actions
	 */
	public HashMap<String, ActivityInstance> getAlreadyCreatedActInst() {
		return alreadyCreatedActInst;
	}

}
