/*  CASi Context Awareness Simulation Software
 *  Copyright (C) 2012 2012  Moritz B�rger, Marvin Frick, Tobias Mende
 *
 *  This program is free software. It is licensed under the
 *  GNU Lesser General Public License with one clarification.
 *  
 *  You should have received a copy of the 
 *  GNU Lesser General Public License along with this program. 
 *  See the LICENSE.txt file in this projects root folder or visit
 *  <http://www.gnu.org/licenses/lgpl.html> for more details.
 *  
 *  ==================================================================
 *  Changed By: 		Alexandr Petcovici
 *  Date:				26-Aug-2016
 *  Description:		Read simulationWOrld.xml and creates rooms based
 *  					on it content
 *  ==================================================================
 */
package de.uniluebeck.imis.casi.simulations.mate.generator.java;

import java.awt.Point;
import java.awt.geom.Point2D;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


import de.uniluebeck.imis.casi.generator.RoomCollector;
import de.uniluebeck.imis.casi.simulation.factory.WallFactory;
import de.uniluebeck.imis.casi.simulation.model.Door;
import de.uniluebeck.imis.casi.simulation.model.Room;
import de.uniluebeck.imis.casi.simulation.model.Wall;

/**
 * Room generator file with static methods that generate all the rooms for the
 * MATe simulation environment World.
 * 
 * Put all your rooms in here!
 * 
 * @author Marvin Frick
 * 
 */
public class Rooms {

	/**
	 * Fills the RoomGenerator singleton object with all the rooms.
	 * 
	 * Put all your rooms here!
	 */
	public static void generateRooms() {
		//Wall newWall;
		//Room newRoom = new Room();
		//GraphNodeCollector nodeCollector = GraphNodeCollector.getInstance();
				
		RoomImportTemp newRoom = new RoomImportTemp();
		
		ArrayList<RoomImportTemp> roomImportTemp = new ArrayList<RoomImportTemp>();
		
		File xmlFile = new File("simulationWorld.xml");
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(xmlFile);
			
			
			NodeList roomsList = document.getElementsByTagName("rooms");
			Node roomsNode = roomsList.item(0);
			Element roomsElem = (Element) roomsNode;
			
			NodeList roomList = roomsElem.getElementsByTagName("room");
			
			for (int roomIndx = 0; roomIndx < roomList.getLength(); ++roomIndx) {
				newRoom = new RoomImportTemp();
				Node room = roomList.item(roomIndx);

				String roomId =  ((Element) room).getElementsByTagName("roomid").item(0).getTextContent().trim();
				NodeList wallList = ((Element)room).getElementsByTagName("wall");
				newRoom.setRoomId(roomId);

				//ArrayList<WallImportTemp> wallsToAdd = new ArrayList<WallImportTemp>();
				for (int wallIndx = 0; wallIndx < wallList.getLength(); ++wallIndx) {
					//wallsToAdd = new ArrayList<Wall>();
					Node wall = wallList.item(wallIndx);
					Element wallElem = (Element) wall;
					NodeList compList = wall.getChildNodes();

					NodeList pointList = wallElem.getElementsByTagName("point");

					
					Element pointElement = (Element)pointList.item(0);
					Integer xCoord = Integer.parseInt(pointElement.getElementsByTagName("xcoord").item(0).getTextContent().trim());
					Integer yCoord = Integer.parseInt(pointElement.getElementsByTagName("ycoord").item(0).getTextContent().trim());
					
					Point p1_temp = new Point(xCoord, yCoord);
					

					Element pointElement2 = (Element)pointList.item(1);
					Integer xCoord2 = Integer.parseInt(pointElement2.getElementsByTagName("xcoord").item(0).getTextContent().trim());
					Integer yCoord2 = Integer.parseInt(pointElement2.getElementsByTagName("ycoord").item(0).getTextContent().trim());
					
					Point p2_temp = new Point(xCoord2, yCoord2);
					
					
					//newWall = WallFactory.getWallWithPoints(p1_temp, p2_temp);
					WallImportTemp newWall = new WallImportTemp(p1_temp, p2_temp);

					Node door = wallElem.getElementsByTagName("door").item(0);
					if (door != null) {
						DoorImportTemp door_temp = null;
						Element doorElem = (Element) door;

						String doorid = doorElem.getElementsByTagName("doorid").item(0).getTextContent().trim();
						String doorsize = doorElem.getElementsByTagName("doorsize").item(0).getTextContent().trim();
						String doorX = doorElem.getElementsByTagName("xcoord").item(0).getTextContent().trim();
						String doorY = doorElem.getElementsByTagName("ycoord").item(0).getTextContent().trim();

						door_temp = new DoorImportTemp(doorid, Integer.parseInt(doorX), Integer.parseInt(doorY), Integer.parseInt(doorsize));
						newWall.addDoor(door_temp);
					}
					//wallsToAdd.add(newWall);
					newRoom.addWall(newWall);
				}
				newRoom.orderWalls();
				roomImportTemp.add(newRoom);
			}
		} catch (ParserConfigurationException e) {e.printStackTrace();} 
		catch (SAXException e) {e.printStackTrace();} 
		catch (IOException e) {e.printStackTrace();}
		
		//roomImportTemp = orderRooms((ArrayList<RoomImportTemp>) roomImportTemp.clone());

		for (int i = 0; i < roomImportTemp.size(); ++i){
			RoomImportTemp currentRoom = roomImportTemp.get(i);
			Room roomToAdd = new Room();
			ArrayList<Point2D> orderedPoints = new ArrayList<Point2D>();
			roomToAdd.setIdentifier(currentRoom.getRoomId());
			
			ArrayList<WallImportTemp> currentRoomWalls = currentRoom.getAllWalls();
			for (int j = 0; j < currentRoomWalls.size(); ++j){

				WallImportTemp currentWall = currentRoomWalls.get(j);
				Wall wallToAdd = WallFactory.getWallWithPoints(currentWall.getStartPoint(), currentWall.getEndPoint());
				orderedPoints.add(currentWall.getStartPoint());
				
				ArrayList<DoorImportTemp> currentDoors = currentWall.getAllDoors();
				
				for(int k = 0; k < currentDoors.size(); ++k){

					DoorImportTemp currentDoor = currentDoors.get(k);

					String doorId = currentDoor.getDoorId();
					int doorX_Coord = currentDoor.getXCoord();
					int doorY_Coord = currentDoor.getYCoord();
					int doorSize = currentDoor.getDoorSize();

					Door doorToAdd = new Door(doorId, doorX_Coord, doorY_Coord, doorSize);

					wallToAdd.addDoor(doorToAdd);
					//Point2D newGraphNodePoint = new Point2D.Double();
					//newGraphNodePoint.setLocation(doorX_Coord, doorY_Coord);
					
					//System.out.println("Door ID: " + doorId);
					//System.out.println("Node Point ID: " + newGraphNodePoint);
					//System.out.println("=======================================");
					//System.out.println("Room");
					//GraphNode newGraphNode = new GraphNode(doorId, newGraphNodePoint);
					//newGraphNode.setIntIdentifier(nodeCollector.getAll().size());
					//nodeCollector.newGraphNode(newGraphNode);
				}
				
				roomToAdd.addWall(wallToAdd);
			}
			roomToAdd.setOrderedWalls(orderedPoints);
			RoomCollector.getInstance().newRoom(roomToAdd);
		}
		//System.out.println(nodeCollector.getAll().size());
		
	}
	
	
	public static ArrayList<RoomImportTemp> orderRooms(ArrayList<RoomImportTemp> rooms){
		ArrayList<RoomImportTemp> orderedRooms = new ArrayList<RoomImportTemp>();
		
		if (rooms.size() > 0){
			RoomImportTemp currentRoom = rooms.get(0);
			rooms.remove(0);
			orderedRooms.add(currentRoom);
			
			
			ArrayList<WallImportTemp> addedWalls = new ArrayList<WallImportTemp>();
			addedWalls.addAll(currentRoom.getAllWalls());
			
			while(rooms.size() > 0){
				
				// find a room which has adjacent wall with the current room
				
				//****** create a list of walls from already ordered rooms
				
				boolean adjRoomFound = false;
				
				// iterate through unordered rooms
				for(int i = 0; ((i < rooms.size()) && (!adjRoomFound)); ++i){
					RoomImportTemp candidateRoom = rooms.get(i);
					ArrayList<WallImportTemp> wallsCandidateRooms = candidateRoom.getAllWalls();
					
					// iterate through walls from unordered current room
					for(int j = 0; j < wallsCandidateRooms.size(); ++j){
						WallImportTemp currentCandidateWall = wallsCandidateRooms.get(j);
						Point2D currentCandidateWallStartPoint = currentCandidateWall.getStartPoint();
						Point2D currentCandidateWallEndPoint = currentCandidateWall.getEndPoint();
						
						// iterate through ordered walls and search for a match
						for (int k = 0; ((k < addedWalls.size()) && (!adjRoomFound)); ++k){
							WallImportTemp orderedWall = addedWalls.get(k);
							Point2D orderedWallStartPoint = orderedWall.getStartPoint();
							Point2D orderedWallEndPoint = orderedWall.getEndPoint();
							// check if the room start and end points match
							if ((currentCandidateWallStartPoint.getX() == orderedWallStartPoint.getX()) && 
									(currentCandidateWallStartPoint.getY() == orderedWallStartPoint.getY()) &&
									(currentCandidateWallEndPoint.getX() == orderedWallEndPoint.getX()) && 
									(currentCandidateWallEndPoint.getY() == orderedWallEndPoint.getY())){
								//System.out.println("Candidate Wall Found");
								orderedRooms.add(candidateRoom);
								addedWalls.addAll(candidateRoom.getAllWalls());
								rooms.remove(candidateRoom);
								
								adjRoomFound = true;
							}
							// if not check if the start matches with end and end matches with start (reverse order) 
							else if ((currentCandidateWallStartPoint.getX() == orderedWallEndPoint.getX()) && 
									(currentCandidateWallStartPoint.getY() == orderedWallEndPoint.getY()) &&
									(currentCandidateWallEndPoint.getX() == orderedWallStartPoint.getX()) && 
									(currentCandidateWallEndPoint.getY() == orderedWallStartPoint.getY())){
								
								
//								for (int u = 0; u < candidateRoom.getAllWalls().size(); ++u) System.out.println("\t\t\t" + candidateRoom.getAllWalls().get(u).getStartPoint() + "<=>" + candidateRoom.getAllWalls().get(u).getEndPoint());
								
								ArrayList<WallImportTemp> walls_temp = candidateRoom.getAllWallsReversed();
								candidateRoom.setAllWalls(walls_temp);
								orderedRooms.add(candidateRoom);
								addedWalls.addAll(candidateRoom.getAllWalls());
								rooms.remove(candidateRoom);
								adjRoomFound = true;
								
								//for (int u = 0; u < candidateRoom.getAllWalls().size(); ++u)System.out.println("\t\t\t" + candidateRoom.getAllWalls().get(u).getStartPoint() + "<=>" + candidateRoom.getAllWalls().get(u).getEndPoint());
								
							}
								
								
						}
					}
					
				}
				
			}
			
			
		}
		return orderedRooms;
	} 
	
	public static void generateRoomGraphs(){
		RoomCollector rc = RoomCollector.getInstance();
		
		for (Room r: rc.getAll()){
			r.generateRoomGraph();
		}
		
		//System.out.println("Room Graph is enerated");
	}
}
