/*  	CASi Context Awareness Simulation Software
* 	Author:			Alexandr Petcovici
* 	Date: 			August 26th
* 	
*/
package de.uniluebeck.imis.casi.generator;

import java.util.HashSet;
import java.util.Set;
import java.util.logging.Logger;

import de.uniluebeck.imis.casi.simulation.model.AbstractInteractionComponent;
import de.uniluebeck.imis.casi.simulation.model.Location;

public class LocationCollector {
	
	/**
	 * Logging is useful for developers.
	 */
	private static final Logger log = Logger.getLogger(LocationCollector.class
			.getName());
	
	/** The instance of this singleton */
	private static LocationCollector instance;

	/**
	 * The List of already created agents.
	 */
	private Set<AbstractInteractionComponent> alreadyCreatedLocations = new HashSet<AbstractInteractionComponent>();
	
	/**
	 * The private constructor of this singleton
	 */
	private LocationCollector() {
		// just here for prohibiting external access
	}

	/**
	 * Getter for the instance of this singleton
	 * 
	 * @return the instance
	 */
	public static LocationCollector getInstance() {
		if (instance == null) {
			instance = new LocationCollector();
		}
		return instance;
	}

	/**
	 * Add a new component to this collection
	 * 
	 * @param l
	 *            the new Component
	 */
	public void newLocation(Location l) {
		alreadyCreatedLocations.add(l);
	}

	/*
	public void printAllLocations() {
		for (AbstractInteractionComponent comp : alreadyCreatedLocations) System.out.println(comp.getIdentifier());
	}*/
	
	/**
	 * Returns an Component with a given identifier
	 * 
	 * @param identifierToLookFor
	 * @return the Component with this name or (CAUTION) null if this component cannot
	 *         be found!
	 */
	public AbstractInteractionComponent findLocationByIdentifier(String identifierToLookFor) {
		for (AbstractInteractionComponent comp : alreadyCreatedLocations) {
			
			if (comp.getIdentifier().equals(identifierToLookFor)) {
				return comp;
			}
		}
		log.warning(String.format("couldn't find component %s, mispelled it?", identifierToLookFor));
		return null;
	}

	/**
	 * Getter for the list of agents
	 * 
	 * @return the Vector with all the agents
	 */
	public Set<AbstractInteractionComponent> getAll() {
		return alreadyCreatedLocations;
	}


}
