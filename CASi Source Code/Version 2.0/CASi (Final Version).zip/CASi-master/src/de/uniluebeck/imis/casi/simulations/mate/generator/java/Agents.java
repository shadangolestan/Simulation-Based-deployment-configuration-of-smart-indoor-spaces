/*  	CASi Context Awareness Simulation Software
 *   Copyright (C) 2012 2012  Moritz Bürger, Marvin Frick, Tobias Mende
 *
 *  This program is free software. It is licensed under the
 *  GNU Lesser General Public License with one clarification.
 *  
 *  You should have received a copy of the 
 *  GNU Lesser General Public License along with this program. 
 *  See the LICENSE.txt file in this projects root folder or visit
 *  <http://www.gnu.org/licenses/lgpl.html> for more details.
 *  
 *  
 *  *  ==================================================================
 *  Changed By: 		Alexandr Petcovici
 *  Date:				26-Aug-2016
 *  Description:		Read simulationWorld.xml and creates agents 
 *  					based on it content
 *  ==================================================================
 */
package de.uniluebeck.imis.casi.simulations.mate.generator.java;

import java.awt.Point;
import java.awt.geom.Point2D;
import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import de.uniluebeck.imis.casi.generator.AgentCollector;
import de.uniluebeck.imis.casi.generator.ComponentCollector;
import de.uniluebeck.imis.casi.generator.LocationCollector;
import de.uniluebeck.imis.casi.generator.RoomCollector;
import de.uniluebeck.imis.casi.simulation.model.Agent;
import de.uniluebeck.imis.casi.simulation.model.ConfigMap;
import de.uniluebeck.imis.casi.simulation.model.IPosition;
import de.uniluebeck.imis.casi.simulation.model.Location;

/**
 * Agent generator file with static methods that generate all the agents for
 * MATe simulation environment World.
 * 
 * Put all your agents in here!
 * 
 * @author Marvin Frick
 * 
 */
public class Agents {

	/**
	 * Fills the AgentsGenerator singleton object with all the agents.
	 * 
	 * Put all your Agents here!
	 */
	public static void generateAgents(ComponentCollector compoentC) {

		AgentCollector agentC = AgentCollector.getInstance();
		RoomCollector rooms = RoomCollector.getInstance();
		Agent tempAgent = null;
		LocationCollector locationC = LocationCollector.getInstance();

		File xmlFile = new File("simulationWorld.xml");
		
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(xmlFile);
			
			NodeList agentsList = document.getElementsByTagName("agents");
			Node agentsNode = agentsList.item(0);
			Element agentsElem = (Element) agentsNode;
			
			NodeList agentList = agentsElem.getElementsByTagName("agent");
			
			for (int agentIndx = 0; agentIndx < agentList.getLength(); ++agentIndx)
			{
				Node agent = agentList.item(agentIndx);
				Element agentElem = (Element) agent;
				String agentId = agentElem.getElementsByTagName("agentid").item(0).getTextContent().trim();
				String agentName = agentElem.getElementsByTagName("agentname").item(0).getTextContent().trim();
				String agentRole = agentElem.getElementsByTagName("agentrole").item(0).getTextContent().trim();
					
				Element pointElement = (Element)agentElem.getElementsByTagName("point").item(0);
				Integer xCoord = Integer.parseInt(pointElement.getElementsByTagName("xcoord").item(0).getTextContent().trim());
				Integer yCoord = Integer.parseInt(pointElement.getElementsByTagName("ycoord").item(0).getTextContent().trim());
				
				Point point = new Point(xCoord, yCoord);
				Point2D pTemp = new Point2D.Double(point.getX(), point.getY());
				Location newLocation = new Location("location-" + agentId, pTemp);
				newLocation.setCoordinates(pTemp);
				locationC.newLocation(newLocation);
				
				tempAgent = new Agent(agentId, agentName, agentRole, newLocation, 36.6, 85, 10);
				agentC.newAgent(tempAgent);

			}

		} 
		catch (ParserConfigurationException e) {e.printStackTrace();} 
		catch (SAXException e) {e.printStackTrace();} 
		catch (IOException e) {e.printStackTrace();}

		/*
		 * // if we need a lot of agents... for (int i = 0; i < 0; i++) {
		 * tempAgent = new Agent("agent_" + i + "_smith", "A. Smith the " + i,
		 * "crowd"); agentC.newAgent(tempAgent); }
		 * 
		 * // ########## // Hermann Matsumbishi // ########## tempAgent = new
		 * Agent("casi_hermann_matsumbishi", "Hermann Matsumbishi",
		 * "teamleader"); tempAgent.setDefaultPosition(rooms
		 * .findRoomByIdentifier("officeHermann")); agentC.newAgent(tempAgent);
		 * 
		 * // ########## // Zwotah Zwiebel // ########## agentC.newAgent(new
		 * Agent("casi_zwotah_zwiebel", "Zwotah Zwiebel", "coworker")); Agent
		 * zwotah = agentC.findAgentByName("Zwotah Zwiebel");
		 * zwotah.setDefaultPosition(rooms.findRoomByIdentifier("officeZwotah"))
		 * ; // zwotah is very attentive, he turns his cube more nearly every
		 * time zwotah.addConfiguration(ConfigMap.TURN_CUBE_PROBABILITY, 0.9);
		 * 
		 * // ########## // Dagobert Dreieck // ########## tempAgent = new
		 * Agent("casi_dagobert_dreieck", "Dagobert Dreieck", "coworker");
		 * tempAgent.setDefaultPosition(rooms
		 * .findRoomByIdentifier("officeDagobert")); agentC.newAgent(tempAgent);
		 * 
		 * // ########## // Felix Freudentanz // ########## tempAgent = new
		 * Agent("casi_felix_freudentanz", "Felix Freudentanz", "teamLeader");
		 * tempAgent.setDefaultPosition(rooms.findRoomByIdentifier("officeFelix"
		 * )); // Felix moves very fast!
		 * tempAgent.addConfiguration(ConfigMap.MOVE_SPEED, 1.5);
		 * agentC.newAgent(tempAgent);
		 * 
		 * // ########## // Susi Sekretärin // ########## tempAgent = new
		 * Agent("casi_susi_sekretärin", "Susi Sekretärin", "secretary");
		 * tempAgent.setDefaultPosition(rooms.findRoomByIdentifier("officeSusi")
		 * ); agentC.newAgent(tempAgent);
		 * 
		 * // ########## // Rudi Random // ########## tempAgent = new
		 * Agent("casi_rudi_random", "Rudi Random", "coworker");
		 * tempAgent.setDefaultPosition(rooms.findRoomByIdentifier("officeRudi")
		 * ); agentC.newAgent(tempAgent);
		 */
	}
}
