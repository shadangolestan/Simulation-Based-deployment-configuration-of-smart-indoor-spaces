/**
 * This package contains factories that facilitate some awkward tasks that we need to do round about n times ;)
 */
package de.uniluebeck.imis.casi.simulation.factory;

