/*  	CASi Context Awareness Simulation Software
* Author: 		Alexandr Petcovici
* Date: 		10-December-2016
* Description:  This class is collector for activity schedules
*/
package de.uniluebeck.imis.casi.generator;
import java.util.HashMap;
import de.uniluebeck.imis.casi.simulation.model.ActivitySchedule;

public class ActivityScheduleCollector {
	

	private static ActivityScheduleCollector instance;

	private HashMap<String, ActivitySchedule> alreadyCreatedActScheduler = new HashMap<String, ActivitySchedule>();


	private ActivityScheduleCollector() {
		// just here for prohibiting external access
	}

	public static ActivityScheduleCollector getInstance() {
		if (instance == null) {
			instance = new ActivityScheduleCollector();
		}
		return instance;
	}

	public void newActSched(String identifier, ActivitySchedule newSchedule) {
		alreadyCreatedActScheduler.put(identifier, newSchedule);
	}


	public HashMap<String, ActivitySchedule> getAlreadyScheduledActivities() {
		return alreadyCreatedActScheduler;
	}

}
