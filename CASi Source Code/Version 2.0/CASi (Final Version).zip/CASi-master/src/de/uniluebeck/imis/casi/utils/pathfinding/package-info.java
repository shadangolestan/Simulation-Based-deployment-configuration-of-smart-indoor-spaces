/**
 * This package contains the basic A<sup>*</sup> algorithm and some implementations that are used for path finding.
 */
package de.uniluebeck.imis.casi.utils.pathfinding;

