/*  	CASi Context Awareness Simulation Software
* Author: 		Alexandr Petcovici
* Date: 		10-December-2016
* Description:  This class represents activity Instance
*/
package de.uniluebeck.imis.casi.simulation.model;

import java.util.ArrayList;

public class ActivityInstance {
	
	String actInstName;
	ArrayList<String> subActIDs;
	ArrayList<String> subActTargets;
	ArrayList<String> subActParameters;
	
	
	public ActivityInstance(String actInstName){
		this.actInstName = actInstName;
		subActIDs = new ArrayList<String>();
		subActTargets = new ArrayList<String>();
		subActParameters = new ArrayList<String>();
	}
	
	public void addSubActInst (String id, String target, String parameter){
		subActIDs.add(id);
		subActTargets.add(target);
		subActParameters.add(parameter);
	}
	
	public void removeSubActInstById(String id){
		boolean found  = false;
		for(int i = 0; ((i < this.subActIDs.size()) && (!found)); ++i){
			if (this.subActIDs.get(i).equals(id))
			{
				found = true;
				
				subActTargets.remove(i);
				subActIDs.remove(i);
				subActParameters.remove(i);
			}
		}
		
	}
	
	public void removeSubActInstByIndex(int i)
	{
		subActTargets.remove(i);
		subActIDs.remove(i);
		subActParameters.remove(i);
	}
	
	
	public String getSubActIDByIndex(int i) {return subActIDs.get(i);}
	public String getSubActTargetByIndex(int i) {return subActTargets.get(i);}
	public String getSubActParameterByIndex(int i) {return subActParameters.get(i);}
	
	public int getIndexBySubAct(String id){
		for(int i = 0; i < this.subActIDs.size(); ++i)
			if (this.subActIDs.get(i).equals(id))
				return i;
		
			return -1;
	}
	
	public ArrayList<String> getActivityIDs(){return this.subActIDs;}
	
	public String getID(){return this.actInstName;}

}
