/**
 * Package contains the interfaces and implementations for external communication.
 */
package de.uniluebeck.imis.casi.communication;

