/*  	CASi Context Awareness Simulation Software
*		Author: 		Alexandr Petcovici
*		Date: 			27-Aug-2016
*		Description: 	Obstacle Collector: Stores all obstacles.
*						Created on the base on RoomCollector
*/
package de.uniluebeck.imis.casi.generator;

import java.util.HashSet;
import java.util.Set;
import java.util.logging.Logger;

import de.uniluebeck.imis.casi.simulation.model.Door;
import de.uniluebeck.imis.casi.simulation.model.Obstacle;
import de.uniluebeck.imis.casi.simulation.model.Room;


public class ObstacleCollector {
	
	/**
	 * Logging is useful for developers.
	 */
	private static final Logger log = Logger.getLogger(ObstacleCollector.class
			.getName());
	/** The instance of this singleton */
	private static ObstacleCollector instance;

	/**
	 * The List of already created agents.
	 */
	private Set<Obstacle> alreadyCreatedObstacles = new HashSet<Obstacle>();

	/**
	 * The private constructor of this singleton
	 */
	private ObstacleCollector() {
		// just here for prohibiting external access
	}

	/**
	 * Getter for the instance of this singleton
	 * 
	 * @return the instance
	 */
	public static ObstacleCollector getInstance() {
		if (instance == null) {
			instance = new ObstacleCollector();
		}
		return instance;
	}

	/**
	 * Add a new room to this collection
	 * 
	 * @param newRoom
	 *            the new Room
	 */
	public void newObstacle(Obstacle obstacle) {
		alreadyCreatedObstacles.add(obstacle);
	}

	/**
	 * Returns an Room with a given identifier
	 * 
	 * @param identifierToLookFor
	 * @return the Room with this name or (CAUTION) null if this room cannot be
	 *         found!
	 */
	public Obstacle findObstacleByIdentifier(String identifierToLookFor) {
		for (Obstacle obstacle : alreadyCreatedObstacles) {
			if (obstacle.getIdentifier().equals(identifierToLookFor)) {
				return obstacle;
			}
		}
		log.warning(String.format("couldn't find room %s, mispelled it?", identifierToLookFor));
		return null;
	}


	/**
	 * Getter for the list of Rooms
	 * 
	 * @return the Vector with all the Rooms
	 */
	public Set<Obstacle> getAll() {
		return alreadyCreatedObstacles;
	}

}
