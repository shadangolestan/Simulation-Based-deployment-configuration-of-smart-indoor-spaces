/*  	CASi Context Awareness Simulation Software
 *   Copyright (C) 2012  Moritz Bürger, Marvin Frick, Tobias Mende
 *
 *  This program is free software. It is licensed under the
 *  GNU Lesser General Public License with one clarification.
 *  
 *  You should have received a copy of the 
 *  GNU Lesser General Public License along with this program. 
 *  See the LICENSE.txt file in this projects root folder or visit
 *  <http://www.gnu.org/licenses/lgpl.html> for more details.
 *  
 *  
 *  
 *  =================================================================
 *  Changed By: 			Alexandr Petcovici
 *  Change Date:			26-Aug-2016
 *  Description:			Reads the simulation date and time 
 *  =================================================================
 */
package de.uniluebeck.imis.casi.simulations.mate.generator.java;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.logging.Logger;

import javax.imageio.ImageIO;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import de.uniluebeck.imis.casi.CASi;
import de.uniluebeck.imis.casi.generator.AgentCollector;
import de.uniluebeck.imis.casi.generator.ComponentCollector;
import de.uniluebeck.imis.casi.generator.IWorldGenerator;
import de.uniluebeck.imis.casi.generator.Linker;
import de.uniluebeck.imis.casi.generator.LocationCollector;
import de.uniluebeck.imis.casi.generator.ObstacleCollector;
import de.uniluebeck.imis.casi.generator.RoomCollector;
import de.uniluebeck.imis.casi.simulation.model.AbstractComponent;
import de.uniluebeck.imis.casi.simulation.model.Door;
import de.uniluebeck.imis.casi.simulation.model.Room;
import de.uniluebeck.imis.casi.simulation.model.SimulationTime;
import de.uniluebeck.imis.casi.simulation.model.World;

/**
 * Generates the specific MATe simulation environment World. All sub actions are
 * delegated to their Generators. I should be not necessary to change this class
 * for adding new aspects of this world. Put your changes in the specific
 * Classes! Do not remove the implementation of {@link IWorldGenerator}, this is
 * needed. The simulator expects {@link IWorldGenerator#generateWorld()}.
 * 
 * @author Marvin Frick
 * 
 */
public class WorldGenerator implements IWorldGenerator {

	/**
	 * The name of this simulation.
	 * Used for prefixing many things.
	 */
	private static String SIMULATION_NAME = "MATe Demo Simulation";

	/**
	 * The logger for developing purposes.
	 */
	private static final Logger log = Logger.getLogger(WorldGenerator.class
			.getName());

	/**
	 * The new world object that we're going to fill
	 */
	World tempWorld = new World();
	
	/**
	 * shortcut for the singleton RoomCollector
	 */
	RoomCollector rooms = RoomCollector.getInstance();
	
	/**
	 * shortcut for the singleton AgentCollector
	 */
	AgentCollector agents = AgentCollector.getInstance();
	
	/**
	 * locations
	 */
	LocationCollector locations = LocationCollector.getInstance();
	
	ObstacleCollector obstacles = ObstacleCollector.getInstance();
	
	/**
	 * This generator creates an basic, pre coded World object
	 * 
	 * @throws Exception
	 *             In this particular generator the Exception is less useful,
	 *             this comes from {@link IWorldGenerator} which is used by the
	 *             more specialized generators.
	 * @return {@link World}
	 */
	@Override
	public World generateWorld() {
		BufferedImage image = null;
		try {
			image = ImageIO
					.read(new File("sims/dev_office_java/backround.png"));
		} catch (IOException e) {
			log.severe("Can't read image: " + e.fillInStackTrace());
		}

		// giant try block around everything that actually sets things to the
		// world

		try {
			tempWorld.setStartTime(new SimulationTime("4/23/2013 09:00:42"));
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			
			
			File xmlFile = new File("simulationWorld.xml");
			
			try {
				DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
				Document document = documentBuilder.parse(xmlFile);
				
				
				NodeList simStartTimeList = document.getElementsByTagName("sim_start_time");
				Node simStartTimeNode = simStartTimeList.item(0);
				Element simStartTimeElem = (Element) simStartTimeNode;
				
				//2016-08-24
				String simStartDate = simStartTimeElem.getElementsByTagName("simStartDate").item(0).getTextContent().trim();
				String simStartTime = simStartTimeElem.getElementsByTagName("simStartTime").item(0).getTextContent().trim();
				
				if ((simStartDate != null) && (!simStartDate.equals("")) && (simStartTime != null) && (!simStartTime.equals(""))){
					//2016-08-24
					String[] startDateArr =  simStartDate.split("-");
					if (startDateArr.length != 3) throw new Exception("Wrong Start Day");
					
					String simStartYear = startDateArr[0];
					String simStartMonth = startDateArr[1];
					String simStartDay = startDateArr[2];
					
					String simStartDateStr = simStartMonth + "/" + simStartDay + "/" + simStartYear; 
					
					String[] startTimeArr =  simStartTime.split(":");
					if (startTimeArr.length != 3) throw new Exception("Wring Start Time");
					
					//String simStartHour = startDateArr[0];
					//String simStartMinutes = startDateArr[1];
					//String simStartSecinds = startDateArr[2];
					
					
					tempWorld.setStartTime(new SimulationTime(simStartDateStr + " " + simStartTime));
					
				}
			
			} catch (ParserConfigurationException e) {e.printStackTrace();} 
			catch (SAXException e) {e.printStackTrace();} 
			catch (IOException e) {e.printStackTrace();}
				
			tempWorld.setBackgroundImage(image);
			
			Rooms.generateRooms();
			
			Obstacles.generateObstacles();

			
			Rooms.generateRoomGraphs();
			
			
			Components.fillOfficesWithDesktopThings();
			
			
			Components.addLightsAndSensorsToDoors();
			Components.generateActuators();
			Components.generateSensors();
			Locations.addRoomsAsLocations();
			Locations.addCompoentsAsLocations();
			Locations.addLocationsFromXML();

			ActivityDefinitions.addActivityDefinitionsFromXML();
			ActivityInstances.addActivityInstancesFromXML();
			
			ActivitySchedules.addActivitySchedulesFromXML();
			
			Agents.generateAgents(ComponentCollector.getInstance());

			//Actions.generateActions(tempWorld.getStartTime());
			//Actions.generateActionsPools(tempWorld.getStartTime());

			Actions.generateSchedActions();
			
			Linker linker = new Linker();
			linker.linkAll();

			tempWorld.setComponents(new HashSet<AbstractComponent>());
		} catch (IllegalAccessException e) {
			log.severe("Illegal Access:" + e.fillInStackTrace());
		} catch (ParseException e) {
			log.severe("Parse Exception:" + e.fillInStackTrace());
		} catch (Exception e) {
			log.severe("Unknown Exception: " + e.fillInStackTrace());
		}
		finalizeWorld();
		return tempWorld;
	}

	/**
	 * Finalizes this world.
	 */
	private void finalizeWorld() {
		// assure: no null defaultRooms
		AgentCollector.getInstance().fillAllAgentsWithDefaultRoom();

		try {
			tempWorld.setRooms(RoomCollector.getInstance().getAll());
			tempWorld.setAgents(AgentCollector.getInstance().getAll());
			tempWorld.setInteractionComponents(ComponentCollector.getInstance()
					.getAll());
			//tempWorld.setObstacles(ObstacleCollector.getInstance().getAll());
			tempWorld.setLocations(LocationCollector.getInstance().getAll());
			for (Room room : RoomCollector.getInstance().getAll()) 
			{
				ArrayList<Door> doors = new ArrayList<Door>(room.getDoors());
			}
		} catch (IllegalAccessException e) {
			// World seems to be already sealed!
			log.severe("could not set the world. It is already sealed!");
		}

	}
}
