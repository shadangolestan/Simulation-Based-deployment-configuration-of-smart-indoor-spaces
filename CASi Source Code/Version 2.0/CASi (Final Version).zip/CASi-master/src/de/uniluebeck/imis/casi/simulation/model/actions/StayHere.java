/*  	CASi Context Awareness Simulation Software
 *   Copyright (C) 2012 2012  Moritz Bürger, Marvin Frick, Tobias Mende
 *
 *  This program is free software. It is licensed under the
 *  GNU Lesser General Public License with one clarification.
 *  
 *  You should have received a copy of the 
 *  GNU Lesser General Public License along with this program. 
 *  See the LICENSE.txt file in this projects root folder or visit
 *  <http://www.gnu.org/licenses/lgpl.html> for more details.
 *  
 *  
 *  Change Date: 26-Aug-2016: Added logign of the current action
 *  to MQTT Server and file log
 *  
 */
package de.uniluebeck.imis.casi.simulation.model.actions;

import de.uniluebeck.imis.casi.CASi;
import de.uniluebeck.imis.casi.communication.comLogger.MQTTEventLogger;
import de.uniluebeck.imis.casi.simulation.engine.SimulationClock;
import de.uniluebeck.imis.casi.simulation.model.AbstractComponent;
import de.uniluebeck.imis.casi.simulation.model.Agent;
import de.uniluebeck.imis.casi.simulation.model.actionHandling.AtomicAction;

/**
 * The Agent stays at his current position and does _nothing_ for the given
 * time.
 * 
 * @author Marvin Frick
 */
public class StayHere extends AtomicAction {

	String parentAction;
	/**
	 * serialization identifier
	 */
	private static final long serialVersionUID = 8981370022973052710L;

	/**
	 * Creates a new boring StayHere Action.
	 * 
	 * @param duration
	 *            how long should the agent do nothing
	 * @param prio
	 *            at what priority should the agent to nothing
	 */
	public StayHere(int duration, int prio, String parentAction) {
		this.setPriority(prio);
		this.setDuration(duration);
		this.parentAction = parentAction;
	}

	@Override
	protected boolean internalPerform(AbstractComponent performer) {
		// nothing to do here
		CASi.SIM_LOG.info(SimulationClock.getInstance().getCurrentTime().getTime() + "," + 
				this.parentAction + "/" + this.getClass().getSimpleName() + "," + performer.getIdentifier() + ",[" +  
				performer.getCoordinates().getX() + "," + performer.getCoordinates().getY() + "]");
	
		MQTTEventLogger.getInstance().publishMQTT("casiSimulator/action_reeding/" + ((Agent)performer).getAgentRole() + "/" + performer.getIdentifier() + "/" + 
				this.parentAction + "/" + this.getClass().getSimpleName()
				, (SimulationClock.getInstance().getCurrentTime().getTime() + ",[" +  performer.getCoordinates().getX() + "," + performer.getCoordinates().getY() + "]"));

		return false;
	}

	@Override
	public String getInformationDescription() {
		return "stay here and do nothing";
	}

}
