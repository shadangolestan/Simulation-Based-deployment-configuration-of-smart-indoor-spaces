package de.uniluebeck.imis.casi.simulations.mate.generator.java;

import java.awt.Point;
import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import de.uniluebeck.imis.casi.generator.AgentCollector;
import de.uniluebeck.imis.casi.generator.ComponentCollector;
import de.uniluebeck.imis.casi.generator.RoomCollector;
import de.uniluebeck.imis.casi.simulation.model.AbstractInteractionComponent.Face;
import de.uniluebeck.imis.casi.simulation.model.Agent;
import de.uniluebeck.imis.casi.simulation.model.Door;
import de.uniluebeck.imis.casi.simulation.model.Room;
import de.uniluebeck.imis.casi.simulation.model.mackComponents.Cube;
import de.uniluebeck.imis.casi.simulation.model.mackComponents.Desktop;
import de.uniluebeck.imis.casi.simulation.model.mackComponents.DoorLight;
import de.uniluebeck.imis.casi.simulation.model.mackComponents.DoorSensor;
import de.uniluebeck.imis.casi.simulation.model.mackComponents.Mike;
import sensors.MotionSensorAnalog;
import sensors.MotionSensorBinary;
import sensors.PressureSensorAnalog;


public class SensorLoader {

	public static void fillOfficesWithDesktopThings(String filePath) {
		
		try{
			File xmlFile = new File(filePath);
			DocumentBuilderFactory documentBuilderFactorySensors = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilderSensors = documentBuilderFactorySensors.newDocumentBuilder();
			Document documentSensors = documentBuilderSensors.parse(xmlFile);
			
			NodeList sensorsList = documentSensors.getElementsByTagName("sensors");
			Node sensorsNode = sensorsList.item(0);
			Element sensorsElem = (Element) sensorsNode;
						
			NodeList sensorList = sensorsElem.getElementsByTagName("sensor");
			
			for (int sensorIndx = 0; sensorIndx < sensorList.getLength(); ++sensorIndx)
			{
				Node sensor = sensorList.item(sensorIndx);
				Element sensorElem = (Element) sensor;
				
				String[] pointArr = sensorElem.getElementsByTagName("point").item(0).getTextContent().trim().split(" ");
				
				String sensorType = sensorElem.getElementsByTagName("type").item(0).getTextContent().trim();
				int sensrorRadius = Integer.parseInt(sensorElem.getElementsByTagName("radius").item(0).getTextContent().trim());
				String sensorID = sensorElem.getElementsByTagName("id").item(0).getTextContent().trim();
				
			}
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();}
	}
}
