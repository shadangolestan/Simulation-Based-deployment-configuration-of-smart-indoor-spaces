/*  	
 * Author: Alexandr Petcovici
 * Date: 26-Aug-2016 Added loggign of the current action
 *  to MQTT Server and file log
 */
package de.uniluebeck.imis.casi.simulation.model.actions;

import java.awt.geom.Area;
import java.awt.geom.Point2D;

import de.uniluebeck.imis.casi.CASi;
import de.uniluebeck.imis.casi.communication.comLogger.MQTTEventLogger;
import de.uniluebeck.imis.casi.generator.ComponentCollector;
import de.uniluebeck.imis.casi.simulation.engine.SimulationClock;
import de.uniluebeck.imis.casi.simulation.model.AbstractComponent;
import de.uniluebeck.imis.casi.simulation.model.Agent;
import de.uniluebeck.imis.casi.simulation.model.actionHandling.AtomicAction;
import objectInterfaces.Pressurable;
import objectInterfaces.Wearable;

public class Sit extends AtomicAction {

	/**
	 * serialization identifier
	 */
	private static final long serialVersionUID = 8981370022973052710L;

	private String parentAction;
	
	private Sit() {
		this.setPriority(1);
	}
	
	/**
	 * Creates a new boring StayHere Action.
	 * 
	 * @param duration
	 *            how long should the agent do nothing
	 * @param prio
	 *            at what priority should the agent to nothing
	 */
	public Sit(int duration, int prio, String parentAction) {
		this.setPriority(prio);
		this.setDuration(duration);
		this.parentAction = parentAction;
	}

	@Override
	protected boolean internalPerform(AbstractComponent performer) {
		Agent agent = (Agent)performer;
		Area agentArea = new Area(performer.getShapeRepresentation());
		Point2D agentPoint = agent.getCentralPoint();

		CASi.SIM_LOG.info(SimulationClock.getInstance().getCurrentTime().getTime() + "," + 
				this.parentAction + "/" + this.getClass().getSimpleName() + "," + performer.getIdentifier() + ",[" +  
				performer.getCoordinates().getX() + "," + performer.getCoordinates().getY() + "]");

		MQTTEventLogger.getInstance().publishMQTT("casiSimulator/action_reeding/" + ((Agent)performer).getAgentRole() + "/" + performer.getIdentifier() + "/" + 
				this.parentAction + "/" + this.getClass().getSimpleName()
				, (SimulationClock.getInstance().getCurrentTime().getTime() + ",[" +  performer.getCoordinates().getX() + "," + performer.getCoordinates().getY() + "]"));

		
		ComponentCollector c = ComponentCollector.getInstance();
		
		Object[] presurableObjects = c.getAllPressurable().toArray();
		
		for(int i = 0; i < presurableObjects.length; ++i){
			Pressurable comp = (Pressurable) presurableObjects[i];
			Area pressurableObject_shape = new Area(comp.getShapeRepresentation());
			
			pressurableObject_shape.intersect(agentArea);
			if (pressurableObject_shape != null && !pressurableObject_shape.isEmpty()) 
				{comp.sensePressure(agentPoint, agent.getBodyWeight());	}
		}
		
		
		Object[] wearableObjects = c.getAllWearable().toArray();
		
		for (int wearableSensorCounter = 0; wearableSensorCounter < wearableObjects.length; wearableSensorCounter++)
		{
			Wearable comp = (Wearable) wearableObjects[wearableSensorCounter];
			Area wearableObject_shape = new Area(comp.getShapeRepresentation());
			
			wearableObject_shape.intersect(agentArea);
			if (wearableObject_shape != null && !wearableObject_shape.isEmpty()) 
				{comp.addDetectedAgent(agent);}
		}
		return false;
		
	}

	@Override
	public String getInformationDescription() {
		return "Sit";
	}

}
