/*  	CASi Context Awareness Simulation Software
* Author: 		Alexandr Petcovici
* Date: 		10-December-2016
* Description:  This class reads input file and imports activity
* 				definitions
*/
package de.uniluebeck.imis.casi.simulations.mate.generator.java;

import java.awt.Point;
import java.awt.geom.Point2D;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import de.uniluebeck.imis.casi.generator.ActivityDefinitionCollector;


/**
 * Fills the ComponentCollector with Components. Both Actuators and Sensors.
 * 
 * Put all your Components here!
 * 
 * @author Marvin Frick
 * 
 */
public class ActivityDefinitions {

/*
	public static void addRoomsAsLocations() {
		RoomCollector roomC = RoomCollector.getInstance();
		LocationCollector locationC = LocationCollector.getInstance();
		for (Room r : roomC.getAll()) {//newLocation.setCoordinates(pTemp);
			Location locTemp = new Location(r.getIdentifier(), r.getCentralPoint());
			locTemp.setCoordinates(r.getCentralPoint());
			locationC.newLocation(locTemp);
		}
		
		
	}
	public static void addCompoentsAsLocations() {
		ComponentCollector componentC = ComponentCollector.getInstance();
		LocationCollector locationC = LocationCollector.getInstance();
		for (AbstractInteractionComponent c : componentC.getAll()) 
		{
			Location locTemp = new Location(c.getIdentifier(), c.getCentralPoint());
			
			locTemp.setCoordinates(c.getCentralPoint());
			locationC.newLocation(locTemp);
		}
	}
*/	
	
	public static void addActivityDefinitionsFromXML() throws IllegalAccessException {
	
		//LocationCollector locationC = LocationCollector.getInstance();
		File xmlFile = new File("simulationWorld.xml");
		ActivityDefinitionCollector actDefCollector = ActivityDefinitionCollector.getInstance();
		
		//HashMap <String, String> actDefTemp = new HashMap <String, String>();
		
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document documentSensors = documentBuilder.parse(xmlFile);
			
			NodeList activityDefinietionList = documentSensors.getElementsByTagName("activityDefinitions");
			Node activityDefinitions = activityDefinietionList.item(0);
			Element activityDefinitionsElem = (Element) activityDefinitions;
			NodeList activityDefinitionList = activityDefinitionsElem.getElementsByTagName("activityDefinition");
			
			for (int activityDefinitionIndx = 0; activityDefinitionIndx < activityDefinitionList.getLength(); ++activityDefinitionIndx){
				Node location = activityDefinitionList.item(activityDefinitionIndx);
				Element activityDefinitionElem = (Element) location;
		
				String activityDefinitionName = activityDefinitionElem.getElementsByTagName("activityDefinitionName").item(0).getTextContent().trim();
				//System.out.println("Name: " + activityDefinitionName);
				String isComplexActDefinition = activityDefinitionElem.getElementsByTagName("isComplexActDefinition").item(0).getTextContent().trim();
				//System.out.println("Complex: " + isComplexActDefinition);
				
				Node subActivityDefinitionsParentNode = activityDefinitionElem.getElementsByTagName("SubActivityDefinitions").item(0);
				Element subActivityDefinitionsParentElement = (Element) subActivityDefinitionsParentNode;
				
				NodeList subActivityDefinitionList = subActivityDefinitionsParentElement.getElementsByTagName("SubActivityDefinition");
				
				for (int subActivityIndex = 0; subActivityIndex < subActivityDefinitionList.getLength(); ++subActivityIndex)
				{
					Node subactivityNode = subActivityDefinitionList.item(subActivityIndex);
					Element subactivityElement = (Element) subactivityNode;
					
					
					String activityID = subactivityElement.getElementsByTagName("activityID").item(0).getTextContent().trim();
					//System.out.println("\tactivityID: " + activityID);
					
					String activityType = subactivityElement.getElementsByTagName("activityType").item(0).getTextContent().trim();
					//System.out.println("\tactivityType: " + activityType);
					
					//if (!activityID.equals(activityDefinitionName)) actDefTemp.put(activityID, activityDefinitionName);
					//else actDefTemp.put(activityID, activityType);
					
					//if (!activityID.equals(activityDefinitionName)) actDefCollector.newActDef(activityID, activityDefinitionName);
					//else actDefCollector.newActDef(activityID, activityType);
					if (activityType != null) actDefCollector.newActDef(activityID, activityType);
				}

			//	System.out.println("=======================");
			}
		
		} catch (ParserConfigurationException e) {e.printStackTrace();} 
		catch (SAXException e) {e.printStackTrace();} 
		catch (IOException e) {e.printStackTrace();}
		
		

		/*
		HashMap <String, String> actDefTemp = actDefCollector.getAlreadyCreatedActDefs();
	    Iterator it = actDefTemp.entrySet().iterator();
	    while (it.hasNext()) {
	        Map.Entry pair = (Map.Entry)it.next();
	        //System.out.println(pair.getKey() + " = " + pair.getValue());
	        
	        //ArrayList<String> actionChain = actDefCollector.getParentChainArr((String)pair.getKey());
	        
	        //for(int i = 0; i < actionChain.size(); ++i) System.out.print(actionChain.get(i) + "->");
	        
	        //System.out.println("");
	        
	        System.out.println(pair.getKey() + "===>" + pair.getValue());
	        
	        it.remove(); // avoids a ConcurrentModificationException
	    }
		
		System.exit(1);
		*/
	}
}
