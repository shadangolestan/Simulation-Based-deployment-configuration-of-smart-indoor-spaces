/**
 * This package contains a generator stub which only creates an empty world and returns it.
 * It might be useful for testing until real generators are working fine.
 */
package de.uniluebeck.imis.casi.generator.stub;

