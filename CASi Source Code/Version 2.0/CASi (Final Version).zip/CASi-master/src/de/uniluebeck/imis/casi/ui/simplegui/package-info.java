/**
 * The simple gui package holds an implementation of a simple passive graphical user interface.
 */
package de.uniluebeck.imis.casi.ui.simplegui;

