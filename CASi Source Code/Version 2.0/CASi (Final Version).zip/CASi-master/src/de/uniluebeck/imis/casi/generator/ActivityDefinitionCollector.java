/*  	CASi Context Awareness Simulation Software
* Author: 		Alexandr Petcovici
* Date: 		10-December-2016
* Description:  This class is collector for activity definitions
*/
package de.uniluebeck.imis.casi.generator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import java.util.TreeSet;

public class ActivityDefinitionCollector {
	
	private Set<String> rootActions = new TreeSet<String>();
	
	
	
	/** The instance of this singleton */
	private static ActivityDefinitionCollector instance;

	/**
	 * The List of already created agents.
	 */
	private HashMap<String, String> alreadyCreatedActDefs = new HashMap<String, String>();

	/**
	 * The private constructor of this singleton
	 */
	private ActivityDefinitionCollector() {
		// just here for prohibiting external access
		rootActions.add("Move");
		rootActions.add("Sit");
		rootActions.add("SitTimer");
		rootActions.add("Stay");
		rootActions.add("StayTimer");
		rootActions.add("Turn On");
		rootActions.add("Turn Off");
		rootActions.add("Set Turn Off Timer");
	}

	/**
	 * Getter for the instance of this singleton
	 * 
	 * @return the instance
	 */
	public static ActivityDefinitionCollector getInstance() {
		if (instance == null) {
			instance = new ActivityDefinitionCollector();
		}
		return instance;
	}


	public void newActDef(String identifier, String newAction) {
		alreadyCreatedActDefs.put(identifier, newAction);
	}

	/**
	 * Simple getter that returns the HashMap of all Actions
	 * 
	 * @return all the Actions
	 */
	public HashMap<String, String> getAlreadyCreatedActDefs() {
		return alreadyCreatedActDefs;
	}

	public ArrayList<String> getParentChainArr (String actDef){
		ArrayList<String> actDefChain = new ArrayList<String>();
		
		String parent = actDef;
		actDefChain.add(parent);
		
		while (!rootActions.contains(parent))
		{
			parent = alreadyCreatedActDefs.get(parent);
			actDefChain.add(parent);
		}
		
		return actDefChain;
	}
}
