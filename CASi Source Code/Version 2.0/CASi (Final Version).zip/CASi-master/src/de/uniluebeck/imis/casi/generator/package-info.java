/**
 * The generator package contains interfaces for dealing with generators which generate a simulation/ world and provides different implementations of these interfaces in sub packages
 */
package de.uniluebeck.imis.casi.generator;

