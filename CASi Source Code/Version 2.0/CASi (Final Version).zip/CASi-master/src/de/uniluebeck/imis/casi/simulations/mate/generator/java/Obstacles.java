/*  CASi Context Awareness Simulation Software
 *  Copyright (C) 2012 2012  Moritz B�rger, Marvin Frick, Tobias Mende
 *
 *  This program is free software. It is licensed under the
 *  GNU Lesser General Public License with one clarification.
 *  
 *  You should have received a copy of the 
 *  GNU Lesser General Public License along with this program. 
 *  See the LICENSE.txt file in this projects root folder or visit
 *  <http://www.gnu.org/licenses/lgpl.html> for more details.
 *  
 *  
 *  
*  ==================================================================
 *  Changed By: 		Alexandr Petcovici
 *  Date:				26-Aug-2016
 *  Description:		Read simulationWorld.xml and creates obstacles 
 *  					based on it content
 *  ==================================================================
 */
package de.uniluebeck.imis.casi.simulations.mate.generator.java;

import java.awt.Point;

import java.awt.Point;
import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import de.uniluebeck.imis.casi.generator.ObstacleCollector;
import de.uniluebeck.imis.casi.generator.RoomCollector;
import de.uniluebeck.imis.casi.simulation.factory.WallFactory;
import de.uniluebeck.imis.casi.simulation.factory.WorldFactory;
import de.uniluebeck.imis.casi.simulation.model.Door;
import de.uniluebeck.imis.casi.simulation.model.Obstacle;
import de.uniluebeck.imis.casi.simulation.model.Room;
import de.uniluebeck.imis.casi.simulation.model.Wall;

/**
 * Room generator file with static methods that generate all the rooms for the
 * MATe simulation environment World.
 * 
 * Put all your rooms in here!
 * 
 * @author Marvin Frick
 * 
 */
public class Obstacles {

	/**
	 * Fills the RoomGenerator singleton object with all the rooms.
	 * 
	 * Put all your rooms here!
	 */
	public static void generateObstacles() {
		Wall newWall;
		Obstacle newObstacle = new Obstacle();	
		
		File xmlFile = new File("simulationWorld.xml");
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(xmlFile);
			
			
			NodeList obstaclesList = document.getElementsByTagName("obstacles");
			Node obstaclesNode = obstaclesList.item(0);
			Element obstaclesElem = (Element) obstaclesNode;
			
			NodeList obstacleList = obstaclesElem.getElementsByTagName("obstacle");
			
			for (int obstacleIndx = 0; obstacleIndx < obstacleList.getLength(); ++obstacleIndx) {
				newObstacle = new Obstacle();
				Node obstacle = obstacleList.item(obstacleIndx);

				NodeList wallList = ((Element)obstacle).getElementsByTagName("wall");
				for (int wallIndx = 0; wallIndx < wallList.getLength(); ++wallIndx) {
					
					Node wall = wallList.item(wallIndx);
					Element wallElem = (Element) wall;

					NodeList pointList = wallElem.getElementsByTagName("point");

					Element pointElement = ((Element)pointList.item(0));
					Integer xCoord = Integer.parseInt(pointElement.getElementsByTagName("xcoord").item(0).getTextContent().trim());
					Integer yCoord = Integer.parseInt(pointElement.getElementsByTagName("ycoord").item(0).getTextContent().trim());
					Point p1_temp = new Point(xCoord, yCoord);
					

					Element pointElement2 = (Element) ((Element)pointList.item(1));
					Integer xCoord2 = Integer.parseInt(pointElement2.getElementsByTagName("xcoord").item(0).getTextContent().trim());
					Integer yCoord2 = Integer.parseInt(pointElement2.getElementsByTagName("ycoord").item(0).getTextContent().trim());
					Point p2_temp = new Point(xCoord2, yCoord2);
					
					newWall = WallFactory.getWallWithPoints(p1_temp, p2_temp);

					newObstacle.addWall(newWall);
				}
				
				String obstacleId =  ((Element) obstacle).getElementsByTagName("obstacleid").item(0).getTextContent().trim();
				if ((obstacleId != null) && (!obstacleId.equals(""))) newObstacle.setIdentifier(obstacleId);
				ObstacleCollector.getInstance().newObstacle(newObstacle); 
				//System.out.println("\t\t--------->"+ WorldFactory.getRoomsWithPoint(newObstacle.getCentralPoint()));
				newObstacle.setParentRoom(RoomCollector.getInstance().getRoomWithPoint(newObstacle.getCentralPoint()));
			}
		} catch (ParserConfigurationException e) {e.printStackTrace();} 
		catch (SAXException e) {e.printStackTrace();} 
		catch (IOException e) {e.printStackTrace();}
		
		/*
		for (Obstacle o: ObstacleCollector.getInstance().getAll())
		{
			System.out.println("--++--++>>>" + o.getParentRoom().getIdentifier());
		}
		System.exit(1);
		*/
	}
}
