package de.uniluebeck.imis.casi.simulations.mate.generator.java;

import java.awt.geom.Point2D;
import java.util.ArrayList;

public class WallImportTemp {
	private Point2D startPoint;
	private Point2D endPoint;
	private ArrayList<DoorImportTemp> doorsTemp;
	

	public WallImportTemp(Point2D startPoint, Point2D endPoint){
		this.startPoint = startPoint;
		this.endPoint = endPoint;
		this.doorsTemp = new ArrayList<DoorImportTemp>();
	}
	
	public Point2D getStartPoint(){return this.startPoint;}
	public Point2D getEndPoint(){return this.endPoint;}
	public ArrayList<DoorImportTemp> getAllDoors(){return this.doorsTemp;}
	
	public void setStartPoint(Point2D startPoint){this.startPoint = startPoint;}
	public void setEndPoint(Point2D endPoint){this.endPoint = endPoint;}
	public void addDoor(DoorImportTemp doorTemp){this.doorsTemp.add(doorTemp);}
	public void addAllDoors (ArrayList<DoorImportTemp> doorsTemp){this.doorsTemp = doorsTemp;}
	
	public WallImportTemp getReversedWall(){
		WallImportTemp wallToReturn = new WallImportTemp(this.endPoint, this.startPoint);
		wallToReturn.addAllDoors(this.getAllDoors());
		return wallToReturn;
	}
	
}
