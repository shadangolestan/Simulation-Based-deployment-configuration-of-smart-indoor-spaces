/*  	CASi Context Awareness Simulation Software
* Author: 		Alexandr Petcovici
* Date: 		10-December-2016
* Description:  This class set world scales for world dimensions
*/
package de.uniluebeck.imis.casi.simulation.model;

import java.awt.Point;

/* @Alex
 * This class contains the information about world calibration parameters
 * 
 * 
 */


/**
 * 
 * @author Alex
 *
 */
public class WorldCalibrator {
	/* 1000 -> millimeter precission
	 * 100 -> dedimeter
	 * 10 -> centmeter
	 * 1 -> meter
	 */
	
	// MAX size is 450; MAX * coeff = 450; coeff = 450 / max
	double scaleFactor;
	// 900 / 8 =  112.5; x * 8 = max /112.5
	double agentScaleFactor;
	// 900 / 15 = 60
	int agentMovemnetSpeed;
	
	// Support for 3 levels of scale
	// 1) Millimeter precision
	// 2) Centimeter precision
	// 3) Decimeter precision
	int worldScale;
	
	
	//Point min;
	Point maxPoint;
	
	int maxVal;
	
	
	public WorldCalibrator(Point maxPoint, int worldScale){
//System.out.println("maxPoint: " + maxPoint);
//System.exit(0);
		this.worldScale = worldScale;
		this.maxPoint = maxPoint;		
		if (maxPoint.x > maxPoint.y) this.maxVal = maxPoint.x;
		else this.maxVal = maxPoint.y;
		
		this.scaleFactor = (450.0 / this.maxVal) / this.worldScale; 
		this.agentScaleFactor = this.maxVal  / 876.0 / this.worldScale;
		this.agentMovemnetSpeed = (int) Math.round(this.maxVal / 60.0 / this.worldScale);
	}
	
	public double getWorldScale(){return this.scaleFactor;}
	public double getAgentScale(){return this.agentScaleFactor;}
	public int getAgentMoveSpeed(){
		
		//return this.agentMovemnetSpeed;
		return this.agentMovemnetSpeed;
		}
}
