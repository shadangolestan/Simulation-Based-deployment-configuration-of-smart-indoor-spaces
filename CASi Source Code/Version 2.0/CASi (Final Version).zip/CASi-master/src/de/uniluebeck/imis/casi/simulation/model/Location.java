/*  	CASi Context Awareness Simulation Software
 *   Copyright (C) 2012  Moritz Bürger, Marvin Frick, Tobias Mende
 *
 *  This program is free software. It is licensed under the
 *  GNU Lesser General Public License with one clarification.
 *  
 *  You should have received a copy of the 
 *  GNU Lesser General Public License along with this program. 
 *  See the LICENSE.txt file in this projects root folder or visit
 *  <http://www.gnu.org/licenses/lgpl.html> for more details.
 */
package de.uniluebeck.imis.casi.simulation.model;

import java.awt.Polygon;
import java.awt.Shape;
import java.awt.geom.Point2D;
import java.util.logging.Logger;
import de.uniluebeck.imis.casi.simulation.model.actionHandling.AbstractAction;


public class Location extends AbstractInteractionComponent{
	/** the development logger */
	private static final Logger log = Logger.getLogger(Location.class.getName());
	/** serialization identifier */
	private static final long serialVersionUID = 112593179870431369L;
	
	Point2D coordinates;
	
	public Location(String identifier, Point2D coordinates) {
		super(identifier, coordinates);
	}
	

	
	public void setCoordinates(Point2D point){
		this.coordinates = point;
	}

	@Override
	public Point2D getCoordinates() {
		// TODO Auto-generated method stub
		return this.coordinates;
	}

	@Override
	public boolean contains(IPosition position) {
		// TODO Auto-generated method stub
		return contains(position.getCoordinates());
	}

	@Override
	public boolean contains(Point2D point) {
		// TODO Auto-generated method stub
		return (this.coordinates.equals(point));
	}

	@Override
	public Shape getShapeRepresentation() {
		// TODO Auto-generated method stub
		Polygon polygon = new Polygon();
		polygon.contains(getCoordinates());
		Shape shape = polygon;
		return shape;
	}

	@Override
	public Point2D getCentralPoint() {
		// TODO Auto-generated method stub
		return this.coordinates;
	}


	@Override
	protected boolean handleInternal(AbstractAction action, Agent agent) {
		// TODO Auto-generated method stub
		return false;
	}



	@Override
	public void turnOnFunctionality() {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void turnOffFunctionality() {
		// TODO Auto-generated method stub
		
	}

}
