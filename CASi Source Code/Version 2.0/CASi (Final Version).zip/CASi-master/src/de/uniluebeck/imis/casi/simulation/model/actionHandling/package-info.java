/**
 * The action handling package is used to encapsulate different action templates due to security risks like the problem how java handles protected methods.
 */
package de.uniluebeck.imis.casi.simulation.model.actionHandling;

