/**
 * Utils provides a collection of generic and general tools, classes and interfaces which might help during the implementation 
 * and that are highly reusable
 */
package de.uniluebeck.imis.casi.utils;

