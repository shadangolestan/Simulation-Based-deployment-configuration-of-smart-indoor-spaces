/*  	CASi Context Awareness Simulation Software
* Author: 		Alexandr Petcovici
* Date: 		10-December-2016
* Description:  This class is used during the world generation and
* 				schedules actions
*/
package de.uniluebeck.imis.casi.simulations.mate.generator.java;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import de.uniluebeck.imis.casi.generator.ActivityScheduleCollector;
import de.uniluebeck.imis.casi.simulation.model.ActivitySchedule;


/**
 * Action generator file with static methods that generate all the actions for
 * the MATe simulation environment World.
 * 
 * Put all your actions in here!
 * 
 * @author Marvin Frick
 * 
 */
public final class ActivitySchedules {

	private static final Logger log = Logger.getLogger(WorldGenerator.class
			.getName());

	/**
	 * Fills the ActionGenerator singleton object with all the actions.
	 * 
	 * Put all your actions here!
	 */
	public static void addActivitySchedulesFromXML() {
	
		ActivityScheduleCollector actScheCollector = ActivityScheduleCollector.getInstance();
		
		File xmlFile = new File("simulationWorld.xml");
		try{
			
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(xmlFile);
			NodeList actionsShedsList = document.getElementsByTagName("actions");
			Node actionShedsNode = actionsShedsList.item(0);
			Element actionsElem = (Element) actionShedsNode;
			NodeList actionSchedList = actionsElem.getElementsByTagName("action");
			
			
			
			for (int actionSchedIndx = 0; actionSchedIndx < actionSchedList.getLength(); ++actionSchedIndx){
				Node actionSchedNode = actionSchedList.item(actionSchedIndx);
				Element actionSchedElem = (Element) actionSchedNode;
				
				
				
				String actionID = actionSchedElem.getElementsByTagName("id").item(0).getTextContent().trim();
				String agentID = actionSchedElem.getElementsByTagName("agentID").item(0).getTextContent().trim();
				String actionDate = actionSchedElem.getElementsByTagName("actionDate").item(0).getTextContent().trim();
				String actionTime = actionSchedElem.getElementsByTagName("actionTime").item(0).getTextContent().trim();
	
				
				ActivitySchedule actSched = new ActivitySchedule(actionID,  actionDate, actionTime, agentID);
				Element subactionsElement = (Element) (actionSchedElem.getElementsByTagName("subactions").item(0));
				NodeList subactionList = subactionsElement.getElementsByTagName("subaction");
				for(int subActionInx = 0; subActionInx < subactionList.getLength(); ++subActionInx){
				
					String actionType = subactionsElement.getElementsByTagName("actionType").item(subActionInx).getTextContent().trim();
					actSched.addSubActivity(actionType);
				//	String target = subactionsElement.getElementsByTagName("target").item(subActionInx).getTextContent().trim();

				}
				
				actScheCollector.newActSched(actionID, actSched);
			
			}
		} catch (ParserConfigurationException e) {e.printStackTrace();} 
		catch (SAXException e) {e.printStackTrace();} 
		catch (IOException e) {e.printStackTrace();}
		
		/*
		HashMap <String, ActivitySchedule> actDefTemp = actScheCollector.getAlreadyCreatedActions();
	    Iterator it = actDefTemp.entrySet().iterator();
	    while (it.hasNext()) {
	        Map.Entry pair = (Map.Entry)it.next();
	        //System.out.println(pair.getKey() + " = " + pair.getValue());
	        System.out.println("Key: " + ((String) pair.getKey()));
	        
	        ActivitySchedule actSched_temp = (ActivitySchedule)pair.getValue();
	        
	        ArrayList<String> actTypes = actSched_temp.getActionTypes();
	        for(int i = 0; i < actTypes.size(); ++i)
	        {
	        	System.out.println("\t\t" + actTypes.get(i) + "->");
	        }
	        System.out.println("--");
	        	
	        it.remove(); // avoids a ConcurrentModificationException
	    }
	    
		System.out.println("Scheduler Loaded");
		System.exit(1);
		*/
	}

}
