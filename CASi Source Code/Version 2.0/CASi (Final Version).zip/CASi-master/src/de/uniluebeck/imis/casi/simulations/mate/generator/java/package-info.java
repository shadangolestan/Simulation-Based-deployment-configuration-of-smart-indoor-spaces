/**
 * Contains a generator for manual creating java objects and aggregating them to a world which can be simulated.
 */
package de.uniluebeck.imis.casi.simulations.mate.generator.java;

