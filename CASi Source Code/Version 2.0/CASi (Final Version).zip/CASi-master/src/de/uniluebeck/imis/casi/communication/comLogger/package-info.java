/**
 * This package contains a implementation of the {@link de.uniluebeck.imis.casi.communication.ICommunicationHandler} interface 
 * that simply logs all messages that should be sended to the log file.
 * The main usage of this handler is debugging
 */
package de.uniluebeck.imis.casi.communication.comLogger;

