/**
 * The model contains classes which are used to represent the reality
 */
package de.uniluebeck.imis.casi.simulation.model;

