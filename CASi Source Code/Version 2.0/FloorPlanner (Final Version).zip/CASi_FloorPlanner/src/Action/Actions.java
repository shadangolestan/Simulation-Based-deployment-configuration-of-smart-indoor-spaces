package Action;

import java.util.ArrayList;

public class Actions {
	private ArrayList<Action> actions;
	private Action currentActiveAction;

	public Actions() {
		this.actions = new ArrayList<Action>();
		this.currentActiveAction = null;
	}

	public void addAction(Action action) {actions.add(action);}
	public void removeAction(Action action) {actions.remove(action);}
	public void removeActionByIndex(int index) {actions.remove(index);}
	public ArrayList<Action> getActions() {return actions;}
	public void setCurrentActiveAction(Action currentActiveAction) {this.currentActiveAction = currentActiveAction;}
	public Action getCurrentActiveAction() {return currentActiveAction;}

	public boolean isIdInList(String id) {
		for (int i = 0; i < actions.size(); ++i)
		{
			if (actions.get(i).getActionId().equals(id)) 
				return true;
		}
		return false;
	}

	public Action getActionByID(String id) {
		for (int i = 0; i < actions.size(); ++i) {
			if (actions.get(i).getActionId().equals(id)) {
				return actions.get(i);
			}
		}
		return null;
	}
}
