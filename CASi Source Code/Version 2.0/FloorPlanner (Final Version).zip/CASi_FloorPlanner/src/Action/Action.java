package Action;

import java.time.LocalDate;
import java.util.ArrayList;

import application.Agent;
import application.GroupController;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class Action {
	private boolean isValidAction;
	private Action itself;
	
	private String actionID; 
	private Agent agent;
	private String actionType;
	//private String target;
	private String actionStartDate;
	private String actionStartTime;
	private GroupController gc;
	private ArrayList<Action> subactions;
	private boolean isSubAction;
	private String parentActionID;

	public Action(GroupController gc){
		this.itself = this;
		this.gc = gc;
		this.isSubAction = gc.createSubtask;
		isValidAction = validateAndRecord(true);
		
		if (!isSubAction){
			gc.actions.setCurrentActiveAction(itself);
			
			subactions = new ArrayList<Action>();
			subactions.add(itself);
		}
		else {
			Action parentAction = gc.actions.getActionByID(
					gc.ca_parentActionList.getSelectionModel().getSelectedItem().toString());
			
			gc.actions.setCurrentActiveAction(parentAction);
			
			if (this.gc.ca_actionInst_ChoiceBox.getSelectionModel().getSelectedItem() != null)
			{
				this.actionID = gc.ca_actionInst_ChoiceBox.getSelectionModel().getSelectedItem().toString() + "-" + parentAction.getSubactionIds().size();
				
			}else{
				this.actionID = gc.ca_actionInst_ChoiceBox.getSelectionModel().getSelectedItem().toString() + "-" + parentAction.getSubactionIds().size();
			}
			
		//	actionID = parentAction.getActionId() + "-" + parentAction.getSubactionIds().size();
			parentAction.addSubaction(itself);
			subactions = null;
		}
	} 

	public Action(String actionID, Agent agent, String actionType, //String target, 
			String actionDate, String actionTime, GroupController gc)
	{
		this.gc = gc;
		this.isSubAction = gc.createSubtask;
		if (!isSubAction){
			subactions = new ArrayList<Action>();
			this.actionID = actionID; 
			this.agent = agent;
			this.actionType = actionType;
			//this.target = target;
			this.actionStartDate = actionDate;
			this.actionStartTime = actionTime;
			
			
			this.itself = this;
			gc.actions.addAction(itself);
			
			if (!gc.createSubtask) gc.actions.setCurrentActiveAction(itself);
			isValidAction = true;
			
			subactions.add(itself);

		}
		else{
			subactions = null;
			Action parentAction = gc.actions.getCurrentActiveAction();
			this.itself = this;
			gc.actions.setCurrentActiveAction(parentAction);
			parentAction.addSubaction(itself);
			if (gc.ca_actionInst_ChoiceBox.getSelectionModel().getSelectedItem() != null)
			{
				this.actionID = gc.ca_actionInst_ChoiceBox.getSelectionModel().getSelectedItem().toString() + "-" + parentAction.getSubactionIds().size();
			}

			subactions = null;
			isValidAction = true;
			
			this.actionType = actionType;
		}
			
	}
	

	public String getActionId(){return this.actionID;}
	public Agent getAgent(){return this.agent;}
	public void setAgent(Agent agent){this.agent = agent;}
	public void setDate(String date){this.actionStartDate = date;}
	public String getDate(){return this.actionStartDate;}
	public void setTime(String time){this.actionStartTime = time;}
	public String getTime(){return this.actionStartTime;}
	public Action getItself(){return this.itself;}
	public String getAgentID(){return this.agent.getAgentId();}
	public String getActionType(){return this.actionType;}
	public void setActionType(String actionType){this.actionType = actionType;}
	public String getActionTime(){return this.actionStartTime;}
	public String getActionDate(){return this.actionStartDate;}
	public boolean isValidAction(){return this.isValidAction;}
	
	@SuppressWarnings({ "rawtypes", "unused" })
	public boolean validateAndRecord(boolean isNew)
	{
		String actionID_temp = "";
		String agentID_temp = "";
		String actionType_temp = "";
		String actionTarget_temp = "";
		String startDate_temp = "";
		String startTime_temp = "";
		String parentActionID_temp = "";
		Agent selectedAgent_temp = null;
		
		DatePicker actionStart_datePicker = null;
		ChoiceBox agentID_choiceBox = null;
		ChoiceBox actionType_choiceBox = null;
//		ChoiceBox actionTarget_choiceBox = null;
		ChoiceBox actionID_choiceBox = null;
		Label outputMessage_label = null;
		TextField actionStartTime_textField = null;
		
		
		if (isNew){
			actionID_temp = gc.ca_actionID_TextField.getText().trim();
			outputMessage_label = gc.ca_addAction_Label;
			agentID_choiceBox = gc.ca_agentID_ChoiceBox;
			actionType_choiceBox = gc.ca_actionInst_ChoiceBox;
//			actionTarget_choiceBox = gc.ca_target_ChoiceBox;
			actionStartTime_textField = gc.ca_actionStartTime_TextField;
			actionStart_datePicker = gc.ca_actionStartData_DatePicker;
			//parentActionID = gc.ca_actionID_ChoiceBox.getSelectionModel().getSelectedItem().toString();
		}
		else{
			outputMessage_label = gc.ma_addAction_Label;
			agentID_choiceBox = gc.ma_agentID_ChoiceBox;
			//actionType_choiceBox = gc.ma_actionType_ChoiceBox;
//			actionTarget_choiceBox = gc.ma_target_ChoiceBox;
			actionStartTime_textField = gc.ma_actionStartTime_TextField;
			actionStart_datePicker = gc.ma_actionStartData_DatePicker;
			actionID_choiceBox = gc.ma_actionID_ChoiceBox;
		}
		
		//LocalDate localDate = actionStart_datePicker.getValue();
	

		if (!isSubAction){
			if ((isNew) && ((actionID_temp.equals("") || actionID_temp == null)))
				gc.setMessage(false, "Action Id missing", outputMessage_label);
			else if ((!isNew)){
				try {
					//actionID_temp = ((ChoiceBox)actionID_obj).getSelectionModel().getSelectedItem().toString();
					actionID_temp = gc.ma_actionID_ChoiceBox.getSelectionModel().getSelectedItem().toString();
					//actionID_temp = gc.ca_actionType_ChoiceBox.getSelectionModel().getSelectedItem().toString();
					
				} catch (Exception e) {
					gc.setMessage(false, "Action Id missing", outputMessage_label);
					return false;
				}
			}
			
			if (isNew &&(gc.actions.isIdInList(actionID_temp))) {
				gc.setMessage(false, "Action is already in the list.", outputMessage_label);
				return false;
			}
			
			startTime_temp = actionStartTime_textField.getText();
			if  (startTime_temp.equals("") || startTime_temp == null) {
				gc.setMessage(false, "Start Time Missing", outputMessage_label);
				return false;
			}
			
			String timeValidationError = validateTimeFormat(startTime_temp).trim();
			if  (!timeValidationError.equals("")) {
				gc.setMessage(false, timeValidationError, outputMessage_label);
				return false;
			}
			
			try {
				agentID_temp = agentID_choiceBox.getSelectionModel().getSelectedItem().toString();
			} catch (Exception e) {
				gc.setMessage(false, "Agent Name is missing", outputMessage_label);
				return false;
			}

			try {
				startDate_temp = actionStart_datePicker.getValue().toString();
			} catch (Exception e) {
				gc.setMessage(false, "Start Date is missing", outputMessage_label);
				return false;
			}
			try {
				LocalDate.parse(startDate_temp);
			} catch (Exception e) {
				gc.setMessage(false, "Incorrect date", outputMessage_label);
				return false;
			}

			try {
				selectedAgent_temp = gc.agents.getAgentById(agentID_temp);
			} catch (Exception e) {
				gc.setMessage(false, "Agent id is missing", outputMessage_label);
				return false;
			}
			
			this.actionID = actionID_temp;
					//gc.ca_actionInst_ChoiceBox.getSelectionModel().getSelectedItem().toString();//actionID_temp; 
		}
		else if (isSubAction && isNew){
			try {
				this.parentActionID = gc.ca_parentActionList.getSelectionModel().getSelectedItem().toString();
			} catch (Exception e) {
				gc.setMessage(false, "Parent Action Not Selected", outputMessage_label);
				return false;
			}
			
			try {
				actionType_temp = actionType_choiceBox.getSelectionModel().getSelectedItem().toString();
			} catch (Exception e) {
				gc.setMessage(false, "Action type is missing", outputMessage_label);
				return false;
			}
			
		}
		


		//this.actionID = actionID_temp; 
		this.agent = selectedAgent_temp;
		this.actionType = actionType_temp;
		//this.target = actionTarget_temp;
		this.actionStartDate = startDate_temp;
		this.actionStartTime = startTime_temp;

		
		if (isNew){
			gc.ca_actionID_TextField.setText("");
			gc.setMessage(true, "Action Added!", outputMessage_label);
		}
		else{
			gc.setMessage(true, "Modified", outputMessage_label);
		}
		
	//	actionType_choiceBox.getSelectionModel().clearSelection();
		//actionTarget_choiceBox.getSelectionModel().clearSelection();
		actionStart_datePicker.setValue(null); 
		actionStartTime_textField.setText("");
		
		return true;
	}
	
	
	public String validateTimeFormat(String time) {
		String[] time_arr = time.trim().split(":");

		int hours = -1;
		int minutes = -1;
		int seconds = -1;
		if (time_arr.length != 3) return "Wrong Format. Should be HH:MM:SS";
		try {
			hours = Integer.parseInt(time_arr[0]);
			minutes = Integer.parseInt(time_arr[1]);
			seconds = Integer.parseInt(time_arr[2]);
		} catch (Exception e) {
			return "Time format is HH:MM:SS";
		}

		if ((hours < -1) || (hours > 23))
			return ("Hours must be from 0 to 23 inclusive");
		if ((minutes < -1) || (minutes > 59))
			return ("Minutes must be from 0 to 59 inclusive");
		if ((seconds < -1) || (seconds > 59))
			return ("Seconds must be from 0 to 59 inclusive");

		return "";
	}
	
	public ArrayList<Action> getSubactions(){return subactions;}
	
	public ArrayList<String> getSubactionIds(){
		ArrayList<String> subactionIDs = null;
		if (this.subactions !=  null){
			subactionIDs = new ArrayList<String>();
			
			for(int i = 1; i < this.subactions.size(); ++i){
				subactionIDs.add(subactions.get(i).getActionType());
			}
		}
		
		return subactionIDs;
	
	}
	
	public void addSubaction(Action newSubAction){
		subactions.add(newSubAction);
	}
	
	public Action getSubActionByID(String subactionId){
		if (this.subactions != null){
			for (int i = 0; i < this.subactions.size(); ++i){
				if (subactions.get(i).getActionId().equals(subactionId))
					return subactions.get(i);
			}
		}
		
		return null;
	}
}
