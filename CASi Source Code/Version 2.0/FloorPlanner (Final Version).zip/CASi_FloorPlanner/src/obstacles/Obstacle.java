package obstacles;

import java.util.ArrayList;
import application.AnchorDrawShape;
import application.GroupController;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.StrokeLineCap;

public class Obstacle {
	private String obstacleID;
	private Polygon obstacleShape;
	private ArrayList<AnchorDrawShape> obstacleAnchors;
    private Obstacle itself;    
    private ArrayList<DoubleProperty> xObstaclePropertyListener;
    private ArrayList<DoubleProperty> yObstaclePropertyListener;
	private AnchorDrawShape currentlySelectedObstaclePoint;
	private GroupController gc;
	

	public Obstacle(GroupController gc){
		this.gc = gc;
		this.obstacleID = null;
		this.obstacleShape = new Polygon();
		this.obstacleAnchors = new ArrayList<AnchorDrawShape>();
		this.itself = this;
		this.xObstaclePropertyListener = new ArrayList<DoubleProperty>();
		this.yObstaclePropertyListener = new ArrayList<DoubleProperty>();
		this.setSelected();
		this.setSelectedStyle();
		
		this.currentlySelectedObstaclePoint = null;
		
		obstacleShape.setOnMouseClicked(new EventHandler<MouseEvent>(){
			@Override
			public void handle(MouseEvent event) {
				itself.gc.resetObstacleIdLabel.setText("");
				if (event.getButton() == MouseButton.SECONDARY) {
 		        	itself.gc.obstacles.removeObstacle(itself);
 		        	itself.gc.getMainPane().getChildren().remove(obstacleShape);
 		        	removeAnchorsFromPane();
 		        	itself.removeAnchorsFromAllAchors();
				}
 		        else if (event.getButton() == MouseButton.PRIMARY)
 		        {
 		        	itself.gc.currentObstaclePoint_Xcoord_textField.setText("");
 		        	itself.gc.currentObstaclePoint_Ycoord_textField.setText("");
 		        	
 		        	itself.gc.obstacleIdTextFields.setText(obstacleID);
 		        	setSelected();
  				
 		        	itself.gc.saveObstacle.setOnAction(new EventHandler<ActionEvent>(){
	 		   			@Override
	 					public void handle(ActionEvent event) {
	 		   	   			try{
		 		   				String newID = itself.gc.obstacleIdTextFields.getText();
		  						String x_coord_str = itself.gc.currentObstaclePoint_Xcoord_textField.getText().trim();
		  						String y_coord_str = itself.gc.currentObstaclePoint_Ycoord_textField.getText().trim();
		 		   				
		  						if ((!itself.gc.obstacles.isIdInList(newID)) || (itself.gc.obstacles.isIdInList(newID) && newID.equals(itself.getObstacleId()))){
		  							if ((!y_coord_str.equals("")) && (!x_coord_str.equals("")))
		  							{
		  								Double x_coord_new = Double.parseDouble(itself.gc.currentObstaclePoint_Xcoord_textField.getText());
				  						Double y_coord_new = Double.parseDouble(itself.gc.currentObstaclePoint_Ycoord_textField.getText());
				  						currentlySelectedObstaclePoint.setCenterX(x_coord_new);currentlySelectedObstaclePoint.setCenterY(y_coord_new);
		  							}
		  							itself.obstacleID = newID;	
		  							
		  							itself.gc.setMessage(true, "Changes successfully saved", itself.gc.resetObstacleIdLabel);
		 		   					
		  						}else itself.gc.setMessage(false, "ID already Exists", itself.gc.resetObstacleIdLabel);
		  						
		  					}
		  					catch (Exception exception){itself.gc.setMessage(false, "Invalid input", itself.gc.resetObstacleIdLabel);}
	 		   			}
		        	});
  		          
 		        }	
			}
        });
	}
	
		
	
	public void hide(){
		this.removeAnchorsFromPane();
		itself.gc.getMainPane().getChildren().remove(this.obstacleShape);
	}
	
	public void show(){
		for(int i = 0; i < obstacleAnchors.size(); i++){
			itself.gc.getMainPane().getChildren().add(obstacleAnchors.get(i));
		}
		itself.gc.getMainPane().getChildren().add(obstacleShape);
	}
	
	
	public AnchorDrawShape addAnchorCircle(){
		ObservableList<Double> currentPoints = obstacleShape.getPoints();
		AnchorDrawShape newPoint = createControlAnchorsFor(currentPoints);
		 obstacleAnchors.add(newPoint);
		 itself.gc.allObstacleAnchors.add(newPoint);
		return newPoint;
	}
	
	private AnchorDrawShape createControlAnchorsFor(final ObservableList<Double> points) {
    	
    	int index = points.size() - 2;
    
    	DoubleProperty xProperty = new SimpleDoubleProperty(points.get(index));
        DoubleProperty yProperty = new SimpleDoubleProperty(points.get(index + 1));
        
        xProperty.addListener(new ChangeListener<Number>() {
        	@Override
            public void changed(ObservableValue<? extends Number> ov, Number oldX, Number x) {
        		points.set(index, (double) x);
        		itself.gc.currentObstaclePoint_Xcoord_textField.setText(x + "");
        	}
         });

         yProperty.addListener(new ChangeListener<Number>() {
        	 @Override
             public void changed(ObservableValue<? extends Number> ov, Number oldY, Number y) {
        		 points.set(index + 1, (double) y);
        		 itself.gc.currentObstaclePoint_Ycoord_textField.setText(y + "");
        	 }
         });
         
         AnchorDrawShape a = new AnchorDrawShape(xProperty, yProperty, itself.gc.allObstacleAnchors, gc.anchorSize);
         setSelected();
         a.setOpacity(1);
         
         a.setOnMouseClicked(new EventHandler<MouseEvent>(){
 			@Override
 			public void handle(MouseEvent e) {
 				setSelected();
 				if (e.getButton() == MouseButton.PRIMARY){
 					currentlySelectedObstaclePoint = a;
 					itself.gc.currentObstaclePoint_Xcoord_textField.setText(points.get(index) + "");
 					itself.gc.currentObstaclePoint_Ycoord_textField.setText(points.get(index + 1) + "");
 					itself.gc.obstacles.setCurrentActiveObstacle(itself.gc.obstacles.getCurrentActiveObstacleIndex());
 					a.setSelected();
 					
 					itself.gc.saveObstacle.setOnAction(new EventHandler<ActionEvent>(){
	 		   			@Override
	 					public void handle(ActionEvent event) {
			 		   		try{
		 		   				String newID = itself.gc.obstacleIdTextFields.getText();
		  						String x_coord_str = itself.gc.currentObstaclePoint_Xcoord_textField.getText().trim();
		  						String y_coord_str = itself.gc.currentObstaclePoint_Ycoord_textField.getText().trim();
		 		   				
		  						if ((!itself.gc.obstacles.isIdInList(newID)) || (itself.gc.obstacles.isIdInList(newID) && newID.equals(itself.getObstacleId()))){
		  							if ((!y_coord_str.equals("")) && (!x_coord_str.equals("")))
		  							{
		  								Double x_coord_new = Double.parseDouble(itself.gc.currentObstaclePoint_Xcoord_textField.getText());
				  						Double y_coord_new = Double.parseDouble(itself.gc.currentObstaclePoint_Ycoord_textField.getText());
				  						currentlySelectedObstaclePoint.setCenterX(x_coord_new);currentlySelectedObstaclePoint.setCenterY(y_coord_new);
		  							}
		  							itself.obstacleID = newID;	
		  							itself.gc.setMessage(true, "Changes successfully saved", itself.gc.resetObstacleIdLabel);
		 		   					
		  						}else itself.gc.setMessage(false, "ID already Exists", itself.gc.resetObstacleIdLabel);
		  						
		  					}
		  					catch (Exception exception){itself.gc.setMessage(false, "Invalid input", itself.gc.resetObstacleIdLabel);}
	 		   			}
		        	});
 				}
 		        e.consume();
 			}
         });

         currentlySelectedObstaclePoint = a;
         
         xObstaclePropertyListener.add(xProperty);
         yObstaclePropertyListener.add(yProperty);
         
         return a;
    }
	
	public void setUnselectedStyle(){
		obstacleShape.setStroke(Color.DARKCYAN);
		obstacleShape.setStrokeWidth(1);
		obstacleShape.setStrokeLineCap(StrokeLineCap.ROUND);
		obstacleShape.setFill(Color.LIGHTGRAY.deriveColor(0, 1.2, 1, 0.6));
	}
	
	public void setSelectedStyle(){
		obstacleShape.setStroke(Color.DARKGREEN);
		obstacleShape.setStrokeWidth(1);
		obstacleShape.setStrokeLineCap(StrokeLineCap.ROUND);
		obstacleShape.setFill(Color.CRIMSON.deriveColor(0, 1.2, 1, 0.6));
	}

	public ArrayList<DoubleProperty> getX_PropertyListener(){return this.xObstaclePropertyListener;}
	public ArrayList<DoubleProperty> getY_PropertyListener(){return this.yObstaclePropertyListener;}
	public void addValue(double value) {obstacleShape.getPoints().add(value);}
	public Polygon getObstacleShape (){return obstacleShape;}
	public void setObstacleID(String obstacle_id){this.obstacleID = obstacle_id;}
	public String getObstacleId(){return this.obstacleID;}
	public void addAnchor (AnchorDrawShape anchor) {obstacleAnchors.add(anchor); itself.gc.allObstacleAnchors.add(anchor);}
	public void removeAnchor (AnchorDrawShape anchor) {obstacleAnchors.remove(anchor); itself.gc.allObstacleAnchors.remove(anchor);}
	public ArrayList<AnchorDrawShape> getAnchors () {return obstacleAnchors;}
	public ArrayList<Double> get_Xcoord(){return this.get_Xcoord();}
	public ArrayList<Double> get_Ycoord(){return this.get_Ycoord();}
	public Obstacle getItself(){return this.itself;} 
	public void setSelected(){itself.gc.obstacleIdTextFields.setText(obstacleID);itself.gc.obstacles.setSelectedObstacle(itself);}
	public void removeAnchorsFromPane(){for(int i = 0 ; i < obstacleAnchors.size(); ++i)itself.gc.getMainPane().getChildren().remove(obstacleAnchors.get(i));}
	public void removeAnchorsFromAllAchors(){for(int i = 0 ; i < obstacleAnchors.size(); ++i)itself.gc.allObstacleAnchors.remove(obstacleAnchors.get(i));}

}
