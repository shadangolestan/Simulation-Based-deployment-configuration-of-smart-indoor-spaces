package obstacles;

import java.util.ArrayList;

public class Obstacles {
	private ArrayList<Obstacle> obstacles;
	private int currentActiveObstacle;
	
	public Obstacles(){
		this.obstacles = new ArrayList<Obstacle>();
		this.currentActiveObstacle = -1;
	}
	
	public void addObstacle(Obstacle obstacle){obstacles.add(obstacle);currentActiveObstacle = obstacles.size() - 1;}
	public void removeObstacle(Obstacle obstacle){obstacles.remove(obstacle);}
	public void removeObstacleByIndex(int index){obstacles.remove(index);}
	public ArrayList<Obstacle> getObstacles(){return obstacles;}
	public void setCurrentActiveObstacle(int currentActiveObstacle){this.currentActiveObstacle = currentActiveObstacle;}
	public int getCurrentActiveObstacleIndex(){return this.currentActiveObstacle;}
	public Obstacle getCurrentActiveObstacle(){return obstacles.get(currentActiveObstacle);}
	
	public boolean isIdInList(String id){
		for (int i = 0; i < obstacles.size(); ++i) if (obstacles.get(i).getObstacleId().equals(id)) return true;
		return false;
	}
	
	public void setSelectedObstacle(Obstacle obstacle){
		for(int i = 0; i < obstacles.size(); ++i) 
			if (!(obstacles.get(i).equals(obstacle))) obstacles.get(i).setUnselectedStyle();
			else {obstacle.setSelectedStyle(); currentActiveObstacle = i;}
	}
	
	
	public void hideAllObstacles(){for(int i = 0; i < obstacles.size(); ++i) obstacles.get(i).hide();}
	public void showAllObstacles(){for(int i = 0; i < obstacles.size(); ++i) obstacles.get(i).show();}
	
	
}
