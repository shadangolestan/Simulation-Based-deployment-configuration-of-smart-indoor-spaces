package geometry;

import javafx.collections.ObservableList;
import javafx.scene.shape.Polygon;

/*http://www.java2s.com/Code/Java/2D-Graphics-GUI/Returnsclosestpointonsegmenttopoint.htm*/
public class GeometryFunctions {

	public static Point getClosestPoint(Polygon polygon, Point p){
		ObservableList<Double> points = polygon.getPoints();
		
		Point closestPoint = null;
		double shortestDistance = Double.MAX_VALUE;

		for (int i = 0; i < points.size() -2; i += 2){
			Point cp = getClosestPointOnSegment(new Point(points.get(i).intValue(), points.get(i + 1).intValue()),
					new Point(points.get(i + 2).intValue(), points.get(i + 3).intValue()), p);
			double cd = Math.sqrt((p.x-cp.x)*(p.x-cp.x) + (p.y-cp.y)*(p.y-cp.y));

			if (cd < shortestDistance){
				closestPoint = cp;
				closestPoint.edgeID = i/2;
				shortestDistance = cd;
			}
		}

		
		Point cp = getClosestPointOnSegment(new Point(points.get(0).intValue(), points.get(1).intValue()), 
				new Point(points.get(points.size()-2).intValue(), points.get(points.size() - 1).intValue()), p);
		
		double cd = Math.sqrt((p.x-cp.x)*(p.x-cp.x) + (p.y-cp.y)*(p.y-cp.y));
		//
		if (cd < shortestDistance){
			closestPoint = cp;
			closestPoint.edgeID = (points.size() / 2) - 1 ;
			shortestDistance = cd;
			
		}
		return closestPoint;
	}
	
	
	public static Point getClosestPointOnSegment(Point ss, Point se, Point p) {
		return getClosestPointOnSegment(ss.x, ss.y, se.x, se.y, p.x, p.y);
	}

	public static Point getClosestPointOnSegment(double sx1, double sy1, double x, double y, double x2, double y2) {
		double xDelta = x - sx1;
		double yDelta = y - sy1;

		//if ((xDelta == 0) && (yDelta == 0)) {throw new IllegalArgumentException("Segment start equals segment end");}

		double u = ((x2 - sx1) * xDelta + (y2 - sy1) * yDelta) / (xDelta * xDelta + yDelta * yDelta);

		final Point closestPoint;
		if (u < 0) {
			closestPoint = new Point(sx1, sy1);
		} else if (u > 1) {
			closestPoint = new Point(x, y);
		} else {
			closestPoint = new Point((int) Math.round(sx1 + u * xDelta), (int) Math.round(sy1 + u * yDelta));
		}

		return closestPoint;
	}
}