package geometry;

public class Point {
	public double x;
	public double y;
	public int edgeID;
	
	public Point(double d, double e){this.x = d; this.y = e;}
	public Point(double x, double y, int edgeID){this.x = x; this.y = y; this.edgeID = edgeID;}
	/*
	public void setX (int x){this.x = x;}
	public void setY (int y){this.y = y;}
	public void setEdeID (int id){this.edgeID = id;}
	public int getX(){return this.x;}
	public int getY(){return this.y;}
	publiv int getEdgeID(){return this.edgeID;}
	*/
	
}
