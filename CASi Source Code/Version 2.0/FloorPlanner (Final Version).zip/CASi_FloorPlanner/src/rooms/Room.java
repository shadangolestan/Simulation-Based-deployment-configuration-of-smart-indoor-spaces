package rooms;

import java.util.ArrayList;
import application.AnchorDrawShape;
import application.Door;
import application.GroupController;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.StrokeLineCap;

public class Room {
	private String roomID;
	private Polygon roomShape;
	private ArrayList<AnchorDrawShape> roomAnchors;
    private Room itself;    
    private ArrayList<DoubleProperty> xPropertyListener;
    private ArrayList<DoubleProperty> yPropertyListener;
    private ArrayList<Door> roomDoors;
    private AnchorDrawShape currentlySelectedPoint;
    private GroupController gc;

	public Room(GroupController gc){
		this.roomID = null;
		this.roomShape = new Polygon();
		this.roomAnchors = new ArrayList<AnchorDrawShape>();
		this.itself = this;
		this.gc = gc;
		this.xPropertyListener = new ArrayList<DoubleProperty>();
		this.yPropertyListener = new ArrayList<DoubleProperty>();	
		this.setSelected();
		this.setSelectedStyle();
		
		this.roomDoors = new ArrayList<Door>();
		this.currentlySelectedPoint = null;
		
		roomShape.setOnMouseClicked(new EventHandler<MouseEvent>(){
			@Override
			public void handle(MouseEvent event) {
				itself.gc.resetIdLabel.setText("");
				if (event.getButton() == MouseButton.SECONDARY) {
					itself.gc.rooms.removeRoom(itself);
					itself.gc.getMainPane().getChildren().remove(roomShape);
 		        	removeAnchorsFromPane();
 		        	itself.removeAnchorsFromAllAchors();
				}
 		        else if (event.getButton() == MouseButton.PRIMARY)
 		        {
 		        	itself.gc.currentPoint_Xcoord_textField.setText("");
 		        	itself.gc.currentPoint_Ycoord_textField.setText("");
 		        	
 		        	itself.gc.roomIdTextFields.setText(roomID);
 		        	setSelected();
  				
 		        	itself.gc.saveRoom.setOnAction(new EventHandler<ActionEvent>(){
	 		   			@Override
	 					public void handle(ActionEvent event) {
		 		   			try{
		 		   				String newID = itself.gc.roomIdTextFields.getText();
		  						String x_coord_str = itself.gc.currentPoint_Xcoord_textField.getText().trim();
		  						String y_coord_str = itself.gc.currentPoint_Ycoord_textField.getText().trim();
		 		   				
		 		   				if ((!itself.gc.rooms.isIdInList(newID)) || (itself.gc.rooms.isIdInList(newID) && newID.equals(itself.getRoomId()))){
		  							if ((!y_coord_str.equals("")) && (!x_coord_str.equals("")))
		  							{
		  								Double x_coord_new = Double.parseDouble(itself.gc.currentPoint_Xcoord_textField.getText());
				  						Double y_coord_new = Double.parseDouble(itself.gc.currentPoint_Ycoord_textField.getText());
				  						currentlySelectedPoint.setCenterX(x_coord_new);currentlySelectedPoint.setCenterY(y_coord_new);
		  							}
		  							itself.roomID = newID;	
		  							
		  							itself.gc.setMessage(true, "Changes successfully saved", itself.gc.resetIdLabel);
		  						}else itself.gc.setMessage(false, "ID already Exists", itself.gc.resetIdLabel);
		  					}
		  					catch (Exception exception){
		  						itself.gc.setMessage(false, "Invalid input", itself.gc.resetIdLabel);
		  					}
	 		   			}
		        	});
  		          
 		        }	
			}
        });
	}
	
	
	public Door getDoorByEdgeId(int edgeID){
		ArrayList<Door> doorArr = gc.doors.getDoors();
		for (int i = 0; i < doorArr.size(); ++i)
		{
			Door currentDoor = doorArr.get(i);
			if (roomDoors.contains(currentDoor) && currentDoor.getEdgeID() == edgeID) return currentDoor;
		}
		return null;
	}

	public Door getDoorByIndex(int index){
		for(int i = 0; i < roomDoors.size(); ++i)
			if(roomDoors.get(i).getEdgeID() == index) return roomDoors.get(i);
		return null;
	}
	
	public void removeDoorByIndex(int index){gc.doors.getDoors().remove(index);}
	public void removeDoor(Door door){gc.doors.getDoors().remove(door);}
	public void hide(){this.removeAnchorsFromPane(); gc.getMainPane().getChildren().remove(this.roomShape);}
	
	public void show(){
		for(int i = 0; i < roomAnchors.size(); i++){
			gc.getMainPane().getChildren().add(roomAnchors.get(i));
		}
		gc.getMainPane().getChildren().add(roomShape);
	}
	
	
	public AnchorDrawShape addAnchorCircle(){
		ObservableList<Double> currentPoints = roomShape.getPoints();
		AnchorDrawShape newPoint = createControlAnchorsFor(currentPoints);
		 roomAnchors.add(newPoint);
		 gc.allRoomAnchors.add(newPoint);
		return newPoint;
	}
	
	private AnchorDrawShape createControlAnchorsFor(final ObservableList<Double> points) {
    	
    	int index = points.size() - 2;
    
    	DoubleProperty xProperty = new SimpleDoubleProperty(points.get(index));
        DoubleProperty yProperty = new SimpleDoubleProperty(points.get(index + 1));
        
        xProperty.addListener(new ChangeListener<Number>() {
        	@Override
            public void changed(ObservableValue<? extends Number> ov, Number oldX, Number x) {
        		points.set(index, (double) x);
        		itself.gc.currentPoint_Xcoord_textField.setText(x + "");
        	}
         });

         yProperty.addListener(new ChangeListener<Number>() {
        	 @Override
             public void changed(ObservableValue<? extends Number> ov, Number oldY, Number y) {
        		 points.set(index + 1, (double) y);
        		 itself.gc.currentPoint_Ycoord_textField.setText(y + "");
        	 }
         });
         
         AnchorDrawShape a = new AnchorDrawShape(xProperty, yProperty, gc.allRoomAnchors, gc.anchorSize);
         setSelected();
         a.setOpacity(1);
         
         a.setOnMouseClicked(new EventHandler<MouseEvent>(){
 			@Override
 			public void handle(MouseEvent e) {
 				setSelected();
 				if (e.getButton() == MouseButton.PRIMARY){
 					currentlySelectedPoint = a;
 					itself.gc.currentPoint_Xcoord_textField.setText(points.get(index) + "");
 					itself.gc.currentPoint_Ycoord_textField.setText(points.get(index + 1) + "");
 					itself.gc.rooms.setCurrentActiveRoom(itself.gc.rooms.getCurrentActiveRoomIndex());
 					a.setSelected();
 					
 		        	itself.gc.saveRoom.setOnAction(new EventHandler<ActionEvent>(){
	 		   			@Override
	 					public void handle(ActionEvent event) {
	 		   				
			 		   		try{
		 		   				String newID = itself.gc.roomIdTextFields.getText();
		  						String x_coord_str = itself.gc.currentPoint_Xcoord_textField.getText().trim();
		  						String y_coord_str = itself.gc.currentPoint_Ycoord_textField.getText().trim();
		 		   				
		  						if ((!itself.gc.rooms.isIdInList(newID)) || (itself.gc.rooms.isIdInList(newID) && newID.equals(itself.getRoomId()))){
		  							if ((!y_coord_str.equals("")) && (!x_coord_str.equals("")))
		  							{
		  								Double x_coord_new = Double.parseDouble(itself.gc.currentPoint_Xcoord_textField.getText());
				  						Double y_coord_new = Double.parseDouble(itself.gc.currentPoint_Ycoord_textField.getText());
				  						currentlySelectedPoint.setCenterX(x_coord_new);currentlySelectedPoint.setCenterY(y_coord_new);
		  							}
		  							itself.roomID = newID;	
		
		  							itself.gc.setMessage(true, "Changes successfully saved", itself.gc.resetIdLabel);
		  						}else itself.gc.setMessage(false, "ID already Exists", itself.gc.resetIdLabel);
		  						
		  					}
		  					catch (Exception exception){itself.gc.setMessage(true, "Invalid input", itself.gc.resetIdLabel);}
	 		   			}
 		        	});
 				}
 		        e.consume();
 			}
         });
         
         currentlySelectedPoint = a;
         xPropertyListener.add(xProperty);
         yPropertyListener.add(yProperty);
         
         return a;
    }
	
	public void setUnselectedStyle(){
		roomShape.setStroke(Color.DARKCYAN);
		roomShape.setStrokeWidth(1);
		roomShape.setStrokeLineCap(StrokeLineCap.ROUND);
		roomShape.setFill(Color.CORNSILK.deriveColor(0, 1.2, 1, 0.6));
	}
	
	public void setSelectedStyle(){
		this.hide();
		this.show();
		roomShape.setStroke(Color.DARKGREEN);
		roomShape.setStrokeWidth(1);
		roomShape.setStrokeLineCap(StrokeLineCap.ROUND);
		roomShape.setFill(Color.AQUAMARINE.deriveColor(0, 1.2, 1, 0.6));
	}
	
	
	public ArrayList<DoubleProperty> getX_PropertyListener(){return this.xPropertyListener;}
	public ArrayList<DoubleProperty> getY_PropertyListener(){return this.yPropertyListener;}
	public void addValue(double value) {roomShape.getPoints().add(value);}
	public Polygon getRoomShape (){return roomShape;}
	public void setRoomID(String room_id){this.roomID = room_id;}
	public String getRoomId(){return this.roomID;}
	public void addAnchor (AnchorDrawShape anchor) {roomAnchors.add(anchor); gc.allRoomAnchors.add(anchor);}
	public void removeAnchor (AnchorDrawShape anchor) {roomAnchors.remove(anchor); gc.allRoomAnchors.remove(anchor);}
	public ArrayList<AnchorDrawShape> getAnchors () {return roomAnchors;}
	public ArrayList<Double> get_Xcoord(){return this.get_Xcoord();}
	public ArrayList<Double> get_Ycoord(){return this.get_Ycoord();}
	public Room getItself(){return this.itself;} 
	public void setSelected(){gc.roomIdTextFields.setText(roomID);gc.rooms.setSelectedRoom(itself);}
	public void removeAnchorsFromPane(){for(int i = 0 ; i < roomAnchors.size(); ++i)gc.getMainPane().getChildren().remove(roomAnchors.get(i));}
	public void removeAnchorsFromAllAchors(){for(int i = 0 ; i < roomAnchors.size(); ++i)gc.allRoomAnchors.remove(roomAnchors.get(i));}
	public void addDoor(Door door){gc.doors.addDoor(door); this.roomDoors.add(door);}
	public ArrayList<Door> getAllRoomDoors(){return roomDoors;}

}
