package rooms;

import java.util.ArrayList;

public class Rooms {
	private ArrayList<Room> rooms;
	private int currentActiveRoom;
	
	public Rooms(){
		this.rooms = new ArrayList<Room>();
		this.currentActiveRoom = -1;
	}
	
	public void addRoom(Room room){rooms.add(room);currentActiveRoom = rooms.size() - 1;}
	public void removeRoom(Room room){rooms.remove(room);}
	public void removeRoomByIndex(int index){rooms.remove(index);}
	public ArrayList<Room> getRooms(){return rooms;}
	public void setCurrentActiveRoom(int currentActiveRoom){this.currentActiveRoom = currentActiveRoom;}
	public int getCurrentActiveRoomIndex(){return this.currentActiveRoom;}
	public Room getCurrentActiveRoom(){return rooms.get(currentActiveRoom);}
	
	public boolean isIdInList(String id){
		for (int i = 0; i < rooms.size(); ++i) if (rooms.get(i).getRoomId().equals(id)) return true;
		return false;
	}
	
	public void setSelectedRoom(Room room){
		for(int i = 0; i < rooms.size(); ++i) 
			if (!(rooms.get(i).equals(room))) rooms.get(i).setUnselectedStyle();
			else {room.setSelectedStyle(); currentActiveRoom = i;}
	}
	
	
	public void hideAllRooms(){for(int i = 0; i < rooms.size(); ++i) rooms.get(i).hide();}
	public void showAllRooms(){for(int i = 0; i < rooms.size(); ++i) rooms.get(i).show();}
	
	
}
