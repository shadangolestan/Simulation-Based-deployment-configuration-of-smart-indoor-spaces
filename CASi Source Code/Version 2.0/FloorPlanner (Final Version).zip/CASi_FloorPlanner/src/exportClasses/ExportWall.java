package exportClasses;

import java.awt.Point;

public class ExportWall {
	private Point startPoint;
	private Point endPoint;
	
	public ExportWall(Point startPoint, Point endPoint){
		
	}
	
	public Point getStartPoint(){return this.startPoint;}
	public Point getEndPoint(){return this.endPoint;}

}
