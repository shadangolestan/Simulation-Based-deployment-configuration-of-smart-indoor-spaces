package exportClasses;

import java.awt.Point;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeSet;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import Action.Action;
import Action.Actions;
import ActivityDefinition.ActivityDefinition;
import ActivityDefinition.ActivityDefinitions;
import ActivityInsatnce.ActivityInstance;
import ActivityInsatnce.ActivityInstances;
import application.Agent;
import application.Agents;
import application.InteractableLine;
import application.Door;
import application.GroupController;
import javafx.beans.property.DoubleProperty;
import javafx.stage.FileChooser;
import obstacles.Obstacle;
import obstacles.Obstacles;
import places.Place;
import places.Places;
import rooms.Room;
import rooms.Rooms;
import sensors.Sensor;
import sensors.Sensors;

public class XML_Exporter {

	private GroupController gc;
	
	public XML_Exporter(GroupController gc){this.gc = gc;}
	
	public void generateRoomXML()
	{
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Save file");
		fileChooser.setInitialFileName("rooms.xml");
		
		File savedFile = fileChooser.showSaveDialog(gc.getMainPane().getScene().getWindow());

		if (savedFile != null)
			try{
				DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
				Document document = documentBuilder.newDocument();
				
				Element elementMap = document.createElement("rooms");
				document.appendChild(elementMap);
				
				writeOutDocument(generateRoomDocument(document, elementMap, gc.rooms), savedFile);
			}
			catch(ParserConfigurationException e){e.printStackTrace();}
	}
	
	public Document generateObstacleDocument(Document document, Element elementMap, Obstacles obstacles) throws ParserConfigurationException{
		ArrayList<Obstacle> exportObstacles = obstacles.getObstacles();
		for(int i = 0; i < exportObstacles.size(); ++i ){
			
			Element elementObstacle = document.createElement("obstacle");
			elementMap.appendChild(elementObstacle);
			
			Obstacle obstacleToExport = exportObstacles.get(i);
			String currentObstacleID = obstacleToExport.getObstacleId();
			Element elementObstacleID = document.createElement("obstacleid");
			elementObstacleID.setTextContent(currentObstacleID);
			
			elementObstacle.appendChild(elementObstacleID);
			
			
			ArrayList<DoubleProperty> xPropertyListenerExport = obstacleToExport.getX_PropertyListener();
			ArrayList<DoubleProperty> yPropertyListenerExport = obstacleToExport.getY_PropertyListener();


			for (int j = 0; j < xPropertyListenerExport.size() - 1; ++j){
				
				Element elementWall = document.createElement("wall");
				
				Element elementPoint1 = document.createElement("point");
				Element xCoord1 = document.createElement("xcoord");
				xCoord1.setTextContent((int)Math.round(xPropertyListenerExport.get(j).intValue() * gc.scale) + "");
				Element yCoord1 = document.createElement("ycoord");
				yCoord1.setTextContent((int)Math.round(yPropertyListenerExport.get(j).intValue() * gc.scale) + "");
				elementPoint1.appendChild(xCoord1);
				elementPoint1.appendChild(yCoord1);
				
				Element elementPoint2 = document.createElement("point");
				Element xCoord2 = document.createElement("xcoord");
				xCoord2.setTextContent((int)Math.round(xPropertyListenerExport.get(j+1).intValue() * gc.scale) + "");
				Element yCoord2 = document.createElement("ycoord");
				yCoord2.setTextContent((int)Math.round(yPropertyListenerExport.get(j+1).intValue() * gc.scale) + "");
				elementPoint2.appendChild(xCoord2);
				elementPoint2.appendChild(yCoord2);
				
				elementWall.appendChild(elementPoint1);
				elementWall.appendChild(elementPoint2);
				
				
				elementObstacle.appendChild(elementWall);
			}
			
			Element elementWall = document.createElement("wall");
			
	
			Element elementPoint1 = document.createElement("point");
			Element xCoord1 = document.createElement("xcoord");
			xCoord1.setTextContent((int)Math.round(xPropertyListenerExport.get(xPropertyListenerExport.size() - 1).intValue() * gc.scale) + "");
			Element yCoord1 = document.createElement("ycoord");
			yCoord1.setTextContent((int)Math.round(yPropertyListenerExport.get(xPropertyListenerExport.size() - 1).intValue() * gc.scale) + "");
			elementPoint1.appendChild(xCoord1);
			elementPoint1.appendChild(yCoord1);
			
			Element elementPoint2 = document.createElement("point");
			Element xCoord2 = document.createElement("xcoord");
			xCoord2.setTextContent((int)Math.round(xPropertyListenerExport.get(0).intValue() * gc.scale) + "");
			Element yCoord2 = document.createElement("ycoord");
			yCoord2.setTextContent((int)Math.round(yPropertyListenerExport.get(0).intValue() * gc.scale) + "");
			elementPoint2.appendChild(xCoord2);
			elementPoint2.appendChild(yCoord2);
			
			
			elementWall.appendChild(elementPoint1);
			elementWall.appendChild(elementPoint2);
			
			
			elementObstacle.appendChild(elementWall);
			
		}
		return document;
	}
	
	
	private boolean areClockwise(ArrayList<DoubleProperty> xProp, ArrayList<DoubleProperty> yProp, TreeSet<ExportWall> exportedWalls)
	{
		// check if 
		for(int i = 0; i < xProp.size() - 1; ++i)
		{
			Point point1 = new Point();
			point1.setLocation(xProp.get(i).doubleValue(), yProp.get(i).doubleValue());
			
			Point point2 = new Point();
			point1.setLocation(xProp.get(i + 1).doubleValue(), yProp.get(i + 1).doubleValue());
			
			ExportWall wallTemp1 = new ExportWall(point1, point2);
			ExportWall wallTemp2 = new ExportWall(point2, point1);
			
			if (exportedWalls.contains(wallTemp1)) return true;
			if (exportedWalls.contains(wallTemp2)) return false;
		}
		
		
		int cwCounter = 0;
		for(int i = 0; i < xProp.size() - 1; ++i)
		{
			double deltaX = xProp.get(i + 1).doubleValue() - xProp.get(i).doubleValue();
			double deltaY = yProp.get(i + 1).doubleValue() - yProp.get(i).doubleValue();
			double total = deltaX * deltaY;
			
			if (total > 0) cwCounter ++;
			else if (total < 0) cwCounter--;
		}
		
		if ((xProp.size() - cwCounter) > cwCounter) return false;
		
		return true;
	}
	
	public ArrayList<DoubleProperty>  reverePointOrder(ArrayList<DoubleProperty> points){
		ArrayList<DoubleProperty> newPoints = new ArrayList<DoubleProperty>();
		
		for (int i = points.size() - 1; i >= 0 ; --i) newPoints.add(points.get(i));
		
		return newPoints;
	}
	
	
	public Document generateRoomDocument(Document document, Element elementMap, Rooms rooms) throws ParserConfigurationException{
		
		ArrayList<Room> exportRooms = rooms.getRooms();
		
		if (exportRooms == null || exportRooms.size() == 0)return document;
		
	//	TreeSet<ExportWall> exportedWalls = new TreeSet<ExportWall>();
		
//		Room curentRoom = exportRooms.get(0);
//		exportRooms.remove(curentRoom);
//		
//		while (exportRooms.size() > 0){}
		
		/*
		ArrayList<Room> exportRooms_temp = rooms.getRooms();
		
		exportRooms_temp.add(exportRooms.get(0));
		exportRooms.remove(0);
		
		while (exportRooms.size() > 0){
			
			// search for room with the ajacent wall
			boolean adjFound = false;
			
			for (int i = 0; ((i < exportRooms.size()) && (adjFound)); ++i){
				
			}
			
		}*/
		
		
		
		for(int i = 0; i < exportRooms.size(); ++i ){
			
			Element elementRoom = document.createElement("room");
			elementMap.appendChild(elementRoom);
			
			Room roomToExport = exportRooms.get(i);
			String currentRoomID = roomToExport.getRoomId();
			
			Element elementRoomID = document.createElement("roomid");
			elementRoomID.setTextContent(currentRoomID);
			
			elementRoom.appendChild(elementRoomID);
			
			
			ArrayList<DoubleProperty> xPropertyListenerExport = roomToExport.getX_PropertyListener();
			ArrayList<DoubleProperty> yPropertyListenerExport = roomToExport.getY_PropertyListener();
			
			// check if room points are in clock-wise direction
			boolean isClockwiseOrder = true; //= areClockwise(xPropertyListenerExport, yPropertyListenerExport, exportedWalls);

			// reverse the order if false 
			if (!isClockwiseOrder){
				xPropertyListenerExport = reverePointOrder(xPropertyListenerExport);
				yPropertyListenerExport = reverePointOrder(yPropertyListenerExport);
			}
			
			for (int j = 0; j < xPropertyListenerExport.size() - 1; ++j){
				
				Element elementWall = document.createElement("wall");
				
				Element elementPoint1 = document.createElement("point");
				int xCoordInt1 = (int)Math.round(xPropertyListenerExport.get(j).doubleValue()* gc.scale);
				int yCoordInt1 = (int)Math.round(yPropertyListenerExport.get(j).doubleValue()* gc.scale);
				Element xCoord1 = document.createElement("xcoord");
				xCoord1.setTextContent((xCoordInt1) + "");
				Element yCoord1 = document.createElement("ycoord");
				yCoord1.setTextContent((yCoordInt1) + "");
				elementPoint1.appendChild(xCoord1);
				elementPoint1.appendChild(yCoord1);
				
				Element elementPoint2 = document.createElement("point");
				int xCoordInt2 = (int)Math.round(xPropertyListenerExport.get(j+1).doubleValue() * gc.scale);
				int yCoordInt2 = (int)Math.round(yPropertyListenerExport.get(j+1).doubleValue() * gc.scale);
				Element xCoord2 = document.createElement("xcoord");
				xCoord2.setTextContent((xCoordInt2) + "");
				Element yCoord2 = document.createElement("ycoord");
				yCoord2.setTextContent((yCoordInt2) + "");
				elementPoint2.appendChild(xCoord2);
				elementPoint2.appendChild(yCoord2);
				
				elementWall.appendChild(elementPoint1);
				elementWall.appendChild(elementPoint2);
				
				Point point1 = new Point();
				point1.setLocation(xPropertyListenerExport.get(j).doubleValue(), yPropertyListenerExport.get(j).doubleValue());
				Point point2 = new Point();
				point2.setLocation(xPropertyListenerExport.get(j+1).doubleValue(), yPropertyListenerExport.get(j+1).doubleValue());
				
				//exportedWalls.add(new ExportWall(point1, point2));
				
				
				Door currentDoorToExport = roomToExport.getDoorByEdgeId(j);
				if (currentDoorToExport != null){
					Element elementDoor = document.createElement("door");
					
					Element elementDoorID = document.createElement("doorid");
					elementDoorID.setTextContent(currentDoorToExport.getDoorID());

					Element elementDoorX = document.createElement("xcoord");
					elementDoorX.setTextContent(((int)Math.round(currentDoorToExport.getX() * gc.scale)) + "");
					Element elementDoorY = document.createElement("ycoord");
					elementDoorY.setTextContent(((int)Math.round(currentDoorToExport.getY() * gc.scale)) + "");
					//
					//
					Element elementDoorSize = document.createElement("doorsize");
					elementDoorSize.setTextContent((int)(Double.parseDouble(currentDoorToExport.getDoorSize()) * gc.scale) + "");
					//
					elementDoor.appendChild(elementDoorID);
					//elementDoor.appendChild(elementDoorOffset);
					elementDoor.appendChild(elementDoorX);
					elementDoor.appendChild(elementDoorY);
					elementDoor.appendChild(elementDoorSize);
					elementWall.appendChild(elementDoor);
					
				}
				elementRoom.appendChild(elementWall);
			}
			
			Element elementWall = document.createElement("wall");
			
			Element elementPoint1 = document.createElement("point");
			Element xCoord1 = document.createElement("xcoord");
			xCoord1.setTextContent((int)Math.round(xPropertyListenerExport.get(xPropertyListenerExport.size() - 1).intValue() * gc.scale) + "");
			Element yCoord1 = document.createElement("ycoord");
			yCoord1.setTextContent((int)Math.round(yPropertyListenerExport.get(xPropertyListenerExport.size() - 1).intValue() * gc.scale) + "");
			elementPoint1.appendChild(xCoord1);
			elementPoint1.appendChild(yCoord1);
			
			Element elementPoint2 = document.createElement("point");
			Element xCoord2 = document.createElement("xcoord");
			xCoord2.setTextContent((int)Math.round(xPropertyListenerExport.get(0).intValue() * gc.scale) + "");
			Element yCoord2 = document.createElement("ycoord");
			yCoord2.setTextContent((int)Math.round(yPropertyListenerExport.get(0).intValue() * gc.scale) + "");
			elementPoint2.appendChild(xCoord2);
			elementPoint2.appendChild(yCoord2);
			
			elementWall.appendChild(elementPoint1);
			elementWall.appendChild(elementPoint2);
			
			Door currentDoorToExport = roomToExport.getDoorByEdgeId(xPropertyListenerExport.size() - 1);
			if (currentDoorToExport != null){
				Element elementDoor = document.createElement("door");
				
				Element elementDoorID = document.createElement("doorid");
				elementDoorID.setTextContent(currentDoorToExport.getDoorID());

				Element elementDoorX = document.createElement("xcoord");
				elementDoorX.setTextContent(((int)Math.round(currentDoorToExport.getX() * gc.scale)) + "");
				Element elementDoorY = document.createElement("ycoord");
				elementDoorY.setTextContent(((int)Math.round(currentDoorToExport.getY() * gc.scale)) + "");
				//
				//
				Element elementDoorSize = document.createElement("doorsize");
				elementDoorSize.setTextContent(currentDoorToExport.getDoorSize());
				//
				elementDoor.appendChild(elementDoorID);
				elementDoor.appendChild(elementDoorX);
				elementDoor.appendChild(elementDoorY);
				elementDoor.appendChild(elementDoorSize);
				
				elementWall.appendChild(elementDoor);
				
			}
			elementRoom.appendChild(elementWall);
			
		}
		
		return document;
	}
	
	
	

	public void generateSensorXML(int precision)
	{
		
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Save file");
		fileChooser.setInitialFileName("defaultFile");
		File savedFile = fileChooser.showSaveDialog(gc.getMainPane().getScene().getWindow());

		if (savedFile != null) 
			try{
				DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
				Document document = documentBuilder.newDocument();

				Element elementSensors = document.createElement("sensors");
				document.appendChild(elementSensors);
			
				writeOutDocument(generateSensorDocument(document, elementSensors, gc.sensors, precision), savedFile);
			}
			catch(ParserConfigurationException e){e.printStackTrace();}
	}
	
	public double getMagnitude (double x1, double y1, double x2, double y2){
		return (Math.sqrt(Math.pow((x1 - x2), 2) + Math.pow((y1 - y2), 2)));
	}
	
	public Document generateSensorDocument(Document document, Element elementSensors, Sensors sensors, int precision) throws ParserConfigurationException
	{
		// got to tired so hard-coded Must be written as a Math function
		// Section start
		double coef_temp = 0.1;
		
		if (precision == 100) coef_temp = 1;
		else if (precision == 10) coef_temp = 10;
		
		// Section end
		
		ArrayList<Sensor> exportSensors = sensors.getSensors();
		
		for(int i = 0; i < exportSensors.size(); ++i ){
			
			Element elementCurrentSensor = document.createElement("sensor");
			elementSensors.appendChild(elementCurrentSensor);
			
			Sensor sensorToExport = exportSensors.get(i);
			
			String sensorID = sensorToExport.getSensorId();
			Element elementSensorID = document.createElement("id");
			elementSensorID.setTextContent(sensorID);
			
			String sensorXCoord = (int) (Math.round(sensorToExport.getImageView().getLayoutX() * gc.scale)) + "";
			String sensorYCoord = (int) (Math.round(sensorToExport.getImageView().getLayoutY() * gc.scale)) + "";
					
			Element elementSensorPoint = document.createElement("point");
			//elementSensorPoint.setTextContent(sensorXCoord + " " + sensorYCoord);
			Element xCoord = document.createElement("xcoord");
			xCoord.setTextContent(sensorXCoord);
			Element yCoord = document.createElement("ycoord");
			yCoord.setTextContent(sensorYCoord);
			elementSensorPoint.appendChild(xCoord);
			elementSensorPoint.appendChild(yCoord);
			
			String sensorType = sensorToExport.getImageView().getId();
			if (sensorType.length() > 2 && sensorType.substring(sensorType.length() - 3, sensorType.length()).equals("Old")) 
				sensorType = sensorType.substring(0, sensorType.length() - 3);

			elementCurrentSensor.appendChild(elementSensorID);
			elementCurrentSensor.appendChild(elementSensorPoint);
			Element elementSensorType = document.createElement("type");
			elementSensorType.setTextContent(sensorType);
			elementCurrentSensor.appendChild(elementSensorType);
			/*
			
			
			String sensorRadius = sensorToExport.getRadius();
			Element elementSensorRadius = document.createElement("radius");
			elementSensorRadius.setTextContent(sensorRadius);
			
			elementCurrentSensor.appendChild(elementSensorRadius);
			*/
			
			Iterator it = sensorToExport.sensorFieldValues.entrySet().iterator();
            while (it.hasNext()) {
				Map.Entry pair = (Map.Entry)it.next();
				String key = pair.getKey().toString();
				if ((!key.equals("sensorid")) && (!key.equals("xcoord")) && (!key.equals("ycoord"))){
					
					
					Element customSensorElement = document.createElement(key);
					if (key.equals("radius"))
					{
						
						//Double distanceCalLine = gc.horizontalCalibrationLine.getDistance();
						
						
						
						// calculate the number of points in a meter
						//double coefficient =  distanceCalLine /Double.parseDouble(pair.getValue().toString());// * 1000;
						
					 
						//double numPoints = Double.parseDouble(pair.getValue().toString()) / coefficient;
						
						double distanceMeters = Double.parseDouble(pair.getValue().toString());
						
						double horCalLineDistance = gc.horizontalCalibrationLine.getDistance();
						
						double horCalLinePointDiff = gc.horizontalCalibrationLine.getPointDifference();
						
						double numPoints  = (horCalLinePointDiff * distanceMeters) / horCalLineDistance;
						//System.out.println("Point Diff: " + horCalLinePointDiff);
						//System.out.println("Calib Line Distance: " + horCalLineDistance);
						//System.out.println("numPoints: " + numPoints);
						//System.out.println("precission: " + precision);
						//System.out.println("==================================================" + coef_temp);
						
						customSensorElement.setTextContent((int) Math.round(numPoints / coef_temp) + "");
					}
					else
					{
						customSensorElement.setTextContent(pair.getValue().toString());
					}

					elementCurrentSensor.appendChild(customSensorElement);
				}
				
            }
		}
		return document;
	}
	
	
	public void generateLocationXML()
	{
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Save file");
		fileChooser.setInitialFileName("locations.xml");
		File savedFile = fileChooser.showSaveDialog(gc.getMainPane().getScene().getWindow());

		if (savedFile != null)
			try{
				DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
				Document document = documentBuilder.newDocument();

				Element elementPlaces = document.createElement("locations");
				document.appendChild(elementPlaces);
				
				writeOutDocument(generateLocationDocument(document, elementPlaces, gc.places), savedFile);
			}
			catch(ParserConfigurationException e){e.printStackTrace();}
	}
	
	
	public Document generateLocationDocument(Document document, Element elementPlaces, Places places) throws ParserConfigurationException
	{
		ArrayList<Place> exportPlaces = places.getPlaces();

		for(int i = 0; i < exportPlaces.size(); ++i ){
	
			Element elementCurrentPlace = document.createElement("location");
			elementPlaces.appendChild(elementCurrentPlace);
		
			Place placeToExport = exportPlaces.get(i);
		
		
			String placeID = placeToExport.getPlaceId();
			Element elementPlaceID = document.createElement("id");
			elementPlaceID.setTextContent(placeID);
			elementCurrentPlace.appendChild(elementPlaceID);

		
			int placeX_coord = (int)Math.round(placeToExport.getImageView().getLayoutX() * gc.scale);
			int placeY_coord = (int)Math.round(placeToExport.getImageView().getLayoutY() * gc.scale);
		
			Element elementPlacePoint = document.createElement("point");
			//elementPlacePoint.setTextContent(((int)placeX_coord) + " " + ((int)placeY_coord));
			
			Element xCoord = document.createElement("xcoord");
			xCoord.setTextContent(placeX_coord + "");
			Element yCoord = document.createElement("ycoord");
			yCoord.setTextContent(placeY_coord + "");
			elementPlacePoint.appendChild(xCoord);
			elementPlacePoint.appendChild(yCoord);
			elementCurrentPlace.appendChild(elementPlacePoint);
		}
		return document;
	}
	
	
	
	public void generateAgentsXML()
	{
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Save file");
		fileChooser.setInitialFileName("agents.xml");
		File savedFile = fileChooser.showSaveDialog(gc.getMainPane().getScene().getWindow());

		if (savedFile != null) 
			try{
				DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
				Document document = documentBuilder.newDocument();

				Element elementAgents = document.createElement("agents");
				document.appendChild(elementAgents);
				
				writeOutDocument(generateAgentDocument(document, elementAgents, gc.agents), savedFile);				
			}
			catch(ParserConfigurationException e){e.printStackTrace();}
	}
	
	
	/**
	 * 
	 * @param pane
	 * @param agents
	 */
	public Document generateAgentDocument(Document document, Element elementAgents, Agents agents) throws ParserConfigurationException
	{
		
		ArrayList<Agent> exportAgents = agents.getAgents();

		for(int i = 0; i < exportAgents.size(); ++i ){
	
			Element elementCurrentAgent = document.createElement("agent");
			elementAgents.appendChild(elementCurrentAgent);
		
			Agent agentToExport = exportAgents.get(i);
		
		
			String agentID = agentToExport.getAgentId();
			Element elementAgentID = document.createElement("agentid");
			elementAgentID.setTextContent(agentID);
			elementCurrentAgent.appendChild(elementAgentID);

		
			String agentName = agentToExport.getAgentName();
			Element elementAgentName = document.createElement("agentname");
			elementAgentName.setTextContent(agentName);
			elementCurrentAgent.appendChild(elementAgentName);
		
			String agentRole = agentToExport.getAgentType();
			Element elementAgentRole = document.createElement("agentrole");
			elementAgentRole.setTextContent(agentRole);
			elementCurrentAgent.appendChild(elementAgentRole);
		
		
		
			int agentX_coord = (int)Math.round(agentToExport.getImageView().getLayoutX() * gc.scale);
			int agentY_coord = (int)Math.round(agentToExport.getImageView().getLayoutY() * gc.scale);
		
			Element elementAgentPoint = document.createElement("point");
			//elementAgentPoint.setTextContent(agentX_coord + " " + agentY_coord);
			
			Element xCoord = document.createElement("xcoord");
			xCoord.setTextContent(agentX_coord + "");
			Element yCoord = document.createElement("ycoord");
			yCoord.setTextContent(agentY_coord + "");
			elementAgentPoint.appendChild(xCoord);
			elementAgentPoint.appendChild(yCoord);
			
			
			elementCurrentAgent.appendChild(elementAgentPoint);
		}
		
		return document;
	}
	
	public void generateActionsXML()
	{
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Save file");
		fileChooser.setInitialFileName("actions.xml");
		File savedFile = fileChooser.showSaveDialog(gc.getMainPane().getScene().getWindow());

		if (savedFile != null) 
			try{
				DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
				Document document = documentBuilder.newDocument();

			
				// Create
				Element elementActions = document.createElement("actions");
				document.appendChild(elementActions);
				
				writeOutDocument(generateActionDocument(document, elementActions, gc.actions), savedFile);
			}
			catch(ParserConfigurationException e){e.printStackTrace();}
	}
	
	public Document generateActionDocument(Document document, Element elementActions, Actions actions) throws ParserConfigurationException
	{
	
		ArrayList<Action> exportActions = actions.getActions();

		for(int i = 0; i < exportActions.size(); ++i ){
	
			Element elementCurrentAction = document.createElement("action");
			elementActions.appendChild(elementCurrentAction);
		
			Action actionToExport = exportActions.get(i);
		
		
			String actionDate = actionToExport.getActionDate();
		
			String[] actionDate_arr = actionDate.split("-");
			if (actionDate_arr.length > 1)actionDate = (actionDate_arr[1] + "/" + actionDate_arr[2] + "/" + actionDate_arr[0]);
			Element elementActionDate = document.createElement("actionDate");
			elementActionDate.setTextContent(actionDate);
			elementCurrentAction.appendChild(elementActionDate);
			
			String actionTime = actionToExport.getTime();
			Element elementActionTime = document.createElement("actionTime");
			elementActionTime.setTextContent(actionTime);
			elementCurrentAction.appendChild(elementActionTime);
			
			String actionID = actionToExport.getActionId();
			Element elementActionID = document.createElement("id");
			elementActionID.setTextContent(actionID);
			elementCurrentAction.appendChild(elementActionID);

			String agentID = actionToExport.getAgentID();
			Element elementAgentID = document.createElement("agentID");
			elementAgentID.setTextContent(agentID);
			elementCurrentAction.appendChild(elementAgentID);
		
			
			Element elementSubactions = document.createElement("subactions");
			elementCurrentAction.appendChild(elementSubactions);
			
			/*
			Element elementSubaction = document.createElement("subaction");
			elementSubactions.appendChild(elementSubaction);
			
			String actionType = actionToExport.getActionType();
			Element elementActionType = document.createElement("actionType");
			elementActionType.setTextContent(actionType);
			elementSubaction.appendChild(elementActionType);
			
			
			String target = actionToExport.getTarget();
			Element elementTarget = document.createElement("target");
			elementTarget.setTextContent(target);
			elementSubaction.appendChild(elementTarget);
			*/
			
			ArrayList<Action> subActions = actionToExport.getSubactions();
			
			if (subActions != null){
				for(int subActionsInx = 1; subActionsInx < subActions.size(); ++subActionsInx){
					Action currentSubAction = subActions.get(subActionsInx);
					
					String subActionType = currentSubAction.getActionType();
					Element elementSubActionType = document.createElement("actionType");
					elementSubActionType.setTextContent(subActionType);
					
					//String subActionTarget = currentSubAction.getTarget();
					//Element elementSubActionTarget = document.createElement("target");
					//elementSubActionTarget.setTextContent(subActionTarget);
					
				
					Element elementSubactionTemp = document.createElement("subaction");
					elementSubactions.appendChild(elementSubactionTemp);
					
					elementSubactionTemp.appendChild(elementSubActionType);
					//elementSubactionTemp.appendChild(elementSubActionTarget);
					
					elementSubactions.appendChild(elementSubactionTemp);
				}
			}

		}
		
		return document;
	}
	
	
	
	public Document generateActivityInstanceDocument(Document document, Element elementActivityInstances, ActivityInstances actInstances) throws ParserConfigurationException
	{
	
		ArrayList<ActivityInstance> exportActivityInstances = actInstances.getactivityInstancies();

		for(int i = 0; i < exportActivityInstances.size(); ++i ){
	
			Element elementCurrentActivitInstance = document.createElement("activityInstance");
			elementActivityInstances.appendChild(elementCurrentActivitInstance);
			
			ActivityInstance activityInstToExport = actInstances.getactivityInstancies().get(i);
			
			/*
			Element elementActDefName = document.createElement("activityDefinitionName");
			elementActDefName.setTextContent(activityDefToExport.getActivityId());
			elementCurrentActivityDefinition.appendChild(elementActDefName);
		
			
			Element elementActDefIsComplex = document.createElement("isComplexActDefinition");
			elementActDefIsComplex.setTextContent(isComplexAction);
			elementCurrentActivityDefinition.appendChild(elementActDefIsComplex);
			*/
			
			Element elementActInstName = document.createElement("activityInstName");
			elementActInstName.setTextContent(activityInstToExport.getActivityInstanceId());
			elementCurrentActivitInstance.appendChild(elementActInstName);
			
			Element elementSubActInstances = document.createElement("SubActivityInstances");
			//elementActDefIsComplex.setTextContent(isComplexAction);
			elementCurrentActivitInstance.appendChild(elementSubActInstances);
			
			ArrayList<String> subActInsts = activityInstToExport.getActivityDefinitions();
			ArrayList<String> inst_targets = activityInstToExport.getTargets();
			ArrayList<String> inst_actionParameters = activityInstToExport.getActionParameter();
			
					
			if (subActInsts != null){
				for(int subActivityIndx = 0; subActivityIndx < subActInsts.size(); ++subActivityIndx){
					Element elementSubActInstance = document.createElement("SubActivityInstance");
					//elementActDefIsComplex.setTextContent(isComplexAction);
					elementSubActInstances.appendChild(elementSubActInstance);
					
					String currentActInstance = subActInsts.get(subActivityIndx);
					
					String subActivityID = "";
					
					if (currentActInstance != null){
						subActivityID = currentActInstance;
					}else subActivityID = activityInstToExport.getActivityInstanceId();
						

					Element elementSubActivityID = document.createElement("activityID");
					elementSubActivityID.setTextContent(subActivityID);
					elementSubActInstance.appendChild(elementSubActivityID);
					
					
					String instance_target = inst_targets.get(subActivityIndx);
					Element elementSubActivityTarget = document.createElement("target");
					elementSubActivityTarget.setTextContent(instance_target);
					elementSubActInstance.appendChild(elementSubActivityTarget);
					
					String instance_actionParameter = inst_actionParameters.get(subActivityIndx);
					Element elementSubActivityActionParameter = document.createElement("actionParameter");
					elementSubActivityActionParameter.setTextContent(instance_actionParameter);
					elementSubActInstance.appendChild(elementSubActivityActionParameter);
				}
			}

		}
		
		return document;
	}
	
	
	
	public Document generateActivityDefDocument(Document document, Element elementActivityDefinitions, ActivityDefinitions actDefs) throws ParserConfigurationException
	{
	
		ArrayList<ActivityDefinition> exportActivities = actDefs.getActivities();

		for(int i = 0; i < exportActivities.size(); ++i ){
	
			Element elementCurrentActivityDefinition = document.createElement("activityDefinition");
			elementActivityDefinitions.appendChild(elementCurrentActivityDefinition);
		
			ActivityDefinition activityDefToExport = exportActivities.get(i);
			
			String isComplexAction = "N";
			
			if(activityDefToExport.isComplexActivity()) isComplexAction = "Y";
			
			Element elementActDefName = document.createElement("activityDefinitionName");
			elementActDefName.setTextContent(activityDefToExport.getActivityId());
			elementCurrentActivityDefinition.appendChild(elementActDefName);
		
			
			Element elementActDefIsComplex = document.createElement("isComplexActDefinition");
			elementActDefIsComplex.setTextContent(isComplexAction);
			elementCurrentActivityDefinition.appendChild(elementActDefIsComplex);
			
			
			Element elementSubActDefs = document.createElement("SubActivityDefinitions");
			//elementActDefIsComplex.setTextContent(isComplexAction);
			elementCurrentActivityDefinition.appendChild(elementSubActDefs);
			
			ArrayList<String> subActivitiesDefs = activityDefToExport.getSubactivities();
			
			
			////
			Element elementSubActDefRoot = document.createElement("SubActivityDefinition");
			//elementActDefIsComplex.setTextContent(isComplexAction);
			elementSubActDefs.appendChild(elementSubActDefRoot);
			
			String subActivityIDRoot = activityDefToExport.getActivityId();
			Element elementSubActivityIDRoot = document.createElement("activityID");
			elementSubActivityIDRoot.setTextContent(subActivityIDRoot);
			elementSubActDefRoot.appendChild(elementSubActivityIDRoot);
			
			
			Element elementSubActivityTypeRoot = document.createElement("activityType");
			elementSubActivityTypeRoot.setTextContent(activityDefToExport.getActivityType());
			elementSubActDefRoot.appendChild(elementSubActivityTypeRoot);
			////
			
			
			if (subActivitiesDefs != null){
				for(int subActivityIndx = 0; subActivityIndx < subActivitiesDefs.size(); ++subActivityIndx){
					Element elementSubActDef = document.createElement("SubActivityDefinition");
					//elementActDefIsComplex.setTextContent(isComplexAction);
					elementSubActDefs.appendChild(elementSubActDef);
					
					String currentActDef = subActivitiesDefs.get(subActivityIndx);
					
					String subActivityID = currentActDef;//.getActivityId();
					Element elementSubActivityID = document.createElement("activityID");
					elementSubActivityID.setTextContent(subActivityID);
					elementSubActDef.appendChild(elementSubActivityID);
					
					
					String subActivityType = gc.activities.getActivityByID(currentActDef).getActivityType();
					Element elementSubActivityType = document.createElement("activityType");
					elementSubActivityType.setTextContent(subActivityType);
					elementSubActDef.appendChild(elementSubActivityType);
				}
			}

		}
		
		return document;
	}
	
	
	public void writeOutDocument(Document document, File savedFile)
	{
		try {
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer;
			
			
			transformer = transformerFactory.newTransformer();
			
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty(OutputKeys.METHOD, "xml");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
			
			DOMSource source = new DOMSource(document);
			
			StreamResult streamResult = new StreamResult(new File(savedFile.getAbsolutePath()));
			
			transformer.transform(source, streamResult);
			
		} catch (TransformerConfigurationException e) {e.printStackTrace();}
		catch (TransformerException e) {e.printStackTrace();}
	}
	
	public void generateSimulatedWorldXML(int precission)
	{
		
		
		
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Save file");
		fileChooser.setInitialFileName("simulationWorld.xml");
		File savedFile = fileChooser.showSaveDialog(gc.getMainPane().getScene().getWindow());

		if (savedFile != null) 
			try{
				DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
				Document document = documentBuilder.newDocument();
				
			
				
				Element elementWorld = document.createElement("simulatedworld");
				document.appendChild(elementWorld);
			
				// precission 
				
				Element elementPrecission = document.createElement("precission");
				elementWorld.appendChild(elementPrecission);
				document = generatePrecisionDocument(document, elementPrecission, precission);
				
				
				//horizontalCalibrationLine
				if (gc.horizontalCalibrationLine != null){
					Element elementHorCalibr = document.createElement("horCalibr");
					elementWorld.appendChild(elementHorCalibr);
					document = generateHorCalibrDocument(document, elementHorCalibr, gc.horizontalCalibrationLine, precission);
				}
				
				Element elementActivityDef = document.createElement("activityDefinitions");
				elementWorld.appendChild(elementActivityDef);
				document = generateActivityDefDocument(document, elementActivityDef, gc.activities);
				
				Element elementActivityInstances = document.createElement("activityInstances");
				elementWorld.appendChild(elementActivityInstances);
				document = generateActivityInstanceDocument(document, elementActivityInstances, gc.activityInstances);
				
				Element elementActions = document.createElement("actions");
				elementWorld.appendChild(elementActions);
				document = generateActionDocument(document, elementActions, gc.actions);
				
				
				Element elementAgents = document.createElement("agents");
				elementWorld.appendChild(elementAgents);
				document = generateAgentDocument(document, elementAgents, gc.agents);
				
				
				
				Element elementRooms = document.createElement("rooms");
				elementWorld.appendChild(elementRooms);
				document = generateRoomDocument(document, elementRooms, gc.rooms);
				
				Element elementObstacles = document.createElement("obstacles");
				elementWorld.appendChild(elementObstacles);
				document = generateObstacleDocument(document, elementObstacles, gc.obstacles);
				
				
				Element elementLocations = document.createElement("locations");
				elementWorld.appendChild(elementLocations);
				document = generateLocationDocument(document, elementLocations, gc.places);
				
				
				Element elementSensors = document.createElement("sensors");
				elementWorld.appendChild(elementSensors);
				document = generateSensorDocument(document, elementSensors, gc.sensors, precission);
				
				Element elementMQTT_ConnectionInfo = document.createElement("mqtt_broker");
				elementWorld.appendChild(elementMQTT_ConnectionInfo);
				document = generate_mqtt_Document(document, elementMQTT_ConnectionInfo, gc);
				
				Element elementSimStartTime = document.createElement("sim_start_time");
				elementWorld.appendChild(elementSimStartTime);
				document = generateSimStartTimeXML(document, elementSimStartTime, gc);
				
				writeOutDocument(document, savedFile);
			}
			catch(ParserConfigurationException e){e.printStackTrace();}
	}
	
	
	public Document generateSimStartTimeXML(Document document, Element elementSimStartTime, GroupController gc) throws ParserConfigurationException
	{
		Element elementStartDate = document.createElement("simStartDate");
		elementSimStartTime.appendChild(elementStartDate);
		elementStartDate.setTextContent(gc.simStartDate);
		
		
		Element elementStartTime = document.createElement("simStartTime");
		elementSimStartTime.appendChild(elementStartTime);
		elementStartTime.setTextContent(gc.simStartTime);
		
		
	
		return document;
	}
	
	
	public Document generate_mqtt_Document(Document document, Element elementMqttConnectionInfo, GroupController gc) throws ParserConfigurationException
	{
		Element elementIpAddress = document.createElement("ip_address");
		elementMqttConnectionInfo.appendChild(elementIpAddress);
		elementIpAddress.setTextContent(gc.ip_TextField.getText());
		
		Element elementPort = document.createElement("port");
		elementMqttConnectionInfo.appendChild(elementPort);
		elementPort.setTextContent(gc.port_Text_Field.getText());
		
		Element elementProtocol = document.createElement("protocol");
		elementMqttConnectionInfo.appendChild(elementProtocol);
		elementProtocol.setTextContent(gc.protocol_TextField.getText());
	
		return document;
	}
	
	
	
	
	public Document generateHorCalibrDocument(Document document, Element elementCalibration, 
			InteractableLine horizontalCalibrationLine, int precission) throws ParserConfigurationException
	{
	
		
		ArrayList<DoubleProperty> xPoints = horizontalCalibrationLine.get_Xcoord();
		ArrayList<DoubleProperty> yPoints = horizontalCalibrationLine.get_Ycoord();
		Double distance = horizontalCalibrationLine.getDistance();
		
		double pointDiff = Math.abs(xPoints.get(1).doubleValue() - xPoints.get(0).doubleValue());
		
		// calculate the number of points in a meter
		double coefficient =  (distance / pointDiff) * precission;
		gc.scale = coefficient;
		
		Element elementPoint1 = document.createElement("point1");
		elementCalibration.appendChild(elementPoint1);
		
		
		Element elementPoint1X = document.createElement("xcoord");
		elementPoint1X.setTextContent(Math.round(xPoints.get(0).doubleValue() * gc.scale) + "");
		elementPoint1.appendChild(elementPoint1X);
		
		Element elementPoint1Y = document.createElement("ycoord");
		elementPoint1Y.setTextContent(Math.round(yPoints.get(0).doubleValue() * gc.scale) + "");
		elementPoint1.appendChild(elementPoint1Y);
		
		
		
		Element elementPoint2 = document.createElement("point2");
		elementCalibration.appendChild(elementPoint2);
		
		
		Element elementPoint2X = document.createElement("xcoord");
		elementPoint2X.setTextContent(Math.round(xPoints.get(1).doubleValue() * gc.scale) + "");
		elementPoint2.appendChild(elementPoint2X);
		
		Element elementPoint2Y = document.createElement("ycoord");
		elementPoint2Y.setTextContent(Math.round(yPoints.get(1).doubleValue() * gc.scale) + "");
		elementPoint2.appendChild(elementPoint2Y);
		
		
		Element elementDistance = document.createElement("distance");
		elementDistance.setTextContent(horizontalCalibrationLine.getDistance() + "");
		elementCalibration.appendChild(elementDistance);
		
		Element elementScale = document.createElement("scale");
		elementScale.setTextContent(coefficient + "");
		elementCalibration.appendChild(elementScale);

		return document;
	}
	
	
	
	public Document generatePrecisionDocument(Document document,  Element precissionElemet, int precision) throws ParserConfigurationException
	{
		precissionElemet.setTextContent(precision + "");
		return document;
	}
	
	
}
