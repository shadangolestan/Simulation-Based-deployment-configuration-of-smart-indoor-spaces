package importClasses;

//import java.awt.Point;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import java.util.Iterator;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import Action.Action;
import ActivityDefinition.ActivityDefinition;
import ActivityInsatnce.ActivityInstance;
import application.InteractableLine;
import application.Coordinates;
import application.Door;
import application.GroupController;
import geometry.Point;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import obstacles.Obstacle;
import rooms.Room;
import sensors.Sensor;

public class XML_Importer {
	String filePath;
	GroupController gc;
	
	
	@SuppressWarnings("unused")
	private XML_Importer(){}
	
	public XML_Importer(GroupController gc) {this.gc = gc; filePath = null;} 
	
	
	public void loadFile()
	{
		File file = (new FileChooser()).showOpenDialog(gc.getMainPane().getScene().getWindow());
		if (file != null) this.filePath = file.getAbsolutePath();
	}
	
	public void importActionDefinition()
	{
		if (filePath == null) return;
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document documentActivityDefinition = documentBuilder.parse(filePath);
			
			NodeList activityDefinitionsList = documentActivityDefinition.getElementsByTagName("activityDefinitions");
			Node activityDefinition = activityDefinitionsList.item(0);
			Element activityDefinitionsElem = (Element) activityDefinition;
			NodeList activityDefinitionList = activityDefinitionsElem.getElementsByTagName("activityDefinition");
			
			
			for (int actDefIndx = 0; actDefIndx < activityDefinitionList.getLength(); ++actDefIndx){
				Node actDef = activityDefinitionList.item(actDefIndx);
				Element actDefElem = (Element) actDef;
				
				String activityDefinitionName = actDefElem.getElementsByTagName("activityDefinitionName").item(0).getTextContent().trim();
				String isComplexActDefinition = actDefElem.getElementsByTagName("isComplexActDefinition").item(0).getTextContent().trim();
			
				
				NodeList subActivityDefsList = actDefElem.getElementsByTagName("SubActivityDefinitions");
				Node subActivityDefs = subActivityDefsList.item(0);
				Element subActivityDefsElem = (Element) subActivityDefs;
				NodeList subActivityDefList = subActivityDefsElem.getElementsByTagName("SubActivityDefinition");
				
				ArrayList<String> actDefs_arr = new ArrayList<String>();
				String activityType_root = "";
				for(int actSubDef = 0; actSubDef < subActivityDefList.getLength(); ++actSubDef){
					Node subActDef = subActivityDefList.item(actSubDef);
					Element subActDefElem = (Element) subActDef;
					String activityID = subActDefElem.getElementsByTagName("activityID").item(0).getTextContent().trim();
					String activityType = subActDefElem.getElementsByTagName("activityType").item(0).getTextContent().trim();
					
					if (actSubDef != 0)actDefs_arr.add(activityID);
					if (actSubDef == 0) activityType_root = activityType;
					
				}
				boolean isComplex = false;
				if (isComplexActDefinition.equals("Y")) isComplex = true;
				ActivityDefinition actDef_new = new ActivityDefinition(gc, !isComplex, activityDefinitionName, actDefs_arr, activityType_root);
				gc.activities.addActivity(actDef_new);

			}
		} catch (ParserConfigurationException e) {e.printStackTrace();} 
		catch (SAXException e) {e.printStackTrace();} 
		catch (IOException e) {e.printStackTrace();}
		
	}
	
	
	public void importActionInstances()
	{
		if (filePath == null) return;
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document documentActivityDefinition = documentBuilder.parse(filePath);
			
			NodeList activityInstancessList = documentActivityDefinition.getElementsByTagName("activityInstances");
			Node activityInstance = activityInstancessList.item(0);
			Element activityInstancesElem = (Element) activityInstance;
			NodeList activityInstanceList = activityInstancesElem.getElementsByTagName("activityInstance");
			
			
			for (int actInstIndx = 0; actInstIndx < activityInstanceList.getLength(); ++actInstIndx){
				Node actInst = activityInstanceList.item(actInstIndx);
				Element actInstElem = (Element) actInst;
				
				String activityInstName = actInstElem.getElementsByTagName("activityInstName").item(0).getTextContent().trim();
				
				
				NodeList subActivityInstancesList = actInstElem.getElementsByTagName("SubActivityInstances");
				Node subActivityInstances = subActivityInstancesList.item(0);
				Element subActivityInstanceElem = (Element) subActivityInstances;
				NodeList subActivityInstanceList = subActivityInstanceElem.getElementsByTagName("SubActivityInstance");
				
				//ArrayList<ActivityDefinition> actDefs_arr = new ArrayList<ActivityDefinition>();
				//String activityType_root = "";
				//ActivityInstance(GroupController gc, ArrayList<ActivityDefinition> activityDefinitions, ArrayList<String> targets, String id)
				 ArrayList<String> activityDefinitions = new ArrayList<String>();
				 ArrayList<String> targets = new ArrayList<String>();
				 ArrayList<String> actionParameter = new ArrayList<String>();
				 
				for(int actSubInstIndx = 0; actSubInstIndx < subActivityInstanceList.getLength(); ++actSubInstIndx){
					Node subActInst = subActivityInstanceList.item(actSubInstIndx);
					Element subActInstElem = (Element) subActInst;
					
					String activityID = subActInstElem.getElementsByTagName("activityID").item(0).getTextContent().trim();
					String target = subActInstElem.getElementsByTagName("target").item(0).getTextContent().trim();
					String timer = subActInstElem.getElementsByTagName("actionParameter").item(0).getTextContent().trim();
					
					targets.add(target);
					actionParameter.add(timer);
					activityDefinitions.add(activityID);
					
				}
				
				//if ((timers != null) && (timers.size() > 0))timers.remove(0);
				ActivityInstance actInst_new = new ActivityInstance(gc, activityDefinitions,  targets, actionParameter, activityInstName);
				gc.activityInstances.addActivityInstance(actInst_new);

			}
		} catch (ParserConfigurationException e) {e.printStackTrace();} 
		catch (SAXException e) {e.printStackTrace();} 
		catch (IOException e) {e.printStackTrace();}
		

	}
	
	
	public void importSensors()
	{
		try {
		
			File xmlFile = new File(filePath);
			DocumentBuilderFactory documentBuilderFactorySensors = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilderSensors = documentBuilderFactorySensors.newDocumentBuilder();
			Document documentSensors = documentBuilderSensors.parse(xmlFile);
			
			
			Element precisionElem = (Element) documentSensors.getElementsByTagName("precission").item(0);
			double precision = Double.parseDouble(precisionElem.getTextContent());
			
			
			NodeList sensorsList = documentSensors.getElementsByTagName("sensors");
			Node sensorsNode = sensorsList.item(0);
			Element sensorsElem = (Element) sensorsNode;
			
			NodeList sensorList = sensorsElem.getElementsByTagName("sensor");
			
			for (int sensorIndx = 0; sensorIndx < sensorList.getLength(); ++sensorIndx)
			{
				Node sensor = sensorList.item(sensorIndx);
				Element sensorElem = (Element) sensor;
				
				//String[] pointArr = sensorElem.getElementsByTagName("point").item(0).getTextContent().trim().split(" ");
				//Point point = new Point(Integer.parseInt(pointArr[0]), Integer.parseInt(pointArr[1]));
				Element pointElement = (Element)sensorElem.getElementsByTagName("point").item(0);
				Double xCoord = Double.parseDouble(pointElement.getElementsByTagName("xcoord").item(0).getTextContent().trim()) / gc.scale;
				Double yCoord = Double.parseDouble(pointElement.getElementsByTagName("ycoord").item(0).getTextContent().trim()) / gc.scale;
				
				
				Point point = new Point(xCoord, yCoord);
				
				String sensorType = sensorElem.getElementsByTagName("type").item(0).getTextContent().trim();
				//String sensrorRadius = (Double.parseDouble(sensorElem.getElementsByTagName("radius").item(0).getTextContent().trim()) / gc.scale) + "";
				String sensorID = sensorElem.getElementsByTagName("id").item(0).getTextContent().trim();
				
				ImageView currentSensorImageView  = new ImageView();
				
				try {
					File file = new File("@../../Sensors/" + sensorType + "/Image/image.png");
					URL url = file.toURI().toURL();
					currentSensorImageView.setImage(new Image(url.toExternalForm()));
					currentSensorImageView.setLayoutX(point.x);
					currentSensorImageView.setLayoutY(point.y);
					currentSensorImageView.setId(sensorType);
				} catch (MalformedURLException e) {e.printStackTrace();}
				
				
				gc.configSensor(currentSensorImageView, true);
				currentSensorImageView.setLayoutX(point.x);
				currentSensorImageView.setLayoutY(point.y);
				Coordinates coord = new Coordinates();
				coord.setX(point.x);
				coord.setY(point.y);
				
				Sensor lastSensor = gc.sensors.getSensors().get(gc.sensors.getSensors().size() - 1);
				
				lastSensor.setImageView(currentSensorImageView);
				lastSensor.setImageViewListeners();
				lastSensor.populateSensoerTextFields();
				gc.getMainPane().getChildren().add(currentSensorImageView);
				
			
				double coef_temp = 0.01;	
				if (precision == 100) coef_temp = 0.1;
				else if (precision == 10) coef_temp = 1;
				
				NodeList sensotSpecNodeList = sensorElem.getChildNodes();
				for(int attrIndex = 0; attrIndex < sensotSpecNodeList.getLength(); attrIndex++){
				
					if (!sensotSpecNodeList.item(attrIndex).getNodeName().equals("#text")){
					

						String specName = sensotSpecNodeList.item(attrIndex).getNodeName();
						String specValue = sensotSpecNodeList.item(attrIndex).getTextContent();
						if (specName.equals("type")){
							lastSensor.getImageView().setId(specValue);
						}
						else if (specName.equals("id")){
							lastSensor.sensorFieldValues.put("sensorid", specValue);
						}
						else if (specName.equals("point")){
							//String[] coords = specValue.split(" ");
							//lastSensor.sensorFieldValues.put("xcoord", coords[0]);
							//lastSensor.sensorFieldValues.put("ycoord", coords[0]);
							String xCoord_new = (Double.parseDouble(pointElement.getElementsByTagName("xcoord").item(0).getTextContent().trim()) / gc.scale) + "";
							String yCoord_new = (Double.parseDouble(pointElement.getElementsByTagName("ycoord").item(0).getTextContent().trim()) /gc.scale) + "";
							lastSensor.sensorFieldValues.put("xcoord", xCoord_new);
							lastSensor.sensorFieldValues.put("ycoord", yCoord_new);
						}
						else if (specName.equals("radius"))
						{
							double distanceMeters = Double.parseDouble(specValue);	
							double horCalLineDistance = gc.horizontalCalibrationLine.getDistance();
							double horCalLinePointDiff = gc.horizontalCalibrationLine.getPointDifference();
							double numPoints  = (horCalLinePointDiff * distanceMeters) / horCalLineDistance;

							//customSensorElement.setTextContent((int) Math.round(specValue * coef_temp) + "");
							
							if (specValue != null){
								
							System.out.println("(Double.parseDouble(specValue): " + (Double.parseDouble(specValue)));
							System.out.println("distanceMeters: " + distanceMeters);
							System.out.println("horCalLineDistance: " + horCalLineDistance);
							System.out.println("horCalLinePointDiff: " + horCalLinePointDiff);
							System.out.println("numPoints: " + numPoints);
							System.out.println("----------");
							/*
								lastSensor.sensorFieldValues.put(specName, ((int) Math.round(
									(Double.parseDouble(specValue) / distanceMeters * horCalLineDistance)  
									* coef_temp)) + "");
							*/
								
								System.out.println("Precission: " + precision);
								System.out.println("specValue: " + specValue);
								System.out.println("coef_temp: " + coef_temp);
								System.out.println("----------");
								lastSensor.sensorFieldValues.put(specName, ((int)(Math.round(
										(Double.parseDouble(specValue) )  
										* coef_temp / horCalLineDistance))) + "");
							}
						}
						else lastSensor.sensorFieldValues.put(specName, specValue);
					}
				}
		         Iterator it = lastSensor.sensorFieldValues.entrySet().iterator();
		         while (it.hasNext()) {

		         	Map.Entry pair = (Map.Entry)it.next();
		        	
//		         	if (!pair.getKey().equals("radius"))
		         		lastSensor.sensorFields.get(pair.getKey()).setText(lastSensor.sensorFieldValues.get(pair.getKey()));
//		         	else 
//		         		lastSensor.sensorFields.get(pair.getKey()).setText((Double.parseDouble(lastSensor.sensorFieldValues.get(pair.getKey()) )/ gc.scale + ""));
		         }
			}
		} catch (ParserConfigurationException e) {e.printStackTrace();
		} catch (SAXException e) {e.printStackTrace();
		} catch (IOException e) {e.printStackTrace();}
	}
	
	
	public void importHorizontalCalibrationLine()
	{
		
		if (filePath == null) return;
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document documentCalibrationLine = documentBuilder.parse(filePath);
			
			
			
			NodeList horCalibLineList = documentCalibrationLine.getElementsByTagName("horCalibr");
			if (horCalibLineList.getLength() > 0)
			{
				Node horCalibLine = horCalibLineList.item(0);
				Element horCalibLineElem = (Element) horCalibLine;
				
				Double scale = Double.parseDouble(((Element)horCalibLineElem.getElementsByTagName("scale").item(0)).getTextContent().trim());
				gc.scale = scale.doubleValue();
				
				Element point1Element1 = (Element)horCalibLineElem.getElementsByTagName("point1").item(0);
				Double xCoord1 = Double.parseDouble(point1Element1.getElementsByTagName("xcoord").item(0).getTextContent().trim()) / gc.scale;
				Double yCoord1 = Double.parseDouble(point1Element1.getElementsByTagName("ycoord").item(0).getTextContent().trim()) / gc.scale;
				
				
				Element point1Element2 = (Element)horCalibLineElem.getElementsByTagName("point2").item(0);
				Double xCoord2 = Double.parseDouble(point1Element2.getElementsByTagName("xcoord").item(0).getTextContent().trim()) / gc.scale;
				Double yCoord2 = Double.parseDouble(point1Element2.getElementsByTagName("ycoord").item(0).getTextContent().trim()) / gc.scale;
				
				Double distance = Double.parseDouble(((Element)horCalibLineElem.getElementsByTagName("distance").item(0)).getTextContent().trim());
				
				
				gc.wc_horizontal_p1_xCoord_TextField.setText(xCoord1 + "");
				gc.wc_horizontal_p1_yCoord_TextField.setText(yCoord1 + "");
				
				
				gc.wc_horizontal_p2_xCoord_TextField.setText(xCoord2 + "");
				gc.wc_horizontal_p2_yCoord_TextField.setText(yCoord2 + "");
				
				gc.wc_horizontal_distance_TextField.setText(distance + "");
				
				gc.horizontalCalibrationLine = new InteractableLine(gc.getMainPane(), gc.wc_horizontal_p1_xCoord_TextField,
						gc.wc_horizontal_p1_yCoord_TextField, gc.wc_horizontal_p2_xCoord_TextField,
						gc.wc_horizontal_p2_yCoord_TextField, gc.wc_horizontal_distance_TextField, gc.wc_saveHorizontal_Button,
						gc.wc_hideHorizontal_Button, gc.wc_horizontalCalibrationLine_Label, gc, false);
				//saveButtonAction()
				
				gc.horizontalCalibrationLine.addValue(xCoord1);
				gc.horizontalCalibrationLine.addValue(yCoord1);
	
				gc.getMainPane().getChildren().remove(gc.horizontalCalibrationLine.getRoomShape());
				gc.getMainPane().getChildren().add(gc.horizontalCalibrationLine.getRoomShape());
				gc.getMainPane().getChildren().add(gc.horizontalCalibrationLine.addAnchorCircle());
				
				
				gc.horizontalCalibrationLine.addValue(xCoord2);
				gc.horizontalCalibrationLine.addValue(yCoord2);
	
				gc.getMainPane().getChildren().remove(gc.horizontalCalibrationLine.getRoomShape());
				gc.getMainPane().getChildren().add(gc.horizontalCalibrationLine.getRoomShape());
				gc.getMainPane().getChildren().add(gc.horizontalCalibrationLine.addAnchorCircle());
				
				//gc.horizontalCalibrationLine.saveButtonAction();
				//Point point = new Point(xCoord, yCoord);
					
				//gc.p_placeID_TextField.setText(locationID);
				//gc.p_XCoord_TextField.setText(((int)point.getX()) + "");
				//gc.p_YCoord_TextField.setText(((int)point.getY()) + "");
				//gc.addPlaceButtonAction();
			
				gc.horizontalCalibrationLine.setDistance(distance);
			}
		} catch (ParserConfigurationException e) {e.printStackTrace();} 
		catch (SAXException e) {e.printStackTrace();} 
		catch (IOException e) {e.printStackTrace();}
		
	}
	

	public void importSimStartTime(){
		if (filePath == null) return;
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document documentSimStartTime = documentBuilder.parse(filePath);
			
			NodeList simStartTimeNodeList = documentSimStartTime.getElementsByTagName("sim_start_time");
			Node simStartTimeNode = simStartTimeNodeList.item(0);
			
			Element simStartTimeElement = (Element) simStartTimeNode;
				
			String simStartDate = simStartTimeElement.getElementsByTagName("simStartDate").item(0).getTextContent().trim();
			String simStartTime = simStartTimeElement.getElementsByTagName("simStartTime").item(0).getTextContent().trim();
			
			gc.sim_startTime_TextField.setText(simStartTime);
			
	//		sim_startDate_DatePicker
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("YYYY-MM-DD");
			LocalDate date = null;
			try{date = LocalDate.parse(simStartDate);}
			catch(Exception e){
				
			}
			gc.sim_startDate_DatePicker.setValue(date);
			
			gc.simStartDate = simStartDate;
			gc.simStartTime = simStartTime;
			
		} catch (ParserConfigurationException e) {e.printStackTrace();} 
		catch (SAXException e) {e.printStackTrace();} 
		catch (IOException e) {e.printStackTrace();}
	}
	
	
	public void importMqttConnectionInformation(){
		if (filePath == null) return;
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document documentSimStartTime = documentBuilder.parse(filePath);
			
			NodeList mqttConnectNodeList = documentSimStartTime.getElementsByTagName("mqtt_broker");
			Node mqttConnectNode = mqttConnectNodeList.item(0);
			
			Element mqttConnectElement = (Element) mqttConnectNode;
				
			String ip = mqttConnectElement.getElementsByTagName("ip_address").item(0).getTextContent().trim();
			String protocol = mqttConnectElement.getElementsByTagName("protocol").item(0).getTextContent().trim();
			String port = mqttConnectElement.getElementsByTagName("port").item(0).getTextContent().trim();
			
			gc.protocol_TextField.setText(protocol);
			gc.ip_TextField.setText(ip);
			gc.port_Text_Field.setText(port);
			
			
		} catch (ParserConfigurationException e) {e.printStackTrace();} 
		catch (SAXException e) {e.printStackTrace();} 
		catch (IOException e) {e.printStackTrace();}
	}
	
	
	public void importPlaces()
	{
		if (filePath == null) return;
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document documentSensors = documentBuilder.parse(filePath);
			
			NodeList locationsList = documentSensors.getElementsByTagName("locations");
			Node locations = locationsList.item(0);
			Element locationsElem = (Element) locations;
			NodeList locationList = locationsElem.getElementsByTagName("location");
			
			
			for (int locationIndx = 0; locationIndx < locationList.getLength(); ++locationIndx){
				Node location = locationList.item(locationIndx);
				Element locationElem = (Element) location;
				
				String locationID = locationElem.getElementsByTagName("id").item(0).getTextContent().trim();
				
				//String[] pointArr = locationElem.getElementsByTagName("point").item(0).getTextContent().trim().split(" ");
				//Point point = new Point(Integer.parseInt(pointArr[0]), Integer.parseInt(pointArr[1]));
		
				Element pointElement = (Element)locationElem.getElementsByTagName("point").item(0);
				Double xCoord = Double.parseDouble(pointElement.getElementsByTagName("xcoord").item(0).getTextContent().trim()) / gc.scale;
				Double yCoord = Double.parseDouble(pointElement.getElementsByTagName("ycoord").item(0).getTextContent().trim()) / gc.scale;
				
				//Point point = new Point(xCoord, yCoord);
				
				gc.p_placeID_TextField.setText(locationID);
				gc.p_XCoord_TextField.setText(xCoord + "");
				gc.p_YCoord_TextField.setText(yCoord + "");
				gc.addPlaceButtonAction();
			}
		} catch (ParserConfigurationException e) {e.printStackTrace();} 
		catch (SAXException e) {e.printStackTrace();} 
		catch (IOException e) {e.printStackTrace();}
		
	}
	
	@SuppressWarnings("unchecked")
	public void importActions()
	{

		if (filePath == null) return;
		
		try{
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(filePath);
			
			NodeList actionsList = document.getElementsByTagName("actions");
			Node actionsNode = actionsList.item(0);
			Element actionsElem = (Element) actionsNode;
			
			NodeList actionList = actionsElem.getElementsByTagName("action");
			
			
			for (int actionIndx = 0; actionIndx < actionList.getLength(); ++actionIndx){
				Node actionNode = actionList.item(actionIndx);
				Element actionElem = (Element) actionNode;
				
				String actionID = actionElem.getElementsByTagName("id").item(0).getTextContent().trim();
				String agentID = actionElem.getElementsByTagName("agentID").item(0).getTextContent().trim();
				String actionDate = actionElem.getElementsByTagName("actionDate").item(0).getTextContent().trim();
				String actionTime = actionElem.getElementsByTagName("actionTime").item(0).getTextContent().trim();
				gc.createSubtask = false;
				
				NodeList subactionList = actionElem.getElementsByTagName("subaction");
				Action newAction = null;
				
				newAction = new Action(actionID, gc.agents.getAgentById(agentID), "", actionDate, actionTime, gc);
				gc.createSubtask = true;
				
				
				for(int subActionInx = 0; subActionInx < subactionList.getLength(); ++subActionInx){
					Element subActionElem = (Element) subactionList.item(subActionInx);
					String actionType = subActionElem.getElementsByTagName("actionType").item(0).getTextContent().trim();
				//	String target = subActionElem.getElementsByTagName("target").item(0).getTextContent().trim();
					
					
					if (!gc.createSubtask){
						newAction = new Action(actionID, gc.agents.getAgentById(agentID), actionType, actionDate, actionTime, gc);
						
					//	gc.actions.addAction(newAction);
					}
					else{
						
						newAction = new Action(actionID, gc.agents.getAgentById(agentID), actionType, actionDate, actionTime, gc);}
					//Location loc = (Location) locationC.findLocationByIdentifier(target);
					//if(actionType.equals("Move")){actionToAdd.addSubAction(new Move(loc));}
					//gc.createSubtask = true;
					//newAction = new Action(actionID, gc.agents.getAgentById(agentID), actionType, actionDate, actionTime, gc);
				}


				//String actionType = locationElem.getElementsByTagName("actionType").item(0).getTextContent().trim();
				//String target = locationElem.getElementsByTagName("target").item(0).getTextContent().trim();
							    			     
			    gc.populateAgentsModificationPanel();
			     
			    gc.ca_addAction_Label.setText("Action Added");
			    gc.ca_addAction_Label.setTextFill(Color.web("#008B00"));
			    gc.ca_agentID_ChoiceBox.getSelectionModel().clearSelection();
			    gc.ca_actionInst_ChoiceBox.getSelectionModel().clearSelection();
			   // gc.ca_target_ChoiceBox.getSelectionModel().clearSelection();
			    gc.ca_actionID_TextField.setText("");
			     
			    gc.ca_actionStartData_DatePicker.setValue(null);
			    gc.ca_actionStartTime_TextField.setText("");
			    
			    gc.ma_actionID_ChoiceBox.getSelectionModel().select(newAction.getActionId());
			}
		} catch (ParserConfigurationException e) {e.printStackTrace();} 
		catch (SAXException e) {e.printStackTrace();} 
		catch (IOException e) {e.printStackTrace();}
	}
	
	
	public void importObstacles()
	{
		if (filePath == null) return;	
		try {
			ArrayList<Wall> walls = new ArrayList<Wall>();
			
			
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(filePath);
			
			
			NodeList obstaclesList = document.getElementsByTagName("obstacles");
			Node obstaclesNode = obstaclesList.item(0);
			Element obstaclesElem = (Element) obstaclesNode;
			
			NodeList obstacleList = obstaclesElem.getElementsByTagName("obstacle");
			
			for (int obstacleIndx = 0; obstacleIndx < obstacleList.getLength(); ++obstacleIndx) {
				walls = new ArrayList<Wall>();
				Obstacle currentObstacle = new Obstacle(gc);
				Node room = obstacleList.item(obstacleIndx);
				NodeList wallList = ((Element)room).getElementsByTagName("wall");

				for (int wallIndx = 0; wallIndx < wallList.getLength(); ++wallIndx) {
					Node wall = wallList.item(wallIndx);
					Element wallElem = (Element) wall;
					
					NodeList pointList = wallElem.getElementsByTagName("point");

					/*
					Node point1 = pointList.item(0);
					String[] point1_txt = point1.getTextContent().split(" ");
					Point p1_temp = new Point(Integer.parseInt(point1_txt[0]), Integer.parseInt(point1_txt[1]));

					Node point2 = pointList.item(1);
					String[] point2_txt = point2.getTextContent().split(" ");
					Point p2_temp = new Point(Integer.parseInt(point2_txt[0]), Integer.parseInt(point2_txt[1]));
					*/
					Element pointElement = ((Element)pointList.item(0));
					Double xCoord = Double.parseDouble(pointElement.getElementsByTagName("xcoord").item(0).getTextContent().trim()) / gc.scale;
					Double yCoord = Double.parseDouble(pointElement.getElementsByTagName("ycoord").item(0).getTextContent().trim()) / gc.scale;
					Point p1_temp = new Point(xCoord.doubleValue(), yCoord.doubleValue());
					

					Element pointElement2 = (Element) ((Element)pointList.item(1));
					Double xCoord2 = Double.parseDouble(pointElement2.getElementsByTagName("xcoord").item(0).getTextContent().trim()) / gc.scale;
					Double yCoord2 = Double.parseDouble(pointElement2.getElementsByTagName("ycoord").item(0).getTextContent().trim()) / gc.scale;
					Point p2_temp = new Point(xCoord2, yCoord2);
					
					Wall newWall = new Wall(p1_temp, p2_temp);
					
					walls.add(newWall);

				}
				
				String obstacleID =  ((Element) room).getElementsByTagName("obstacleid").item(0).getTextContent().trim();
				currentObstacle.setObstacleID(obstacleID);


				ArrayList<Point> pointsToAdd = getOrderedPoints(walls);
				for (int i = 0; i < pointsToAdd.size() - 1; ++ i)
				{
					currentObstacle.addValue(pointsToAdd.get(i).x);
					currentObstacle.addValue(pointsToAdd.get(i).y);
				    
					gc.getMainPane().getChildren().remove(currentObstacle.getObstacleShape());
					gc.getMainPane().getChildren().add(currentObstacle.getObstacleShape());
					gc.getMainPane().getChildren().add(currentObstacle.addAnchorCircle());
				}
				
				gc.obstacles.addObstacle(currentObstacle);
				
				gc.obstacles.setCurrentActiveObstacle(gc.obstacles.getObstacles().size() - 1);
				
			}
		} catch (ParserConfigurationException e) {e.printStackTrace();} 
		catch (SAXException e) {e.printStackTrace();} 
		catch (IOException e) {e.printStackTrace();}
	}
	
	
	
	//////////////////////////////////////
	public void importRooms()
	{
		if (filePath == null) return;	
		try {
			ArrayList<Wall> walls = new ArrayList<Wall>();
			ArrayList<DoorImport> doorPoints = new ArrayList<DoorImport>();
			
			
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(filePath);
			
			
			NodeList roomsList = document.getElementsByTagName("rooms");
			Node roomsNode = roomsList.item(0);
			Element roomsElem = (Element) roomsNode;
			
			NodeList roomList = roomsElem.getElementsByTagName("room");
			
			for (int roomIndx = 0; roomIndx < roomList.getLength(); ++roomIndx) {
				walls = new ArrayList<Wall>();
				doorPoints = new ArrayList<DoorImport>();				
				Room currentRoom = new Room(gc);
				Node room = roomList.item(roomIndx);
				NodeList wallList = ((Element)room).getElementsByTagName("wall");

				for (int wallIndx = 0; wallIndx < wallList.getLength(); ++wallIndx) {
					Node wall = wallList.item(wallIndx);
					Element wallElem = (Element) wall;
					
					NodeList pointList = wallElem.getElementsByTagName("point");

					/*
					Node point1 = pointList.item(0);
					String[] point1_txt = point1.getTextContent().split(" ");
					Point p1_temp = new Point(Integer.parseInt(point1_txt[0]), Integer.parseInt(point1_txt[1]));

					Node point2 = pointList.item(1);
					String[] point2_txt = point2.getTextContent().split(" ");
					Point p2_temp = new Point(Integer.parseInt(point2_txt[0]), Integer.parseInt(point2_txt[1]));
					*/
					
					Element pointElement = (Element)pointList.item(0);
					Double xCoord = Double.parseDouble(pointElement.getElementsByTagName("xcoord").item(0).getTextContent().trim()) / gc.scale;
					Double yCoord = Double.parseDouble(pointElement.getElementsByTagName("ycoord").item(0).getTextContent().trim()) / gc.scale;
					
					Point p1_temp = new Point(xCoord, yCoord);
					

					Element pointElement2 = (Element)pointList.item(1);
					Double xCoord2 = Double.parseDouble(pointElement2.getElementsByTagName("xcoord").item(0).getTextContent().trim()) / gc.scale;
					Double yCoord2 = Double.parseDouble(pointElement2.getElementsByTagName("ycoord").item(0).getTextContent().trim()) / gc.scale;
					
					Point p2_temp = new Point(xCoord2, yCoord2);
					

					Wall newWall = new Wall(p1_temp, p2_temp);
					
					walls.add(newWall);

					Node door = wallElem.getElementsByTagName("door").item(0);
					if (door != null) {
						//int doorXCoord = (int) Math.abs((p1_temp.getX() + p2_temp.getX())/2);
						//int doorYCoord = (int) Math.abs((p1_temp.getY() + p2_temp.getY())/2);
						Element doorElement = (Element) door;
						Double xCoordDoor = Double.parseDouble(doorElement.getElementsByTagName("xcoord").item(0).getTextContent().trim()) / gc.scale;
						Double yCoordDoor = Double.parseDouble(doorElement.getElementsByTagName("ycoord").item(0).getTextContent().trim()) / gc.scale;
						String doorID = doorElement.getElementsByTagName("doorid").item(0).getTextContent().trim();
						String doorSize = (Double.parseDouble(doorElement.getElementsByTagName("doorsize").item(0).getTextContent().trim()) / gc.scale) + "";
						DoorImport newDoor = new DoorImport(xCoordDoor, yCoordDoor, doorID, doorSize);
						//	Point doorPoint = new Point(xCoordDoor, yCoordDoor);	
						if (!doorPoints.contains(newDoor)) doorPoints.add(newDoor);
						
					}
				}
				
				String roomId =  ((Element) room).getElementsByTagName("roomid").item(0).getTextContent().trim();
				currentRoom.setRoomID(roomId);


				ArrayList<Point> pointsToAdd = getOrderedPoints(walls);
				for (int i = 0; i < pointsToAdd.size() - 1; ++ i)
				{
					try{
					currentRoom.addValue(pointsToAdd.get(i).x);
					currentRoom.addValue(pointsToAdd.get(i).y);
				    
					gc.getMainPane().getChildren().remove(currentRoom.getRoomShape());
					gc.getMainPane().getChildren().add(currentRoom.getRoomShape());
					gc.getMainPane().getChildren().add(currentRoom.addAnchorCircle());
					}catch(Exception e){}
				}
				
				gc.rooms.addRoom(currentRoom);
				
				gc.rooms.setCurrentActiveRoom(gc.rooms.getRooms().size() - 1);
				
				for (int i = 0; i < doorPoints.size() ; ++i)
				{
//					gc.current_x = ((int)doorPoints.get(i).getX());
//					gc.current_y = ((int)doorPoints.get(i).getY());
					
					gc.current_x = ((int)doorPoints.get(i).getXCoord());
					gc.current_y = ((int)doorPoints.get(i).getYCoord());

					try {
						File fileDoorImage = new File("@../../image/door/door.png");
						URL url = fileDoorImage.toURI().toURL();
						ImageView doorImageView = new ImageView();
						
						doorImageView.setImage(new Image(url.toExternalForm()));
						gc.configDoor(doorImageView, true);
						Door currentActiveDoor = gc.doors.getDoors().get(gc.doors.getDoors().size() - 1);//gc.doors.getCurrentActiveDoor();
						currentActiveDoor.setDoorSize(doorPoints.get(i).getDoorSize());
					
					} catch (MalformedURLException e) {e.printStackTrace();}
				}
			}
		} catch (ParserConfigurationException e) {e.printStackTrace();} 
		catch (SAXException e) {e.printStackTrace();} 
		catch (IOException e) {e.printStackTrace();}
	}
	
	
	public ArrayList<Point> getOrderedPoints(ArrayList<Wall> walls){
		ArrayList<Point> points = new ArrayList<Point>();
		
		Point firstPoint = walls.get(0).getStartPoint();
		points.add(firstPoint);
		Point secondPoint = walls.get(0).getEndPoint();
		points.add(secondPoint);
		
		walls.remove(walls.get(0));
		while (walls.size() > 0){
			Wall wall_temp = null;
			boolean wallFound = false;
			for (int i = 0; ((i < walls.size()) && (!wallFound)); ++i){
				wall_temp = walls.get(i);
				if (wall_temp.isEdgePoint(secondPoint))wallFound = true;		
			}
			
			Point nextPoint = wall_temp.getAnotherEdgePoint(secondPoint);
			points.add(nextPoint);
			secondPoint =nextPoint;
			walls.remove(wall_temp);
		}
		return points;
	}
	
	
	public void importAgents()
	{
		if (filePath == null) return;
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(filePath);
			
			NodeList agentsList = document.getElementsByTagName("agents");
			Node agentsNode = agentsList.item(0);
			Element agentsElem = (Element) agentsNode;
			
			NodeList agentList = agentsElem.getElementsByTagName("agent");
			
			for (int agentIndx = 0; agentIndx < agentList.getLength(); ++agentIndx)
			{
				Node agent = agentList.item(agentIndx);
				Element agentElem = (Element) agent;
				String agentId = agentElem.getElementsByTagName("agentid").item(0).getTextContent().trim();
				String agentName = agentElem.getElementsByTagName("agentname").item(0).getTextContent().trim();
				String agentRole = agentElem.getElementsByTagName("agentrole").item(0).getTextContent().trim();
				
				//String[] pointArr = agentElem.getElementsByTagName("point").item(0).getTextContent().trim().split(" ");
				Element pointElement = (Element)agentElem.getElementsByTagName("point").item(0);
				Double xCoord = Double.parseDouble(pointElement.getElementsByTagName("xcoord").item(0).getTextContent().trim()) / gc.scale;
				Double yCoord = Double.parseDouble(pointElement.getElementsByTagName("ycoord").item(0).getTextContent().trim()) / gc.scale;
				
				Point point = new Point(xCoord, yCoord);
				
				//Point point = new Point(Integer.parseInt(pointArr[0]), Integer.parseInt(pointArr[1]));
				
				gc.a_agentID_TextField.setText(agentId);
				gc.a_agentName_TextField.setText(agentName);
				gc.a_agentRole_TextField.setText(agentRole);
				gc.a_XCoord_TextField.setText((point.x) + "");
				gc.a_YCoord_TextField.setText((point.y) + "");
				
				gc.addAgentButtonAction();
				
			}

		} 
		catch (ParserConfigurationException e) {e.printStackTrace();} 
		catch (SAXException e) {e.printStackTrace();} 
		catch (IOException e) {e.printStackTrace();}
		
	}

}
