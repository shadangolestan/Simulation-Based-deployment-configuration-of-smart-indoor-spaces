package importClasses;

public class DoorImport {
	private double xCoord, yCoord;
	private String doorId;
	private String doorSize;
	
	public DoorImport(double xCoord, double yCoord, String doorId, String doorSize){
		this.xCoord = xCoord;
		this.yCoord = yCoord;
		this.doorId = doorId;
		this.doorSize = doorSize;
	}
	
	public void setXCoord(int xCoord){this.xCoord = xCoord;}
	public void setYCoord(int yCoord){this.yCoord = yCoord;}
	public void setDoorId(String doorId){this.doorId = doorId;}
	public void setDoorSize(String doorSize){this.doorSize = doorSize;}
	
	
	public double getXCoord(){return xCoord;}
	public double getYCoord(){return yCoord;}
	public String getDoorId(){return doorId;}
	public String getDoorSize(){return doorSize;}
}
