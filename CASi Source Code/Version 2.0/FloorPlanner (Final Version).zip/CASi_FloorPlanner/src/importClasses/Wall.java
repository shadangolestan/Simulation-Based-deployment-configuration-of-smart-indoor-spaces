package importClasses;

import geometry.Point;

public class Wall {
	Point startPoint;
	Point endPoint;
	
	public Wall (Point p1_temp, Point p2_temp)
	{
		this.startPoint = p1_temp;
		
		this.endPoint = p2_temp;
	}
	
	
	public Point getStartPoint(){return this.startPoint;}
	public Point getEndPoint(){return this.endPoint;}
	
	public boolean isEdgePoint (Point point)
	{
		try{
	
			if (((point.x == startPoint.x) && (point.y == startPoint.y)) ||
					((point.x == endPoint.x) && (point.y == endPoint.y)))
				return true;
			return false;
		} catch (Exception e){
			
		}
		return false;
	}
	
	public Point getAnotherEdgePoint(Point point)
	{
		if (this.isEdgePoint(point)) 
		{
			if ((point.x == startPoint.x) && (point.y == startPoint.y)) return endPoint;
			else return startPoint;
		}
			
		return null;
		
	}

	public String toString()
	{
		return ("\tStart: " + startPoint + "\tEnd: " + endPoint + "\n");
	}
}
