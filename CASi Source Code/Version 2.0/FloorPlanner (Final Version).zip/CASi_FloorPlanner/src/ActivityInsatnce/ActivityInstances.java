package ActivityInsatnce;

import java.util.ArrayList;

public class ActivityInstances {

	private ArrayList<ActivityInstance> activityInstancies;
	private ActivityInstance currentActiveActivityInstance;

	public ActivityInstances() {
		this.activityInstancies = new ArrayList<ActivityInstance>();
		this.currentActiveActivityInstance = null;
	}

	public void addActivityInstance(ActivityInstance activity) {activityInstancies.add(activity);}
	public void removeActivityInstance(ActivityInstance activity) {activityInstancies.remove(activity);}
	public void removeActivityInstanceByIndex(int index) {activityInstancies.remove(index);}
	public ArrayList<ActivityInstance> getactivityInstancies() {return this.activityInstancies;}
	public void setcurrentActiveActivityInstance(ActivityInstance currentActiveActivityInstance) {this.currentActiveActivityInstance = currentActiveActivityInstance;}
	public ActivityInstance getcurrentActiveActivityInstance() {return currentActiveActivityInstance;}

	public boolean isIdInList(String id) {
		for (int i = 0; i < activityInstancies.size(); ++i)
		{
			if (activityInstancies.get(i).getActivityInstanceId().equals(id)) 
				return true;
		}
		return false;
	}

	public ActivityInstance getActivityInstanceByID(String id) {
		for (int i = 0; i < activityInstancies.size(); ++i) {
			if (activityInstancies.get(i).getActivityInstanceId().equals(id)) {
				return activityInstancies.get(i);
			}
		}
		return null;
	}
	

	
}
