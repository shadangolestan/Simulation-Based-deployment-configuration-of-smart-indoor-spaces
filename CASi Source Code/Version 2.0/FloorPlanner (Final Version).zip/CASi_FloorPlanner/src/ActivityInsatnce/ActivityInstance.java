package ActivityInsatnce;

import java.util.ArrayList;

import ActivityDefinition.ActivityDefinition;
import application.GroupController;

public class ActivityInstance {
	String id;
	ArrayList<String> activityDefinitions;
	ArrayList<String> targets;
	ArrayList<String> actionParameter;
	
	ActivityInstance itself;
	
	GroupController gc;
	
	public ActivityInstance//(GroupController gc, ArrayList<ActivityDefinition> activityDefinitions, 
		(GroupController gc, ArrayList<String> activityDefinitions, 
	ArrayList<String> targets, 
			ArrayList<String> actionParameter, 
			String id){
		this.itself = this;
		this.id = id;
		this.activityDefinitions = activityDefinitions;
		this.targets = targets;
		this.actionParameter = actionParameter;

	}
	
	public ArrayList<String> getActivityDefinitions(){
		return this.activityDefinitions;
	}
	
	
	public int getActivityDefinitionsIndexOf(String str){
		if (str == null) return 0;
		
		for(int i = 0; i < activityDefinitions.size(); i++)
		{
			if ((activityDefinitions.get(i) != null)  && (activityDefinitions.get(i).equals(str)))return i;
				
		}
		return -1;
	}
	
	public ArrayList<String> getTargets(){return this.targets;}
	public String getTargetByIndex(int i){return this.targets.get(i);}
	
	
	public ArrayList<String> getActionParameter(){return this.actionParameter;}
	public String getTimerByIndex(int i){return this.actionParameter.get(i);}
	
	
	public String getActivityDefinitionByIndex(int i){return this.activityDefinitions.get(i);} 

	public String getActivityInstanceId(){return this.id;}
	
}
