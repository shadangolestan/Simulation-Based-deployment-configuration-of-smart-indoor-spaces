package places;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import application.GroupController;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;

public class Place {

	private final String PLACE_IMAGE_PATH_HOVER_OVER = "@../../image/place/place_icon_ho.png";
	private final String PLACE_IMAGE_PATH = "@../../image/place/place_icon.png";
	
	private GroupController gc;
	private Place itself;
	private ImageView imageView;
	private String placeID;  
	private double XCoord;
	private double YCoord;
	private boolean isValidPlace;
	
	public Place(GroupController gc){
		this.gc = gc;
		this.itself = this;
		this.isValidPlace = false;

		isValidPlace = validateAndRecordPlace(true);
		
		if (isValidPlace){
			try {
				File file = new File(PLACE_IMAGE_PATH);
				URL url = file.toURI().toURL();
				this.imageView = new ImageView(new Image(url.toExternalForm()));
				this.gc.getMainPane().getChildren().add(imageView);
				
				imageView.setLayoutX(XCoord);
				imageView.setLayoutY(YCoord);
				imageView.setFitHeight(30);
				imageView.setFitWidth(30);
			}
			catch (Exception e){gc.p_addPlace_Label.setText("Image Not found"); isValidPlace = false;}
			setListeners();
			
			gc.places.setCurrentActivePlace(itself);
		}
	} 
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void setListeners(){
		itself.imageView = imageView;
		
		this.imageView.setOnDragDetected(new EventHandler() {
        	@Override
			public void handle(Event event) {
        		itself.imageView.setId("place_iconOld");
        		itself.gc.places.setCurrentActivePlace(itself);
        		itself.gc.sensorDrag(event);
			}
        });
		
		imageView.setOnMouseClicked(new EventHandler<MouseEvent>(){
 			@Override
 			public void handle(MouseEvent e) {
 				if (e.getButton() == MouseButton.SECONDARY){
 					gc.getMainPane().getChildren().remove(imageView);
 					gc.places.removePlace(itself);
 					
 					gc.p_placeIDModified_TextField.setText("");
 					gc.p_XCoordModified_TextField.setText("");
 					gc.p_YCoordModified_TextField.setText("");
 				}
 				else if (e.getButton() == MouseButton.PRIMARY){
 					gc.places.setCurrentActivePlace(itself);
 					itself.gc.p_placeIDModified_TextField.setText(itself.placeID);
 					itself.gc.p_XCoordModified_TextField.setText(itself.XCoord + "");
 					itself.gc.p_YCoordModified_TextField.setText(itself.YCoord + "");
 				}
 		        e.consume();
 			}
         });
		
		imageView.setOnMouseEntered(new EventHandler<MouseEvent>(){
 			@Override
 			public void handle(MouseEvent e) {
 				
 				try {
 					File file = new File(PLACE_IMAGE_PATH_HOVER_OVER);
 	 				URL url = file.toURI().toURL();
 					itself.getImageView().setImage(new Image(url.toExternalForm()));
 				} catch (MalformedURLException e1) {e1.printStackTrace(); isValidPlace = false;}
 			}
		});
 			
		imageView.setOnMouseExited(new EventHandler<MouseEvent>(){
 			@Override
 			public void handle(MouseEvent e) {
 				File file = new File(PLACE_IMAGE_PATH);
 				URL url;
 				try {
 					url = file.toURI().toURL();
 					itself.getImageView().setImage(new Image(url.toExternalForm()));
 				} catch (MalformedURLException e1) {e1.printStackTrace();isValidPlace = false;}
 			}
		});
	}
	
	protected boolean validateAndRecordPlace(boolean isNew){
		
		String placeID = "";
		String placeX_Coord_str = "";
		String placeY_Coord_str = "";
		Label messageLabel = null;
		
		if (isNew){
			placeID = gc.p_placeID_TextField.getText().trim();
			placeX_Coord_str = gc.p_XCoord_TextField.getText().trim();
			placeY_Coord_str = gc.p_YCoord_TextField.getText().trim();
			messageLabel = gc.p_addPlace_Label;
		}
		else {
			placeID = gc.p_placeIDModified_TextField.getText();
			placeX_Coord_str = gc.p_XCoordModified_TextField.getText();
			placeY_Coord_str = gc.p_YCoordModified_TextField.getText();
			messageLabel = gc.p_modifyPlace_Label;
		}
		
		if (placeID.equals("") || placeID == null) {
			gc.setMessage(false, "Place ID not enterred", messageLabel);
			return false;
		}

		// this case is only if a new places is added
		if (isNew && gc.places.isIdInList(placeID)) {
			gc.setMessage(false, "Place ID already exits", messageLabel);
			return false;
		}

		
		if (placeX_Coord_str.equals("") || placeX_Coord_str == null) {
			gc.setMessage(false, "X coordinate not enterred", messageLabel);
			return false;
		}

		double placeX_Coord = -1;
		try {
			placeX_Coord = Double.parseDouble(placeX_Coord_str);
		} catch (Exception e) {
			gc.setMessage(false, "Coordinates must be numbers", messageLabel);
			return false;
		}


		if (placeY_Coord_str.equals("") || placeY_Coord_str == null) {
			gc.setMessage(false, "Y coordinate not enterred", messageLabel);
			return false;
		}
		double placeY_Coord = -1;
		try {
			placeY_Coord = Double.parseDouble(placeY_Coord_str);
		} catch (Exception e) {
			gc.setMessage(false, "Coordinates must be numbers", messageLabel);
			return false;
		}
		
		this.placeID = placeID;  
		this.XCoord = placeX_Coord;
		this.YCoord = placeY_Coord;
		
		if (!isNew) updateImageViewCoord();
		
		String successMessage = "";
		
		if (isNew) successMessage = "Place Added!";
		else successMessage = "Place Modified!";
		
		gc.setMessage(true, successMessage, messageLabel);
		
		return true;
	}

	
	public void setImageView(ImageView imageView){this.imageView = imageView;}
	public ImageView getImageView(){return this.imageView;}
	public String getPlaceId(){return this.placeID;}
	public void hide(){gc.getMainPane().getChildren().remove(this.imageView);}
	public void show(){gc.getMainPane().getChildren().add(this.imageView);}
	public Place getItself(){return this.itself;}
	public boolean isValidPlace(){return this.isValidPlace;}

	
	private void updateImageViewCoord(){
		imageView.setLayoutX(XCoord);
		imageView.setLayoutY(YCoord);
		imageView.setFitHeight(30);
		imageView.setFitWidth(30);
	}
	
	public void updatePlaceCoordinates(){
		itself.XCoord = itself.imageView.getLayoutX();
		itself.YCoord = itself.imageView.getLayoutY();
	}
}
