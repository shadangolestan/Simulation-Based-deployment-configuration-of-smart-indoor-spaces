package places;

import java.util.ArrayList;

public class Places {
	private ArrayList<Place> places;
	private Place activePlace;

	public Places() {this.places = new ArrayList<Place>(); activePlace = null;}

	public void savePlaceConfiguration(){
		Place place_temp = getCurrentActivePlace();
		place_temp.validateAndRecordPlace(false);
	}


	public void addPlace(Place place) {places.add(place);}
	public void removePlace(Place place) {places.remove(place);}
	public void removePlaceByIndex(int index) {places.remove(index);}
	public ArrayList<Place> getPlaces() {return places;}
	public void setCurrentActivePlace(Place activePlace) {this.activePlace = activePlace;}
	public Place getCurrentActivePlace() {return activePlace;}
	public void hide() {for (int i = 0; i < places.size(); ++i) places.get(i).hide();}
	public void show() {for (int i = 0; i < places.size(); ++i)places.get(i).show();}
	
	public boolean isIdInList(String id) {
		for (int i = 0; i < places.size(); ++i)
			if (places.get(i).getPlaceId().equals(id))
				return true;
		return false;
	}
	
}
