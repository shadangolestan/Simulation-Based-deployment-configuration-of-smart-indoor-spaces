package sensors;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import application.Coordinates;
import application.GroupController;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;

public class Sensor {
	private ImageView imageView;
	public HashMap<String, TextField> sensorFields;
	public HashMap<String, String> sensorFieldValues;
	private Coordinates coordinates;
	private FlowPane flowPane;
	private FlowPane sensorParametersFlowPane;
	private Button saveButton;
	private Sensor itself;
	private Label sensorLabel;
	private String sensorDescription;
	private GroupController gc;
	

	@SuppressWarnings("rawtypes")
	public Sensor(FlowPane flowPane, ImageView imageView, FlowPane sensorParametersFlowPane, 
			Button saveButton, HashMap<String, TextField> sensorFields, HashMap<String, String> sensorFieldValues,
			Label sensorLabel, String sensorDescription, GroupController gc){
		this.gc = gc;
		
		this.itself = this;
		
		this.sensorDescription = sensorDescription;
		this.sensorLabel = sensorLabel;
		
		this.imageView = new ImageView();
		
		this.coordinates = null;
		this.flowPane =  flowPane;
		this.imageView = imageView;
		this.sensorParametersFlowPane = sensorParametersFlowPane;
		

		this.sensorFields = sensorFields;
		this.sensorFieldValues = sensorFieldValues;
		this.sensorFieldValues = new HashMap<String, String>();
		this.sensorFieldValues.putAll(sensorFieldValues);
		this.saveButton = saveButton;
		//java.util.Date date= new java.util.Date();
		this.sensorFieldValues.put("sensorid", imageView.getId() + "-" + imageView.getLayoutX() + "-" + imageView.getLayoutY());
	
		Iterator it = itself.sensorFieldValues.entrySet().iterator();
		
		
		while (it.hasNext()) {
		        Map.Entry pair = (Map.Entry)it.next();
		        this.sensorFieldValues.put(pair.getKey().toString(), getFieldValue(pair.getKey().toString()));
		}
		
		
		
		setImageViewListeners();
		populateSensoerTextFields();
		
		itself.gc.sensors.setCurrentActiveSensor(itself);
	} 
	
	
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void setImageViewListeners()
	{
		//itself.imageView = imageView;
		
		this.saveButton.setOnAction(new EventHandler<ActionEvent>(){
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				boolean validationPassed = true;
				HashMap<String, String> valuesTemp = new HashMap<String, String>();
				
				Iterator it = itself.sensorFields.entrySet().iterator();
	            while (it.hasNext() && (validationPassed)) {
					Map.Entry pair = (Map.Entry)it.next();
	            	validationPassed = validateParameter(valuesTemp, pair.getKey().toString(), 
	            			((TextField)pair.getValue()).getText());            
	            }
	            
	            if (validationPassed){
	            	itself.sensorFieldValues.clear();
	            	itself.sensorFieldValues.putAll(valuesTemp);	       	    
	            	gc.setMessage(true, "Parameters Saved", sensorLabel);
	            }
	            
	            	imageView.setLayoutX(Double.parseDouble(itself.sensorFieldValues.get("xcoord")));
	            	imageView.setLayoutY(Double.parseDouble(itself.sensorFieldValues.get("ycoord")));
			}
		});

		
		this.imageView.setOnDragDetected(new EventHandler() {
        	@Override
			public void handle(Event event) {
        		String currentImageId = itself.getImageView().getId();
        		
        		if (((currentImageId.length() > 2) && (!(currentImageId.substring(currentImageId.length() - 3, currentImageId.length())).equals("Old")))
        				|| (currentImageId.length() <= 2))
        		{
        			itself.imageView.setId(itself.getImageView().getId() + "Old");
        		}
        		//itself.imageView.setId("sensor_iconOld");
        		itself.gc.sensors.setCurrentActiveSensor(itself);
        		itself.gc.sensorDrag(event);
			}
        });
		
		/*
		imageView.setOnDragDetected(new EventHandler() {
			@Override
			public void handle(Event event) {
				// TODO Auto-generated method stub
				itself.imageView.setId(itself.getImageView().getId() + "Old");
	        	itself.gc.sensors.setCurrentActiveSensor(itself);
	        	itself.gc.sensorDrag(event);
			}});
		 */
		imageView.setOnMouseClicked(new EventHandler<MouseEvent>(){
 			@Override
 			public void handle(MouseEvent e) {
 				if (e.getButton() == MouseButton.SECONDARY){
 					itself.gc.getMainPane().getChildren().remove(imageView);
 					gc.sensorsImageViews.remove(imageView);
 					
 					if(sensorParametersFlowPane.getChildren().size() > 0)
 						sensorParametersFlowPane.getChildren().remove(0);
 					
 					gc.sensorDescription_TextArea.setText("");
 					gc.sensors.removeSensor(itself);
 				}
 				else if (e.getButton() == MouseButton.PRIMARY){
	        		if (sensorParametersFlowPane.getChildren().size() > 0)sensorParametersFlowPane.getChildren().remove(0);
 	        		
 	               sensorParametersFlowPane.getChildren();
 	               
 	              if (!sensorParametersFlowPane.getChildren().contains(flowPane))
 	        		sensorParametersFlowPane.getChildren().add(flowPane);
 	        		
 	                gc.sensorDescription_TextArea.setText(itself.getSensorDescription());
 				}
 		        e.consume();
 			}
         });
	}
	
	@SuppressWarnings("rawtypes")
	public void populateSensoerTextFields(){
         Iterator it = itself.sensorFieldValues.entrySet().iterator();
         while (it.hasNext()) {
         	Map.Entry pair = (Map.Entry)it.next();
         	sensorFields.get(pair.getKey()).setText(itself.sensorFieldValues.get(pair.getKey()));

         	
         }
         /*
          if ((gc.horizontalCalibrationLine != null) && (gc.horizontalCalibrationLine.get_Xcoord().size() == 2)){
                	System.out.println("Meters");
                 	Double distanceCalLine = gc.horizontalCalibrationLine.getDistance();
                 	System.out.println("-->1");
                 	double pointDiff = 0;
                 	try{
                 		pointDiff = Double.parseDouble(itself.sensorFieldValues.get(pair.getKey()));
                    	System.out.println("-->2");
                     	double coefficient =  (distanceCalLine / pointDiff);// * 1000;
                     	System.out.println("-->3");
                     	double meterDistance = pointDiff * coefficient;
                     	System.out.println("-->4");
                     	System.out.println("Point Diff: " + pointDiff + "\t\t");
                     	sensorFields.get(pair.getKey()).setText(meterDistance + "");
                     	//sensorFields.get(pair.getKey()).setText(itself.sensorFieldValues.get(pair.getKey()));
                 	}
                 	catch (Exception e){
                 		System.out.println("No value to display");
                 	}
             
                 	System.out.println("-->5");
                 }
                 else{
          */
         
         //set X and y coordinates
         this.sensorFieldValues.put("xcoord", imageView.getLayoutX() + "");
         this.sensorFieldValues.put("ycoord", imageView.getLayoutY() + "");
         
         this.sensorFields.get("xcoord").setText(imageView.getLayoutX() + "");
         this.sensorFields.get("ycoord").setText(imageView.getLayoutY() + "");

	}
	
	public void setImageView(ImageView imageView){this.imageView = imageView;}
	public ImageView getImageView(){return this.imageView;}
	
	public Sensor(String path) throws MalformedURLException
	{
		File sensorImageFile = new File(path);
    	URL url = sensorImageFile.toURI().toURL();
		Image sensorImage = new Image(url.toExternalForm());
		this.imageView.setImage(sensorImage);
		this.sensorFields = new  HashMap<String, TextField>();	
	}
	
	public void setSensorFields (HashMap<String, TextField> sensorFields){this.sensorFields = sensorFields;}
	public HashMap<String, TextField> getSensorFields(){return this.sensorFields;}
	
	public void setSensorCoordinates(Coordinates coordinates){this.coordinates = coordinates;}
	public Coordinates getSensorCoordinates(){return this.coordinates;}
	public String getSensorId(){return (this.sensorFieldValues.get("sensorid"));}
	public FlowPane getFlowPane(){return this.flowPane;}
	public String getSensorDescription(){return sensorDescription;}
	public void setSensorDescription(String sensorDescription){this.sensorDescription = sensorDescription;}
	
	
	public String getFieldValue (String fieldName){
		if (fieldName.equals("sensorid")) return (this.sensorFieldValues.get("sensorid"));
		else if (fieldName.equals("xcoord")) return ("" +this.imageView.getLayoutX());
		else if (fieldName.equals("ycoord")) return ("" +this.imageView.getLayoutY());
		else return "";
	}
	
	public boolean validateParameter(HashMap<String, String> tempValues, String fieldName, String fieldValue){
		boolean validationPassed = true;
		if (fieldName.equals("sensorid")){
			if((gc.sensors.isIdInList(fieldValue)) && (!fieldValue.equals(this.sensorFieldValues.get("sensorid")))) {
				gc.setMessage(false, "ID must be unique", sensorLabel);
				validationPassed = false;
			}
		}
		else if (fieldName.equals("xcoord")){
			try{
				double xCoord = Double.parseDouble(fieldValue.trim());
				if (xCoord < 0) {
					validationPassed = false;
					gc.setMessage(false, "xCoord must be > 0", sensorLabel);
				}
			}catch(Exception e){validationPassed = false; gc.setMessage(false, "xCoord must be a number", sensorLabel);}
		}
		else if (fieldName.equals("ycoord")){
			try{
				double yCoord = Double.parseDouble(fieldValue);
				if (yCoord < 0) {
					validationPassed = false;
					gc.setMessage(false, "xCoord must be a number", sensorLabel);
				}
			}catch(Exception e){
				validationPassed = false;
				gc.setMessage(false, "xCoord must be a number", sensorLabel);
			}
		}
		
		if (validationPassed) tempValues.put(fieldName, fieldValue);
		return validationPassed;
	}
	
	public String getRadius()
	{return this.sensorFieldValues.get("radius");}


	
	public Label getLabel(){return this.sensorLabel;}
}
