package sensors;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Sensors {
	private ArrayList<Sensor> sensors;
	private Sensor currentActiveSensor;
	
	public Sensors(){
		this.sensors = new ArrayList<Sensor>();
		this.currentActiveSensor = null;
	}
	
	public void addSensor(Sensor sensor){sensors.add(sensor);}
	public void removeSensor(Sensor sensor){sensors.remove(sensor);}
	public void removeSensorByIndex(int index){sensors.remove(index);}
	public ArrayList<Sensor> getSensors(){return sensors;}
	public void setCurrentActiveSensor(Sensor currentActiveSensor){this.currentActiveSensor = currentActiveSensor;}
	public Sensor getCurrentActiveSensor(){return currentActiveSensor;}
	
	public boolean isIdInList(String id){
		for (int i = 0; i < sensors.size(); ++i)
			if (sensors.get(i).getSensorId().equals(id)) return true;
		return false;
	}
	
	
	public void setSelectedSensor(Sensor sensor){
		
		for(int i = 0; i < sensors.size(); ++i) {
			if ((sensors.get(i).getSensorId().equals(sensor.getSensorId()))) {
				currentActiveSensor = sensors.get(i);
				ImageView curretnImageView = sensors.get(i).getImageView();
				String sensorType = curretnImageView.getId();
				

				try {
					File file = new File("@../../Sensors/" + sensorType + "/Image/image_selected.png");
					URL url = file.toURI().toURL();
					curretnImageView.setImage(new Image(url.toExternalForm()));
					
				} catch (MalformedURLException e) {e.printStackTrace();}
				
			}
			else {
				currentActiveSensor = sensors.get(i);
				ImageView curretnImageView = sensors.get(i).getImageView();
				String sensorType = curretnImageView.getId();
				
				
				try {
					File file = new File("@../../Sensors/" + sensorType + "/Image/image.png");
					URL url = file.toURI().toURL();
					curretnImageView.setImage(new Image(url.toExternalForm()));
					
				} catch (MalformedURLException e) {e.printStackTrace();}	
			}
		}
		
	}
	
	public boolean isSelected (Sensor sensor){
		if (currentActiveSensor.getSensorId().equals(sensor.getSensorId())) return true;
		return false;
	}
	
	public boolean isSelectedByImageView (ImageView iv){
		if ((currentActiveSensor != null) &&(currentActiveSensor.getImageView().equals(iv))) return true;
		return false;
	}
}
