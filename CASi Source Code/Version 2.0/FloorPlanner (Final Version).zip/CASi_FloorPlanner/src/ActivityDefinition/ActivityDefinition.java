package ActivityDefinition;

import java.util.ArrayList;
import application.GroupController;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

public class ActivityDefinition {

	private GroupController gc;
	private boolean isAtomicActivity;
	private String activityName;
	private String activityType;
	private boolean isValidActivity;
	private ActivityDefinition itself;
	private ArrayList<String> subActivities;
	
	public ActivityDefinition(GroupController gc){
		this.gc = gc;
		itself = this;
		
		isValidActivity = this.validateAndRecord();
		
	}
	
	public ActivityDefinition(GroupController gc, boolean isAtomicActivity, String activityName, ArrayList<String> subActivities,
			String activityType){
		this.gc = gc;
		this.isAtomicActivity = isAtomicActivity;
		this.activityName = activityName;
		
		this.isValidActivity = true;
		this.itself = this;
		this.subActivities = subActivities;
		this.activityType = activityType;
	}
	private boolean validateAndRecord(){

		RadioButton atomicAction_RadioButton = gc.atomicAction_RadioButton;
		RadioButton complexAction_RadioButton = gc.complexAction_RadioButton;
		TextField activityName_actDef_TextField = gc.activityName_actDef_TextField;
		ChoiceBox activityType_actDef_ChoiceBox = gc.activityType_actDef_ChoiceBox;
		Label outputMessage_actDef_Label = gc.outputMessage_actDef_Label;
		
		
		this.isAtomicActivity = true;
		
		if (complexAction_RadioButton.isSelected()) this.isAtomicActivity = false;
		
		String activityName_actDef_TextField_temp = activityName_actDef_TextField.getText();
		String activityType_actDef_ChoiceBox_temp = "";
		String activityTarget_actDef_ChoiceBox_temp ="";
		


		if ((activityName_actDef_TextField_temp.equals("") || activityName_actDef_TextField_temp == null))
		{
				gc.setMessage(false, "Activity Name is missing", outputMessage_actDef_Label);
				return false;
		}
		
		if ((gc.activities.isIdInList(activityName_actDef_TextField_temp))) {
				gc.setMessage(false, "Activity is already in the list.", outputMessage_actDef_Label);
				return false;
			}

		try {
			activityType_actDef_ChoiceBox_temp = activityType_actDef_ChoiceBox.getSelectionModel().getSelectedItem().toString();
		} catch (Exception e) {
			gc.setMessage(false, "Activity Type is missing", outputMessage_actDef_Label);
			return false;
		}
		
		
		gc.setMessage(true, "Activity Created", outputMessage_actDef_Label);
		
		activityName = activityName_actDef_TextField_temp;
		activityType = activityType_actDef_ChoiceBox.getSelectionModel().getSelectedItem().toString();
		
		gc.activityName_actDef_TextField.setText("");
		gc.activityType_actDef_ChoiceBox.getSelectionModel().clearSelection();
		
		
		subActivities = new ArrayList<String>();
		
		return true;
	}
	
	
	public String getActivityId(){return this.activityName;}
	public boolean isComplexActivity(){return (!isAtomicActivity);}
	public String getActivityType(){return this.activityType;}
	
	public void addSubActivity(String newActivity){
		if (this.isComplexActivity()){
			this.subActivities.add(newActivity);
			
			gc.setMessage(true, "Subactivety Added!", gc.outputMessage_compAct_Label);
		}
	}
	
	public ArrayList<String> getSubactivities(){
		return this.subActivities;
	}
	
	public void removeActivity(){
		if (itself.isComplexActivity() || subActivities.size() == 0){
			gc.activities.removeActivity(itself);
		}
		else{
			String selectedSubactivety = gc.subActivityName_modAct_ChoiceBox.getSelectionModel().getSelectedItem().toString();
			
			boolean found = false;
			for (int i = 0; ((i < subActivities.size()) && (!found)); ++i){
				if(subActivities.get(i).equals(selectedSubactivety)){
					found = true;
					subActivities.remove(i);
				}
			}
		}
		gc.setMessage(false, "Subactivety removed!", gc.outputMessage_modAct_Label);
	}
	
	public ArrayList<String> getSubActivitiesIds(){
		ArrayList<String> ids_str = new ArrayList<String>();
		
		//ids_str.add("RootActivity");
		ids_str.add(this.getActivityType());
		
		for(int i = 0; i < subActivities.size(); ++i){
			ids_str.add(this.subActivities.get(i));
		}
		
		return ids_str;
	}
	
	public void removeSubactivityByiD(String actId){
		boolean found = false;
		for(int i = 0; ((i < subActivities.size()) && (!found)); ++i){
			if (subActivities.get(i).equals(actId)){
				found = true;
				subActivities.remove(i);
			}
		}
	}
	
	public boolean isValidActivity(){return this.isValidActivity;}
}
