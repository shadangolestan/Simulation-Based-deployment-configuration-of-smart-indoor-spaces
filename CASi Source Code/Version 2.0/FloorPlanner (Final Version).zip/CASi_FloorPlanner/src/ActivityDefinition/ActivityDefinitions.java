package ActivityDefinition;

import java.util.ArrayList;

public class ActivityDefinitions {
	private ArrayList<ActivityDefinition> activities;
	private ActivityDefinition currentActiveActivity;

	public ActivityDefinitions() {
		this.activities = new ArrayList<ActivityDefinition>();
		this.currentActiveActivity = null;
	}

	public void addActivity(ActivityDefinition activity) {activities.add(activity);}
	public void removeActivity(ActivityDefinition activity) {activities.remove(activity);}
	public void removeActivityByIndex(int index) {activities.remove(index);}
	public ArrayList<ActivityDefinition> getActivities() {return activities;}
	public void setCurrentActiveActivity(ActivityDefinition currentActiveActivity) {this.currentActiveActivity = currentActiveActivity;}
	public ActivityDefinition getCurrentActiveActivity() {return currentActiveActivity;}

	public boolean isIdInList(String id) {
		for (int i = 0; i < activities.size(); ++i)
		{
			if (activities.get(i).getActivityId().equals(id)) 
				return true;
		}
		return false;
	}

	public ActivityDefinition getActivityByID(String id) {
		for (int i = 0; i < activities.size(); ++i) {
			if (activities.get(i).getActivityId().equals(id)) {
				return activities.get(i);
			}
		}
		return null;
	}
	
	public ArrayList<ActivityDefinition> getComplexActivities(){
		ArrayList<ActivityDefinition> complexActivities = new ArrayList<ActivityDefinition>();
	
		for(int i = 0; i < activities.size(); ++i){
			if(activities.get(i).isComplexActivity()){
				complexActivities.add(activities.get(i));
			}
		}
		return complexActivities;
	}
	

	
}
