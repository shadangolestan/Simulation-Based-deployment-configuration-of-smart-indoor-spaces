package application;

import java.util.ArrayList;
import java.util.List;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.StrokeLineCap;


@SuppressWarnings("unused")
public class RoomMain {
	private String roomID;
	private List<Double> values;
	private Polygon roomShape;
	public ArrayList<AnchorDrawShape> roomAnchors;
	public ArrayList<AnchorDrawShape> allAnchors;
    private TextField roomIdTextFields;
    private TextField currentPoint_Xcoord_textField;
	private double currentPoint_Xcoord;
	private TextField currentPoint_Ycoord_textField;
	private double currentPoint_Ycoord;
	private Button saveRoomIdButton;
	private Label messageLabel;
    private RoomMain itself;    
	public ArrayList<DoubleProperty> xPropertyListener;
	public ArrayList<DoubleProperty> yPropertyListener;
	public Pane pane;
	private Button savePointCoordinatesButton;
	private Label savePointCoordinatesLabel;
	private GroupController gc;
	
	public RoomMain(TextField roomIdTextFields, Pane pane, 
			TextField currentPoint_Xcoord_textField, TextField currentPoint_Ycoord_textField, Button saveRoomIdButton,
			Label messageLabel, ArrayList<AnchorDrawShape> allAnchors,
			Button savePointCoordinatesButton, Label savePointCoordinatesLabel, GroupController gc){
		this.roomID = null;
		this.values = new ArrayList<Double>();
		this.roomShape = new Polygon();
		this.roomAnchors = new ArrayList<AnchorDrawShape>();
		this.allAnchors = allAnchors;
		this.itself = this;
		this.roomIdTextFields = roomIdTextFields;
		this.xPropertyListener = new ArrayList<DoubleProperty>();
		this.yPropertyListener = new ArrayList<DoubleProperty>();	
		this.pane = pane;
		this.currentPoint_Xcoord_textField = currentPoint_Xcoord_textField;
		this.currentPoint_Ycoord_textField = currentPoint_Ycoord_textField;
		this.saveRoomIdButton = saveRoomIdButton;
		this.messageLabel = messageLabel;
		this.savePointCoordinatesButton = savePointCoordinatesButton;
		this.savePointCoordinatesLabel = savePointCoordinatesLabel;
		
		this.gc = gc;
		//this.setSelected();
		setSelectedStyle();
		
		roomShape.setOnMouseClicked(new EventHandler<MouseEvent>(){
			@Override
			public void handle(MouseEvent event) {
				messageLabel.setText("");
				if (event.getButton() == MouseButton.SECONDARY) {
 		        	pane.getChildren().remove(roomShape);
 		        	removeAnchorsFromPane();
 		        	itself.removeAnchorsFromAllAchors();
				}
 		        else if (event.getButton() == MouseButton.PRIMARY)
 		        {
 		        	roomIdTextFields.setText(roomID);
 		        	//setSelected();
 		        
 		        	saveRoomIdButton.setOnAction(new EventHandler<ActionEvent>(){
	 		   			@Override
	 					public void handle(ActionEvent event) {
	 		   				String newID = roomIdTextFields.getText();
	 		   				savePointCoordinatesLabel.setText("Coordinates changed");
	 		   				savePointCoordinatesLabel.setTextFill(Color.web("#008B00"));
	 		   				
	 		   			}
		        	});
  		          
 		        }	
			}
        });
	}
	
	
	public void addValue(double value) {roomShape.getPoints().add(value);}
	public Polygon getRoomShape (){return roomShape;}
	public void setRoomID(String room_id){this.roomID = room_id;}
	public String getRoomId(){return this.roomID;}
	public void addAnchor (AnchorDrawShape anchor) {roomAnchors.add(anchor); allAnchors.add(anchor);}
	public void removeAnchor (AnchorDrawShape anchor) {roomAnchors.remove(anchor); allAnchors.remove(anchor);}
	public ArrayList<AnchorDrawShape> getAnchors () {return roomAnchors;}
	public ArrayList<Double> get_Xcoord(){return this.get_Xcoord();}
	public ArrayList<Double> get_Ycoord(){return this.get_Ycoord();}
	public RoomMain getItself(){return this.itself;} 
	//public void setSelected(){roomIdTextFields.setText(roomID);rooms.setSelectedRoom(itself);}
	public void removeAnchorsFromPane(){for(int i = 0 ; i < roomAnchors.size(); ++i)pane.getChildren().remove(roomAnchors.get(i));}
	public void removeAnchorsFromAllAchors(){for(int i = 0 ; i < roomAnchors.size(); ++i)allAnchors.remove(roomAnchors.get(i));}
	
	public void hide(){
		this.removeAnchorsFromPane();
		pane.getChildren().remove(roomShape);
	}
	
	public void show(){
		for(int i = 0; i < allAnchors.size(); i++){
			pane.getChildren().add(allAnchors.get(i));
		}
		pane.getChildren().add(roomShape);
	}
	
	
	public void removeItself()
	{
		//rooms.removeRoom(itself);
     	pane.getChildren().remove(roomShape);
     	removeAnchorsFromPane();
     	itself.removeAnchorsFromAllAchors();
	}
	
	
	public AnchorDrawShape addAnchorCircle(){
		ObservableList<Double> currentPoints = roomShape.getPoints();
		AnchorDrawShape newPoint = createControlAnchorsFor(currentPoints);
		 roomAnchors.add(newPoint);
		 allAnchors.add(newPoint);
		return newPoint;
	}
	
	private AnchorDrawShape createControlAnchorsFor(final ObservableList<Double> points) {
    	
    	int index = points.size() - 2;
    
    	DoubleProperty xProperty = new SimpleDoubleProperty(points.get(index));
        DoubleProperty yProperty = new SimpleDoubleProperty(points.get(index + 1));
        
        xProperty.addListener(new ChangeListener<Number>() {
        	@Override
            public void changed(ObservableValue<? extends Number> ov, Number oldX, Number x) {
        		points.set(index, (double) x);
        		currentPoint_Xcoord_textField.setText(x + "");
        	}
         });

         yProperty.addListener(new ChangeListener<Number>() {
        	 @Override
             public void changed(ObservableValue<? extends Number> ov, Number oldY, Number y) {
        		 points.set(index + 1, (double) y);
        		 currentPoint_Ycoord_textField.setText(y + "");
        	 }
         });
         
         AnchorDrawShape a = new AnchorDrawShape(xProperty, yProperty, allAnchors, gc.anchorSize);
         //setSelected();
         a.setOpacity(1);
         
         a.setOnMouseClicked(new EventHandler<MouseEvent>(){
 			@Override
 			public void handle(MouseEvent e) {
 			//	setSelected();
 				if (e.getButton() == MouseButton.PRIMARY){
 					currentPoint_Xcoord_textField.setText(points.get(index) + "");
 					currentPoint_Ycoord_textField.setText(points.get(index + 1) + "");
 					a.setSelected();
 				}
 		        e.consume();
 			}
         });
         
         savePointCoordinatesButton.setOnMouseClicked(new EventHandler<MouseEvent>(){
  			@Override
  			public void handle(MouseEvent e) {
  				if (e.getButton() == MouseButton.PRIMARY){
  					try{
  						double x_coord_new = Double.parseDouble(currentPoint_Xcoord_textField.getText());
  						double y_coord_new = Double.parseDouble(currentPoint_Ycoord_textField.getText());
  						
  						//a.setLayoutX(x_coord_new);a.setLayoutY(y_coord_new);
  						a.setCenterX(x_coord_new);a.setCenterY(y_coord_new);
  						savePointCoordinatesLabel.setText("Coordinates changed");
  						savePointCoordinatesLabel.setTextFill(Color.web("#008B00"));
  					}
  					catch (Exception exception){
  						savePointCoordinatesLabel.setText("Invalid input");
  						savePointCoordinatesLabel.setTextFill(Color.web("#CD0000"));
  					}
  				}
  		        e.consume();
  			}
          });
         
         xPropertyListener.add(xProperty);
         yPropertyListener.add(yProperty);
        
         return a;
    }
	/*
	public void setUnselectedStyle(){
		roomShape.setStroke(Color.DARKCYAN);
		roomShape.setStrokeWidth(4);
		roomShape.setStrokeLineCap(StrokeLineCap.ROUND);
		roomShape.setFill(Color.CORNSILK.deriveColor(0, 1.2, 1, 0.6));
	}
	*/
	public void setSelectedStyle(){
		roomShape.setStroke(Color.DARKGREEN);
		roomShape.setStrokeWidth(4);
		roomShape.setStrokeLineCap(StrokeLineCap.ROUND);
		roomShape.setFill(Color.AQUAMARINE.deriveColor(0, 1.2, 1, 0.6));
	}
	
}
