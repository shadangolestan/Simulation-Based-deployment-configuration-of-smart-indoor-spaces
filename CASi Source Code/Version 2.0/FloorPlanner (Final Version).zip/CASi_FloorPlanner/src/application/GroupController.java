package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import Action.Action;
import Action.Actions;
import ActivityDefinition.ActivityDefinitions;
import ActivityInsatnce.ActivityInstance;
import ActivityInsatnce.ActivityInstances;
import ActivityDefinition.ActivityDefinition;
import exportClasses.XML_Exporter;
import geometry.GeometryFunctions;
import geometry.Point;
import importClasses.XML_Importer;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import obstacles.Obstacle;
import obstacles.Obstacles;
import places.Place;
import places.Places;
import rooms.Room;
import rooms.Rooms;
import sensors.Sensor;
import sensors.Sensors;
import zoom.ZoomController;

@SuppressWarnings("rawtypes")
public class GroupController {
	ArrayList<String> core_activity_ids;
	public int anchorSize;
	public ActivityDefinitions activities;
	public ActivityInstances activityInstances;
	@FXML public Label unitsOfMeassurmentLabel;
	
	
	@FXML public TitledPane actInstDefTab;
	@FXML public TextField actvityInstanceId_def_TextField;

	@FXML public ChoiceBox actvityName_def_ChoiceBox;
	@FXML public FlowPane subactivity_def_FlowPane;
	@FXML public Label output_instAct_def_Label;
	@FXML public Button create_def_Button;

	@FXML public ChoiceBox actvityInstanceId_mod_ChoiceBox;
	@FXML public ChoiceBox actvityType_mod_ChoiceBox;
	@FXML public ChoiceBox actvityTarget_mod_ChoiceBox;
	@FXML public TextField actvityTimer_mod_TextField;
	@FXML public Label output_instAct_mod_Label;
	@FXML public Button submit_mod_Button;
	@FXML public Button delete_mod_Button;
	
	@FXML public TitledPane actDefTab;
	@FXML public RadioButton atomicAction_RadioButton;
	@FXML public RadioButton complexAction_RadioButton;
	@FXML public TextField activityName_actDef_TextField;
	@FXML public ChoiceBox activityType_actDef_ChoiceBox;
	@FXML public ChoiceBox activityTarget_actDef_ChoiceBox;
	//@FXML public TextField activityTime_actDef_TextField; // new-->
	
	@FXML public Label outputMessage_actDef_Label;
	@FXML public Button create_actDef_Button;
	@FXML public ChoiceBox activityName_compAct_ChoiceBox;
	@FXML public ChoiceBox activityToAddName_compAct_ChoiceBox;
	@FXML public Button add_compAct_Button;
	@FXML public Label outputMessage_compAct_Label;
	@FXML public ChoiceBox activityName_modAct_ChoiceBox;
	@FXML public ChoiceBox subActivityName_modAct_ChoiceBox;
	@FXML public ChoiceBox activityType_modAct_ChoiceBox;
	@FXML public ChoiceBox activityTarget_modAct_ChoiceBox;
	@FXML public Label outputMessage_modAct_Label;
	@FXML public Button submit_modAct_Button;
	@FXML public Button delete_modAct_Button;	
	
	
	@FXML FlowPane sensorDescriptionFlowPane;
	ZoomController zoomController;
	@FXML ScrollPane scrollPane;
	public double scale = 1;
	
	public final String SENSOR_ROOT_DIR = "@../../Sensors";
	public final String SENSOR_DEFINITION_DIR = "Definition";
	public final String SENSOR_DEFINITION_FILE = "definition.fxml";
	public final String SENSOR_IMAGE_DIR = "Image";
	public final String SENSOR_IMAGE_ORIG_FILE = "image.png";
	public final String SENSOR_IMAGE_HO_FILE = "image_ho.png";
	
	public ClipboardContent clipboardContent;
	private final Color SUCCESS_COLOR = Color.GREEN;
	private final Color FAIL_COLOR = Color.RED;

	ArrayList<String> sensorClaseese;
	HashMap<String, FlowPane> sensorSpecsPane;
	String currentClippboeardContent;
	XML_Exporter exporter;
	XML_Importer importer;
	String[] directories;
	HashMap<String, String> sensorDescription;
	@FXML public TextArea sensorDescription_TextArea;

	ArrayList<String> action_ids;
	ArrayList<String> agent_ids;
	ArrayList<String> action_types;
	ArrayList<String> target_ids;
	ArrayList<String> activity_types;
	/*-------------------------------------------------------*/
	private final int DRAW_AREA_WIDTH = 900;
	private final int DRAW_AREA_HEIGHT = 900;
	/*-------------------------------------------------------*/
	@FXML private ImageView motionSensor;
	@FXML private Button loadImageButton;
	@FXML private ImageView floorPlanImageView;
	@FXML Pane pane;
	@FXML private FlowPane sensorParametersFlowPane;
	@FXML FlowPane sensorFlowPane;
	@FXML private Button saveSensorButton;
	@FXML private FlowPane layoutTest;

	/*-------------------------------------------------------*/
	// Draw Room Shapes Tab Elements
	@FXML public ToggleButton drawRoomShapeButton;
	@FXML public TextField roomIdTextFields;

	@FXML public TextField currentPoint_Xcoord_textField;
	@FXML public TextField currentPoint_Ycoord_textField;

	@FXML public Button saveRoom;
	@FXML public Label resetIdLabel;

	public boolean areObstaclesHidden;
	@FXML public Button hideObstacleShape_Button;
	/*-------------------------------------------------------*/
	// Door
	@FXML public ImageView simpleDoorImageView;
	@FXML public Label doorPanelMessageLabel;
	@FXML public TextField currentDoorID;
	@FXML public TextField currentDoor_Xcoord_textField;
	@FXML public TextField currentDoorSize;
	@FXML public TextField currentDoor_Ycoord_textField;
	@FXML public Button saveDoorIdButton;
	@FXML public Doors doors;

	/*-------------------------------------------------------*/
	// Draw Room Shapes Tab Elements
	@FXML public ToggleButton drawObstacleShapeButton;
	@FXML public TextField obstacleIdTextFields;

	@FXML public TextField currentObstaclePoint_Xcoord_textField;
	@FXML public TextField currentObstaclePoint_Ycoord_textField;

	@FXML public Button saveObstacle;
	@FXML public Label resetObstacleIdLabel;

	@FXML public Button savePointCoordinatesButton;
	@FXML public Label savePointCoordinatesLabel;

	boolean areRoomsHidden;
	@FXML private Button hideRoomShape_Button;

	/*-------------------------------------------------------*/
	// Other
	private boolean drawPolygon;
	private boolean drawObstaclePolygon;
	public String draggedObjectType;
	private FileChooser fileChooser;
	public double current_x;
	public double current_y;
	public ArrayList<ImageView> sensorsImageViews;
	public Sensors sensors;
	public ArrayList<AnchorDrawShape> allRoomAnchors;
	public ArrayList<AnchorDrawShape> allObstacleAnchors;
	public Rooms rooms;
	public Room currentRoom;

	public Obstacles obstacles;
	public Obstacle currentObstacle;

	/* ======================================================= */
	/* ====================WORLD CALIBRATION1================= */
	/*-------------------------------------------------------*/
	// Room
	@FXML private ToggleButton wc_drawRoom_ToggleButton;
	@FXML private TextField wc_roomID_TextField;
	@FXML private Button wc_saveRoomID_Button;
	@FXML private Label wc_resetIdLabel;
	@FXML private Label wc_savePointCoordinatesLabel;
	@FXML private TextField wc_currentPointX_coord_TextField;
	@FXML private TextField wc_currentPointY_coord_TextField;
	@FXML private Button wc_saveCurrentPointCoord_Button;
	@FXML private Button wc_hideRoomShape_Button;

	private ArrayList<AnchorDrawShape> wc_anchorsMainRoom;
	private RoomMain wc_room;
	private boolean wc_drawRoom;
	private boolean wc_isMainRoomHidden;

	@FXML public TextField wc_horizontal_p1_xCoord_TextField;
	@FXML public TextField wc_horizontal_p1_yCoord_TextField;
	@FXML public TextField wc_horizontal_p2_xCoord_TextField;
	@FXML public TextField wc_horizontal_p2_yCoord_TextField;
	@FXML public TextField wc_horizontal_distance_TextField;
	@FXML public Button wc_saveHorizontal_Button;
	@FXML public Button wc_hideHorizontal_Button;
	@FXML public Label wc_horizontalCalibrationLine_Label;

	@FXML private TextField wc_vertical_p1_xCoord_TextField;
	@FXML private TextField wc_vertical_p1_yCoord_TextField;
	@FXML private TextField wc_vertical_p2_xCoord_TextField;
	@FXML private TextField wc_vertical_p2_yCoord_TextField;
	@FXML private TextField wc_vertical_distance_TextField;
	@FXML private Button wc_saveVertical_Button;
	@FXML private Button wc_hideVertical_Button;
	@FXML private Label wc_verticalCalibrationLine_Label;

	@FXML private ToggleButton wc_verticalCalibration_ToggleButton;
	@FXML private ToggleButton wc_horizontalCalibration_ToggleButton;

	private boolean wc_drawVerticalCalibrationLine;
	private boolean wc_drawHorizontalCalibrationLine;
	private boolean wc_isVerticalCalibrationLineHidden, wc_isHorizontalCalibrationLineHidden;
	public InteractableLine horizontalCalibrationLine;
	private InteractableLine verticalCalibrationLine;
	public InteractableLine distanceMeasuremetLine;
	
	/* ======================================================= */
	/* AGENTS */
	@FXML public Button a_addAgent_Button;
	@FXML public TextField a_agentID_TextField;
	@FXML public TextField a_agentName_TextField;
	@FXML public TextField a_agentRole_TextField;
	@FXML public TextField a_XCoord_TextField;
	@FXML public TextField a_YCoord_TextField;
	@FXML public  Label a_addAgent_Label;

	@FXML public Button a_modifyAgent_Button;
	@FXML public TextField a_agentIDModified_TextField;
	@FXML public TextField a_agentNameModified_TextField;
	@FXML public TextField a_agentRoleModified_TextField;
	@FXML public TextField a_XCoordModified_TextField;
	@FXML public TextField a_YCoordModified_TextField;
	@FXML public Label a_modifyAgent_Label;
	
	@FXML public Button a_showHideAgents_Button;
	public boolean a_areAgentsHidden;
	public Agents agents;


	@FXML public Button p_addPlace_Button;
	@FXML public TextField p_placeID_TextField;
	@FXML public TextField p_XCoord_TextField;
	@FXML public TextField p_YCoord_TextField;
	@FXML public Label p_addPlace_Label;

	@FXML public Button p_modifyPlace_Button;
	@FXML public TextField p_placeIDModified_TextField;
	@FXML public TextField p_XCoordModified_TextField;
	@FXML public TextField p_YCoordModified_TextField;
	@FXML public Label p_modifyPlace_Label;

	@FXML private Button p_showHidePlaces_Button;
	boolean p_arePlaceHidden;
	public Places places;
	
	@FXML public ImageView placeImageView;

	/* ======================================================= */
	/* Actions */
	@FXML TitledPane ca_TitledPane;
	@FXML public TextField ca_actionID_TextField;
	
	
	@FXML public Pane ca_createActionPanel;
	@FXML public ChoiceBox ca_parentActionList;
	
	@FXML public ChoiceBox ca_agentID_ChoiceBox;
	@FXML public ChoiceBox ca_actionInst_ChoiceBox;
	
	@FXML public DatePicker ca_actionStartData_DatePicker;
	@FXML public TextField ca_actionStartTime_TextField;
	@FXML public Label ca_addAction_Label;
	@FXML Button ca_addButton_Button;
	@FXML public CheckBox ca_subtask;
	public boolean createSubtask;
	
	///START DEFINE ACTIVITY SECTION
	@FXML public CheckBox ca_subtask_da;
	@FXML public TextField ca_actionID_TextField_da;
	@FXML public Label ca_addAction_Label_da;
	@FXML public Button ca_addButton_Button_da;
	///END DEFINE ACTIVITY SECTION
	
	@FXML public ChoiceBox ma_actionID_ChoiceBox;
	@FXML public ChoiceBox ma_subactions;
	@FXML public ChoiceBox ma_agentID_ChoiceBox;
	@FXML public DatePicker ma_actionStartData_DatePicker;
	@FXML public TextField ma_actionStartTime_TextField;
	@FXML public Label ma_addAction_Label;
	@FXML public Button ma_modifyAction_Button;
	@FXML public Button ma_deleteAction_Button;
	public  DateTimeFormatter dateTimeFormatter;
	public Actions actions;

	//------------------
	@FXML public TextField protocol_TextField;
	@FXML public TextField ip_TextField;
	@FXML public TextField port_Text_Field;
	
	@FXML public DatePicker sim_startDate_DatePicker;
	@FXML public TextField sim_startTime_TextField;
	@FXML public Label sim_update_startDate_Label;
	@FXML public Button sim_modify_StartTime_Button;

	public String simStartTime;
	public String simStartDate;
	
	private ArrayList<Label> allLabels;
	private boolean areLabelsPopulated;

	/*Distance Line Start=======================================*/
	@FXML public ToggleButton draw_distLine_ToggleButton;
	@FXML public ToggleButton showHide_distLine_ToggleButton;

	@FXML public Label distanceLinePoints_Label;
	@FXML public Label distanceLineMeter_Label;
	boolean drawDistanceLine;
	/*Distance Line End=========================================*/
	
	public Pane getMainPane() {return pane;}

	/**
	 * This is the class constructor
	 * 
	 * @throws IOException
	 * @throws SAXException
	 * @throws ParserConfigurationException
	 */
	public GroupController() throws SAXException, IOException, ParserConfigurationException {
		ca_parentActionList = new ChoiceBox();
		activities = new ActivityDefinitions();
		activityInstances = new ActivityInstances();
		createSubtask = false;
		draggedObjectType = "";
		clipboardContent = null;
		wc_drawRoom = false;
		sensorsImageViews = new ArrayList<ImageView>();
		sensors = new Sensors();
		drawPolygon = false;
		drawObstaclePolygon = false;
		rooms = new Rooms();
		obstacles = new Obstacles();
		doors = new Doors();
		agents = new Agents();
		places = new Places();
		actions = new Actions();
		a_areAgentsHidden = false;
		p_arePlaceHidden = false;

		allRoomAnchors = new ArrayList<AnchorDrawShape>();
		allObstacleAnchors = new ArrayList<AnchorDrawShape>();

		wc_anchorsMainRoom = new ArrayList<AnchorDrawShape>();

		wc_isMainRoomHidden = false;
		areRoomsHidden = false;

		wc_drawVerticalCalibrationLine = false;
		wc_drawHorizontalCalibrationLine = false;
		drawDistanceLine = false;

		File file = new File("@../../Sensors/");
		sensorClaseese = new ArrayList<String>();
		sensorSpecsPane = new HashMap<String, FlowPane>();

		directories = file.list(new FilenameFilter() {
			@Override
			public boolean accept(File current, String name) {
				return new File(current, name).isDirectory();
			}
		});

		sensorDescription = determineSensorDescipriton();
		exporter = new XML_Exporter(this);
		importer = new XML_Importer(this);
		
		
		simStartTime = null;
		simStartDate = null;
		
		allLabels = new ArrayList<Label>();
		areLabelsPopulated = false;
		
		anchorSize = 2;
		
		core_activity_ids = new ArrayList<String>();
		core_activity_ids.add("Move");
		core_activity_ids.add("Sit");
		core_activity_ids.add("SitTimer");
		core_activity_ids.add("Stay");
		core_activity_ids.add("StayTimer");
		core_activity_ids.add("Turn On");
		core_activity_ids.add("Turn Off");
		core_activity_ids.add("Set Turn Off Timer");
	}

	
	public void modifysSimStartTime_ButtonHandler()
	{
		LocalDate simStartData_LocalDate = sim_startDate_DatePicker.getValue();
		String simStartDate_temp = null;
		
		if (simStartData_LocalDate != null) simStartDate_temp = simStartData_LocalDate.toString();
		
		String simStartTime_temp = sim_startTime_TextField.getText().trim();
		
		if ((simStartTime_temp != null) && (!simStartTime_temp.equals(""))
				&& (simStartDate_temp != null) && (!simStartDate_temp.equals(""))){
			
			// validate time
			String validataionOutput = validateTimeFormat(simStartTime_temp);
	
			if (validataionOutput.equals("")){
				simStartTime = simStartTime_temp;
				simStartDate = simStartDate_temp;
				setMessage(true, "Start Date and Time updated", sim_update_startDate_Label);
			}
			else{
				setMessage(false, validataionOutput, sim_update_startDate_Label);
			}
		}
		else{
			setMessage(false, "Please enter date and time", sim_update_startDate_Label);
		}
		
	}
	
	
	public String validateTimeFormat(String time) {
		String[] time_arr = time.trim().split(":");

		int hours = -1;
		int minutes = -1;
		int seconds = -1;
		if (time_arr.length != 3) return "Wrong Format. Should be HH:MM:SS";
		try {
			hours = Integer.parseInt(time_arr[0]);
			minutes = Integer.parseInt(time_arr[1]);
			seconds = Integer.parseInt(time_arr[2]);
		} catch (Exception e) {
			return "Time format is HH:MM:SS";
		}

		if ((hours < -1) || (hours > 23))
			return ("Hours must be from 0 to 23 inclusive");
		if ((minutes < -1) || (minutes > 59))
			return ("Minutes must be from 0 to 59 inclusive");
		if ((seconds < -1) || (seconds > 59))
			return ("Seconds must be from 0 to 59 inclusive");

		return "";
	}
	
    public void initZoomController() throws Exception {
    	zoomController = new ZoomController(pane);
        scrollPane.setContent(zoomController);
        scrollPane.setPannable(true);

    }
	
	public HashMap<String, String> determineSensorDescipriton() {
		try {
			HashMap<String, String> sensorDescription = new HashMap<String, String>();

			for (int i = 0; i < directories.length; ++i) {
				String filePathDefinition = ("@../../Sensors/" + directories[i] + "/Definition/definition.fxml");

				File xmlFileSensor = new File(filePathDefinition);

				DocumentBuilderFactory documentBuilderFactorySensor = DocumentBuilderFactory.newInstance();
				DocumentBuilder documentBuilderSensor = documentBuilderFactorySensor.newDocumentBuilder();
				Document documentSensor = documentBuilderSensor.parse(xmlFileSensor);

				NodeList sensorSpecs = documentSensor.getChildNodes().item(0).getChildNodes();

				for (int j = 0; j < sensorSpecs.getLength(); ++j) {
					String currentItem = sensorSpecs.item(j).getNodeName();
					if (currentItem.equals("description")) 
						sensorDescription.put(directories[i], sensorSpecs.item(j).getTextContent());
				}
			}
			return sensorDescription;
		} 
		catch (ParserConfigurationException e1) {
			e1.printStackTrace();
		} catch (SAXException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		return null;
	}

	public void generateRoomXML() {
		try {
			initZoomController();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//public void generateSensorXML() {exporter.generateSensorXML();};
	public void generateAgentsXML() {exporter.generateAgentsXML();};
	public void generateLocationsXML() {exporter.generateLocationXML();};
	public void generateActionsXML() {exporter.generateActionsXML();};
	public void generateSimWorldMillimeterPrecission(){generateActionsSimulatedWorldXML(1000);}
	public void generateSimWorldCentimeterPrecission(){generateActionsSimulatedWorldXML(100);}
	public void generateSimWorldDecimeterPrecission(){generateActionsSimulatedWorldXML(10);}
	public void generateActionsSimulatedWorldXML(int precission) {exporter.generateSimulatedWorldXML(precission);}

	
	public void importWorldXML() {
		
		String popupMessage = "Import was successfull";
		Text popUpText = new Text();
		popUpText.setText(popupMessage);
		
		final Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initOwner(null);
        VBox dialogVbox = new VBox(20);
        
        Scene dialogScene = new Scene(dialogVbox, 250, 100);
        dialog.setScene(dialogScene);
         
		try{ 
			popupMessage = "Error Loading File";
			importer.loadFile();
			popupMessage = "Error Loading Horizontal Calibration Line";
			
			importer.importHorizontalCalibrationLine();
			popupMessage = "Error Loading Sensors";
			popUpText.setText(popupMessage);
			
			importer.importSensors();
			popupMessage = "Error Loading Agents";
			popUpText.setText(popupMessage);
			
			importer.importAgents();
			popupMessage = "Error Loading Places";
			popUpText.setText(popupMessage);
			
			importer.importPlaces();
			popupMessage = "Error Loading Rooms";
			popUpText.setText(popupMessage);
			
			importer.importRooms();
			popupMessage = "Error Loading Obstacless";
			popUpText.setText(popupMessage);
			
			importer.importObstacles();
			
			popupMessage = "Error Loading Actions Definitions";
			popUpText.setText(popupMessage);
			importer.importActionDefinition();		
			
			popupMessage = "Error Loading Actions Insatances";
			popUpText.setText(popupMessage);
			importer.importActionInstances();
			
			popupMessage = "Error Loading Actions";
			popUpText.setText(popupMessage);
			
			importer.importActions();
			popupMessage = "Error Loading Simulation Start Time";
			popUpText.setText(popupMessage);
			
			importer.importSimStartTime();
			popupMessage = "Error Loading MQTT Brocker Connection Information";
			popUpText.setText(popupMessage);
			
			importer.importMqttConnectionInformation();
		}
		catch(Exception e){
			e.printStackTrace();
			dialogVbox.getChildren().add(new Text(popupMessage));
			dialog.show();
		}
	}

	public void setSensorDescription(Event event) {
		String currentSensorType = event.getSource().toString().split("id=")[1].split(",")[0].trim();
		sensorDescription_TextArea.setText(sensorDescription.get(currentSensorType));
		if (sensorParametersFlowPane.getChildren().size() > 0)
			sensorParametersFlowPane.getChildren().remove(0);
	}

	
	public void sensorPanelOver_On(Event event) {
		String currentSensorName = event.getSource().toString().split("id=")[1].split(",")[0].trim();
		if (Arrays.toString(directories).contains(currentSensorName)) {
			File file = new File("@../../Sensors/" + currentSensorName + "/Image/image_ho.png");
			URL url;
			try {
				url = file.toURI().toURL();
				ImageView currentImage = (ImageView) event.getSource();
				currentImage.setImage(new Image(url.toExternalForm()));
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
		}
	}

	
	public void sensorPanelOver_Off(Event event) {
		String currentSensorName = event.getSource().toString().split("id=")[1].split(",")[0].trim();

		if (Arrays.toString(directories).contains(currentSensorName)) {
			File file = new File("@../../Sensors/" + currentSensorName + "/Image/image.png");
			URL url;
			try {
				url = file.toURI().toURL();
				ImageView currentImage = (ImageView) event.getSource();
				currentImage.setImage(new Image(url.toExternalForm()));
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
		}
	}

	
	public void sensorPanelOver_On(ImageView iv, String sensorType) {
		String currentSensorName = sensorType;
		if (Arrays.toString(directories).contains(currentSensorName)) {
			File file = new File("@../../Sensors/" + currentSensorName + "/Image/image_ho.png");
			URL url;
			try {
				url = file.toURI().toURL();
				iv.setImage(new Image(url.toExternalForm()));
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
		}
	}
	

	
	public void sensorPanelOver_Off(ImageView iv, String sensorType) {
		if (Arrays.toString(directories).contains(sensorType)) {
			File file = new File("@../../Sensors/" + sensorType + "/Image/image.png");
			URL url;
			try {
				url = file.toURI().toURL();
				iv.setImage(new Image(url.toExternalForm()));
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
		}
	}

	
	
	public void doorPanelOver_On() {
		File file = new File("@../../image/door/door_ho.png");
		URL url;
		try {
			url = file.toURI().toURL();
			simpleDoorImageView.setImage(new Image(url.toExternalForm()));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
	
	

	public void doorPanelOver_Off() {
		File file = new File("@../../image/door/door.png");
		URL url;
		try {
			url = file.toURI().toURL();
			simpleDoorImageView.setImage(new Image(url.toExternalForm()));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
	
	
	
	public void placePanelOver_On() {
		File file = new File("@../../image/place/place_ho.png");
		URL url;
		try {
			url = file.toURI().toURL();
			simpleDoorImageView.setImage(new Image(url.toExternalForm()));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
	
	

	public void placePanelOver_Off() {
		File file = new File("@../../image/place/place.png");
		URL url;
		try {
			url = file.toURI().toURL();
			simpleDoorImageView.setImage(new Image(url.toExternalForm()));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	
	
	public void doorPanelOver_On(ImageView iv) {
		File file = new File("@../../image/door/door_ho.png");
		URL url;
		try {
			url = file.toURI().toURL();
			iv.setImage(new Image(url.toExternalForm()));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

	}

	
	
	public void doorPanelOver_Off(ImageView iv) {
		File file = new File("@../../image/door/door.png");
		URL url;
		try {
			url = file.toURI().toURL();
			iv.setImage(new Image(url.toExternalForm()));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public void setActionModificationPanelValues(Action action) {
		if (action != null) {
			ma_agentID_ChoiceBox.getSelectionModel().select(action.getAgent().getAgentId());
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
			LocalDate date = null;
			try{date = LocalDate.parse(action.getActionDate());}
			catch(Exception e){date = LocalDate.parse(action.getActionDate(), formatter);}
			ma_actionStartData_DatePicker.setValue(date);
			ma_actionStartTime_TextField.setText(action.getActionTime());
		}
	}

	@SuppressWarnings("unchecked")
	public void tabExpandedAction() {
		
		ma_actionID_ChoiceBox.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
			public void changed(ObservableValue ov, Number value, Number new_value) {
				ma_subactions.setItems(FXCollections.observableArrayList(new ArrayList<String>()));
				int new_value_int = new_value.intValue();
				if (new_value_int >= 0) {
					String selectedActionID = action_ids.get(new_value_int);
					Action selectedAction = actions.getActionByID(selectedActionID);
					actions.setCurrentActiveAction(selectedAction);
					setActionModificationPanelValues(selectedAction);
					populateModificationParentActionChoiceBox(selectedAction.getActionId());
					if (selectedAction.getSubactions() == null){
					}
				}
			}
		});
		
		populateArraysForActionChackBoxes();

		ca_agentID_ChoiceBox.setItems(FXCollections.observableArrayList(agent_ids));
		ca_actionInst_ChoiceBox.setItems(FXCollections.observableArrayList(action_types));

		if (actions.getActions().size() > 0){
			populateAgentsModificationPanel();
		
			ma_subactions.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
				public void changed(ObservableValue ov, Number value, Number new_value) {
					int new_value_int = new_value.intValue();
					if (new_value_int >= 0) {

						
						@SuppressWarnings("unused")
						Action subaction_temp =  actions.getCurrentActiveAction();
					
						if (new_value_int > 0){
							subaction_temp = actions.getCurrentActiveAction().getSubactions().get(new_value_int - 1);
							ma_agentID_ChoiceBox.setDisable(true);
							ma_actionStartData_DatePicker.setDisable(true);
							ma_actionStartTime_TextField.setDisable(true);
						}
						else{
							ma_agentID_ChoiceBox.setDisable(false);
							ma_actionStartData_DatePicker.setDisable(false);
							ma_actionStartTime_TextField.setDisable(false);
						}
					}
				}
			});
			
		}
		else ma_actionID_ChoiceBox.setItems(FXCollections.observableArrayList(new ArrayList<String>()));
	}

	
	public void populateArraysForActionChackBoxes() {
		action_ids = new ArrayList<String>();
		for (int i = 0; i < actions.getActions().size(); ++i)
			action_ids.add(actions.getActions().get(i).getActionId());

		agent_ids = new ArrayList<String>();
		ArrayList<Agent> agents_arrList = agents.getAgents();
		for (int i = 0; i < agents_arrList.size(); ++i)
			agent_ids.add(agents_arrList.get(i).getAgentId());

		action_types = new ArrayList<String>();
		action_types.addAll(core_activity_ids);

		for (int i = 0; i < activityInstances.getactivityInstancies().size(); ++i)
			action_types.add(activityInstances.getactivityInstancies().get(i).getActivityInstanceId());
		
		
		target_ids = new ArrayList<String>();
		for (int i = 0; i < places.getPlaces().size(); ++i)
			target_ids.add(places.getPlaces().get(i).getPlaceId());
		for (int i = 0; i < rooms.getRooms().size(); ++i)
			target_ids.add(rooms.getRooms().get(i).getRoomId());
		for (int i = 0; i < sensors.getSensors().size(); ++i)
			target_ids.add(sensors.getSensors().get(i).getSensorId());
	}

	
	@SuppressWarnings("unchecked")
	public void addActionButtonHandler() {
		createSubtask= ca_subtask.isSelected();
		
		Action newAction = new Action(this);
		if (newAction.isValidAction()){
			if (!createSubtask){
				actions.addAction(newAction);
				populateAgentsModificationPanel();
				ma_actionID_ChoiceBox.getSelectionModel().select(newAction.getActionId());
				setActionModificationPanelValues(newAction);
			}
			else populateParentActionChoiceBox();
		}
	}
	
//	public void addActivityButtonHandler(){System.out.println("Submit Activity Modification");}

	
	@SuppressWarnings("unchecked")
	public void populateParentActionChoiceBox(){
		action_ids = new ArrayList<String>();
		for (int i = 0; i < actions.getActions().size(); ++i)
			action_ids.add(actions.getActions().get(i).getActionId());
		ca_parentActionList.setItems(FXCollections.observableArrayList(action_ids));
	}
	
	
	@SuppressWarnings("unchecked")
	public void populateModificationParentActionChoiceBox(String parentActionID){
		Action parentAction = actions.getActionByID(parentActionID);
		ArrayList<String> current_subactions = parentAction.getSubactionIds();
		
		ma_subactions.setItems(FXCollections.observableArrayList(current_subactions));
		if ((current_subactions != null) && (current_subactions.size() > 0)) ma_subactions.getSelectionModel().select(current_subactions.get(0));
	}
	
	
	@SuppressWarnings("unchecked")
	public void populateAgentsModificationPanel() {
		populateArraysForActionChackBoxes();
		ma_agentID_ChoiceBox.setItems(FXCollections.observableArrayList(agent_ids));
		ma_actionID_ChoiceBox.setItems(FXCollections.observableArrayList(action_ids));
	}



	@SuppressWarnings("unchecked")
	public void updateActionChoiceBox() {
		Object selectedItem = ma_actionID_ChoiceBox.getSelectionModel().getSelectedItem();
		if (selectedItem != null) {
			String selectedAction = ma_actionID_ChoiceBox.getSelectionModel().getSelectedItem().toString();
			Action currentSelectedAction = actions.getActionByID(selectedAction);
			ma_agentID_ChoiceBox.getSelectionModel().select(currentSelectedAction.getAgent().getAgentId());
		}
	}

	
	public void modifyActionButtonHandler() {
		Action currentModifiedAction = null;
		try{
			currentModifiedAction = actions.getActionByID(ma_actionID_ChoiceBox.getSelectionModel().getSelectedItem().toString());
			String subActionId = ma_subactions.getSelectionModel().getSelectedItem().toString();
			
			if (!subActionId.equals("Root Action")){
				currentModifiedAction = currentModifiedAction.getSubActionByID(subActionId);
			}
			else{
				createSubtask = true;
			}
		}
		catch(Exception e){setMessage(false, "Invalid Action ID", ma_addAction_Label); return;}
		currentModifiedAction.validateAndRecord(false);
		createSubtask = false;
	}

	public void deleteActionButtonHandler() {
		try {
			if (actions.getActions().size() > 0) {
				String actionID_temp = ma_actionID_ChoiceBox.getSelectionModel().getSelectedItem().toString();
				actions.getActions().remove(actions.getActionByID(actionID_temp));
				ma_agentID_ChoiceBox.getSelectionModel().clearSelection();
				ma_actionID_ChoiceBox.getSelectionModel().clearSelection();

				ma_actionStartData_DatePicker.setValue(null); 
				ma_actionStartTime_TextField.setText("");

				tabExpandedAction();

				setMessage(true, "Action Deleted", ma_addAction_Label);
			}
		} catch (Exception e) {
			setMessage(false, "Action Id missing", ma_addAction_Label);
			return;
		}
	}

	public void saveAgentModification() {agents.saveAgentConfiguration();}
	public void savePlaceModification() {places.savePlaceConfiguration();}

	
	public void addAgentButtonAction() {	
		Agent newAgent = new Agent(this);
		if (newAgent.isValid())
		{
			agents.addAgent(newAgent);
			a_agentID_TextField.setText("");
			a_agentName_TextField.setText("");
			a_agentRole_TextField.setText("");
			a_XCoord_TextField.setText("");
			a_YCoord_TextField.setText("");
		}
	}
	
	
	public void addPlaceButtonAction() {
		Place newPlace = new Place(this);
		
		if (newPlace.isValidPlace()){
			places.addPlace(newPlace);
			p_placeID_TextField.setText("");
			p_XCoord_TextField.setText("");
			p_YCoord_TextField.setText("");
		}
	}


	public FlowPane createFlowPane(String SensorName, ImageView dbImageView) {
		try {
			HashMap<String, TextField> sensorFields = new HashMap<String, TextField>();
			HashMap<String, String> sensorFieldValues = new HashMap<String, String>();
			
			FlowPane currentSensorFlowPane = new FlowPane();
			Coordinates sensorCoordinates = new Coordinates();
			currentSensorFlowPane.setPrefHeight(327.0);
			currentSensorFlowPane.setPrefWidth(222.0);

			currentSensorFlowPane.prefHeight(1);
			currentSensorFlowPane.prefWidth(1);

			String filePathDefinition = ("@../../Sensors/" + SensorName + "/Definition/definition.fxml");
			sensorClaseese.add(SensorName);

			File xmlFileSensor = new File(filePathDefinition);

			DocumentBuilderFactory documentBuilderFactorySensor = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilderSensor = documentBuilderFactorySensor.newDocumentBuilder();
			Document documentSensor = documentBuilderSensor.parse(xmlFileSensor);

			NodeList sensorSpecs = documentSensor.getChildNodes().item(0).getChildNodes();

			for (int j = 0; j < sensorSpecs.getLength(); ++j) {
				String currentItem = sensorSpecs.item(j).getNodeName();
				if (!currentItem.toLowerCase().equals("description")) {
					Label sensorHeaderLabel = new Label();
					sensorHeaderLabel.setPrefWidth(220);

					Label sensorClass = new Label();
					sensorClass.setPrefWidth(120);
					sensorClass.setText(currentItem);
					sensorFieldValues.put(currentItem, "");

					TextField sensorContent = new TextField();
					sensorContent.setPrefWidth(130);
					sensorContent.setPrefHeight(5);
					
					
					Label sensorNotes = new Label();
					sensorNotes.setPrefHeight(5);
					sensorNotes.setPrefWidth(50);
					if (currentItem.equals("radius") || currentItem.equals("rayLength"))
						sensorNotes.setText("   Meters");
					else if (currentItem.equals("consumptionElectricity"))
						sensorNotes.setText("   Watts");
					else if (currentItem.equals("consumptionWater"))
						sensorNotes.setText("   L/s");
						
					currentSensorFlowPane.getChildren().add(sensorHeaderLabel);
					currentSensorFlowPane.getChildren().add(sensorClass);
					currentSensorFlowPane.getChildren().add(sensorContent);
					currentSensorFlowPane.getChildren().add(sensorNotes);

					if (currentItem.equals("posX")) {
						sensorCoordinates.setX_TextField(sensorContent);
					} else if (currentItem.equals("posY")) {
						sensorCoordinates.setY_TextField(sensorContent);
					} else {
						sensorFields.put(currentItem, sensorContent);
					}
				}
			}
			Label sensorHeaderLabel = new Label();
			sensorHeaderLabel.setPrefWidth(220);
			currentSensorFlowPane.getChildren().add(sensorHeaderLabel);

			Button saveSensorButton = new Button("      Save Parameter      ");
			currentSensorFlowPane.getChildren().add(saveSensorButton);

			sensorSpecsPane.put(SensorName, currentSensorFlowPane);

			if (sensorParametersFlowPane.getChildren().size() > 0)
				sensorParametersFlowPane.getChildren().remove(0);

			sensorParametersFlowPane.getChildren().add(currentSensorFlowPane);

			Sensor currentSensor = new Sensor(currentSensorFlowPane, dbImageView,
					sensorParametersFlowPane, saveSensorButton, sensorFields, sensorFieldValues, sensorHeaderLabel,
					sensorDescription.get(dbImageView.getId().toString()), this);

			
			sensors.addSensor(currentSensor);

			return currentSensorFlowPane;
		}
		catch (ParserConfigurationException e1) {
			e1.printStackTrace();
		} catch (SAXException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		return null;
	}

	public void saveSensorConfig() {sensorParametersFlowPane.getChildren().add(layoutTest);}

	
	@SuppressWarnings("resource")
	public String getFileContent(String filePath) throws FileNotFoundException, IOException {
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		StringBuilder sb = new StringBuilder();
		String line = br.readLine();
		while (line != null) {
			sb.append(line);
			sb.append(System.lineSeparator());
			line = br.readLine();
		}
		return sb.toString();

	}
	
//	public void setAddActivity(){System.out.println("Activity Appended");}

	public void setCreateSubtask()
	{
		if (ca_subtask.isSelected())
		{
			ca_actionInst_ChoiceBox.setDisable(false);
			ca_createActionPanel.getChildren().remove(ca_actionID_TextField);
			ca_createActionPanel.getChildren().add(ca_parentActionList);
			ca_agentID_ChoiceBox.setDisable(true);
			ca_parentActionList.setLayoutX(97);
			ca_parentActionList.setLayoutY(37);
			ca_parentActionList.setPrefHeight(25);
			ca_parentActionList.setPrefWidth(148);
			
			createSubtask = true;
			ca_actionID_TextField.setDisable(true);
			ca_actionStartData_DatePicker.setDisable(true);
			ca_actionStartTime_TextField.setDisable(true);
			ca_addButton_Button.setText("Add Sub-Action");
			populateParentActionChoiceBox();
		}
		else
		{
			createSubtask = false;
			ca_actionInst_ChoiceBox.setDisable(true);
			ca_actionID_TextField.setDisable(false);
			ca_actionStartData_DatePicker.setDisable(false);
			ca_actionStartTime_TextField.setDisable(false);
			ca_addButton_Button.setText("Add Action");
			
			ca_createActionPanel.getChildren().remove(ca_parentActionList);
			ca_createActionPanel.getChildren().add(ca_actionID_TextField);
			ca_agentID_ChoiceBox.setDisable(false);
			ca_actionID_TextField.setLayoutX(97);
			ca_actionID_TextField.setLayoutY(37);
			ca_actionID_TextField.setPrefHeight(25);
			ca_actionID_TextField.setPrefWidth(148);
		}
	}
	
	
	public void wc_drawHorizontalCalibrationLine() {
		if (wc_horizontalCalibration_ToggleButton.isSelected()) {
			wc_drawHorizontalCalibrationLine = true;

			if (horizontalCalibrationLine != null)
				horizontalCalibrationLine.removeItself();
			horizontalCalibrationLine = new InteractableLine(pane, wc_horizontal_p1_xCoord_TextField,
					wc_horizontal_p1_yCoord_TextField, wc_horizontal_p2_xCoord_TextField,
					wc_horizontal_p2_yCoord_TextField, wc_horizontal_distance_TextField, wc_saveHorizontal_Button,
					wc_hideHorizontal_Button, wc_horizontalCalibrationLine_Label, this, false);
		} else
			wc_drawHorizontalCalibrationLine = false;
	}

	
	public void wc_drawVerticalCalibrationLine() {
		if (wc_verticalCalibration_ToggleButton.isSelected()) {
			wc_drawVerticalCalibrationLine = true;

			if (verticalCalibrationLine != null)
				verticalCalibrationLine.removeItself();
			verticalCalibrationLine = new InteractableLine(pane, wc_vertical_p1_xCoord_TextField,
					wc_vertical_p1_yCoord_TextField, wc_vertical_p2_xCoord_TextField, wc_vertical_p2_yCoord_TextField,
					wc_vertical_distance_TextField, wc_saveVertical_Button, wc_hideVertical_Button,
					wc_verticalCalibrationLine_Label, this, false);
		} else
			wc_drawVerticalCalibrationLine = false;
	}

	
	public void wc_drawRoomShapeButtonAction() {
		if (wc_drawRoom_ToggleButton.isSelected()) {
			wc_drawRoom = true;

			if (wc_room != null)
				wc_room.removeItself();
			wc_room = new RoomMain(wc_roomID_TextField, pane, wc_currentPointX_coord_TextField,
					wc_currentPointY_coord_TextField, wc_saveRoomID_Button, wc_resetIdLabel, wc_anchorsMainRoom,
					wc_saveCurrentPointCoord_Button, wc_savePointCoordinatesLabel, this);

			java.util.Date date = new java.util.Date();
			wc_room.setRoomID((new Timestamp(date.getTime())).toString() + "");
		} else {
			wc_drawRoom = false;
		}
	}

	public void drawRoomShapeButtonAction() {
		if (drawRoomShapeButton.isSelected()) {
			drawPolygon = true;
			currentRoom = new Room(this);

			java.util.Date date = new java.util.Date();
			currentRoom.setRoomID((new Timestamp(date.getTime())).toString() + "");
		} else {
			drawPolygon = false;
			rooms.addRoom(currentRoom);
			currentRoom = null;
		}
	}

	
	public void drawObstacleShapeButtonAction() {
		if (drawObstacleShapeButton.isSelected()) {
			drawObstaclePolygon = true;

			currentObstacle = new Obstacle(this);

			java.util.Date date = new java.util.Date();
			currentObstacle.setObstacleID((new Timestamp(date.getTime())).toString() + "");
		} else {
			drawObstaclePolygon = false;
			obstacles.addObstacle(currentObstacle);
			currentObstacle = null;
		}
	}

	
	/**
	 * loads the background image
	 */
	public void loadImage() {
		fileChooser = new FileChooser();
		File file = fileChooser.showOpenDialog(pane.getScene().getWindow());
		URL url;

		try {
			url = file.toURI().toURL();

			if (file != null) {
				floorPlanImageView.setImage(new Image(url.toExternalForm()));
				floorPlanImageView.setFitWidth(DRAW_AREA_WIDTH);
				floorPlanImageView.setFitHeight(DRAW_AREA_HEIGHT);
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * This event is triggered when a sensor is dragged
	 * 
	 * @param event
	 */
	public void sensorDrag(Event event) {
		ImageView currentImage = (ImageView) event.getSource();
		draggedObjectType = event.getSource().toString().split("id=")[1].split(",")[0].trim();

		Dragboard db = currentImage.startDragAndDrop(TransferMode.ANY);
		clipboardContent = new ClipboardContent();
		clipboardContent.putImage(currentImage.getImage());
		db.setContent(clipboardContent);

		currentClippboeardContent = event.getSource().toString().split("id=")[1].split(",")[0].trim();
		
		if (draggedObjectType.equals("simpleDoorImageViewOld")) {pane.getChildren().remove(currentImage);}
		else pane.getChildren().remove(currentImage);
			
		event.consume();
	}

	/**
	 * This event is triggered when the image is dragged over the pane
	 * 
	 * @param event
	 */
	public void sensorDraggedOver(DragEvent event) {
		event.acceptTransferModes(TransferMode.ANY);
		event.consume();
	}

	/**
	 * This event is triggered when a sensor image is dropped over the pane
	 * 
	 * @param event
	 */
	public void sensorDropped(DragEvent event) {
		Dragboard db = event.getDragboard();
		if (db.hasImage()) {
			current_x = event.getX();
			current_y = event.getY();

			Image dbimage = db.getImage();
			ImageView dbImageView = new ImageView();
			dbImageView.setImage(dbimage);
			dbImageView.setId(currentClippboeardContent);

			
			if (draggedObjectType.equals("simpleDoorImageView")) configDoor(dbImageView, true);
			else if (draggedObjectType.equals("simpleDoorImageViewOld")) {
				pane.getChildren().add(dbImageView);
				configDoor(dbImageView, false);
			}
			else if (draggedObjectType.equals("agent_icon")){
				pane.getChildren().add(dbImageView);
				addAgentButtonAction();
			}
			else if (draggedObjectType.equals("agent_iconOld")){	
				pane.getChildren().add(dbImageView);
				Agent agent_temp = agents.getCurrentActiveAgent();
				
				dbImageView.setFitHeight(30);
				dbImageView.setFitWidth(30);
				dbImageView.setLayoutX(current_x - (dbImageView.getFitWidth() / 2));
				dbImageView.setLayoutY(current_y - (dbImageView.getFitWidth() / 2));
				agent_temp.setImageView(dbImageView);
				
				agent_temp.setListeners();				
				agent_temp.updateAgentCoordinates();
				agents.setCurrentActiveAgent(null);
			}
			else if (draggedObjectType.equals("place_iconOld")){			
				pane.getChildren().add(dbImageView);
				Place currentPlace = places.getCurrentActivePlace();
	
				dbImageView.setFitHeight(30);
				dbImageView.setFitWidth(30);
				dbImageView.setLayoutX(current_x - (dbImageView.getFitHeight() / 2));
				dbImageView.setLayoutY(current_y - (dbImageView.getFitWidth() / 2));
				currentPlace.setImageView(dbImageView);
				
				currentPlace.setListeners();				
				currentPlace.updatePlaceCoordinates();
				places.setCurrentActivePlace(null);
			}
			else if ((draggedObjectType.length() > 2) && (draggedObjectType.substring(draggedObjectType.length() - 3, draggedObjectType.length()).equals("Old"))){
				
				pane.getChildren().add(dbImageView);
				configSensor(dbImageView, false);
			}
			else if (draggedObjectType.equals("placeImageView")){
				p_placeID_TextField.setText("Place:" + places.getPlaces().size());
				dbImageView.setFitHeight(30);
				dbImageView.setFitWidth(30);
				
				p_XCoord_TextField.setText((current_x - (dbImageView.getFitHeight() / 2)) + "");
				p_YCoord_TextField.setText((current_y - (dbImageView.getFitWidth() / 2)) + "");

				Place newPlace = new Place(this);

				places.addPlace(newPlace);
				p_placeID_TextField.setText("");
				p_XCoord_TextField.setText("");
				p_YCoord_TextField.setText("");
			}
			else if (draggedObjectType.equals("agentImageView")){
				a_agentName_TextField.setText("Default Name");
				a_agentRole_TextField.setText("Default Role");
				a_XCoord_TextField.setText((current_x - (dbImageView.getFitHeight() / 2)) + "");
				a_YCoord_TextField.setText((current_y - (dbImageView.getFitWidth() / 2)) + "");
				a_agentID_TextField.setText("agent[" + a_XCoord_TextField.getText() + ", " + a_YCoord_TextField.getText() + "]");
				Agent newAngent = new Agent(this);
				agents.addAgent(newAngent);
				a_agentID_TextField.setText("");
				a_agentName_TextField.setText("");
				a_agentRole_TextField.setText("");
				a_XCoord_TextField.setText("");
				a_YCoord_TextField.setText("");
			}
			else{
				pane.getChildren().add(dbImageView);
				configSensor(dbImageView, true);
			}
		}
		event.consume();
	}


	public void configDoor(ImageView dbImageView, boolean isNew) {
		
		dbImageView.setFitHeight(10);
		dbImageView.setFitWidth(10);

		Room curentActiveRoom = rooms.getCurrentActiveRoom();
		GeometryFunctions geom = new GeometryFunctions();

		@SuppressWarnings("static-access")
		Point p = geom.getClosestPoint(curentActiveRoom.getRoomShape(), new Point((int) current_x, (int) current_y));

		if (isNew) {
			Door newDoor = new Door(p, dbImageView, curentActiveRoom, this);

			curentActiveRoom.addDoor(newDoor);

			java.util.Date date = new java.util.Date();
			newDoor.setDoorID((new Timestamp(date.getTime())).toString() + "");
			doors.getCurrentActiveDoor().setListeners(dbImageView);

		} else {
			// reset listeners
			doors.getCurrentActiveDoor().setListeners(dbImageView);
		}
		dbImageView.setLayoutX(p.x);
		dbImageView.setLayoutY(p.y);
		doors.setCurrentActiveDoor(-1);

		doorPanelOver_Off(dbImageView);

		dbImageView.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				doorPanelOver_On(dbImageView);
			}
		});
		dbImageView.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				doorPanelOver_Off(dbImageView);
			}
		});

		dbImageView.setCursor(Cursor.CLOSED_HAND);

		currentDoor_Xcoord_textField.setText(dbImageView.getLayoutX() + "");
		currentDoor_Ycoord_textField.setText(dbImageView.getLayoutY() + "");

	}


	public void configSensor(ImageView dbImageView, boolean isNew) {
		sensorsImageViews.add(dbImageView);

		dbImageView.setFitHeight(30);
		dbImageView.setFitWidth(30);
		
		dbImageView.setLayoutX(current_x - (dbImageView.getFitHeight() / 2));
		dbImageView.setLayoutY(current_y - (dbImageView.getFitWidth() / 2));

		Sensor sensor_temp = sensors.getCurrentActiveSensor();
		
		if (isNew) {
			createFlowPane(dbImageView.getId(), dbImageView);
		} else {
			String origName = draggedObjectType.substring(0, draggedObjectType.length() - 3);
			
			if (Arrays.toString(directories).contains(origName)) {
				File file = new File("@../../Sensors/" + origName + "/Image/image.png");
				URL url;
				try {
					url = file.toURI().toURL();
					dbImageView.setImage(new Image(url.toExternalForm()));
				} catch (MalformedURLException e) {
					e.printStackTrace();
				}
			}
			
			sensor_temp.setImageView(dbImageView);
			sensor_temp.setImageViewListeners();
			sensor_temp.populateSensoerTextFields();
			sensorParametersFlowPane.getChildren().remove(0);
			sensorParametersFlowPane.getChildren().add(sensor_temp.getFlowPane());
			sensor_temp.setImageViewListeners();
		}
		
		sensorSetHoverOverListeners(dbImageView);
	}

	public void mousePressed(MouseEvent mouseEvent) {

		if (drawPolygon || wc_drawRoom || wc_drawHorizontalCalibrationLine || wc_drawVerticalCalibrationLine
				|| drawObstaclePolygon || drawDistanceLine) {
			current_x = mouseEvent.getX();
			current_y = mouseEvent.getY();
			if (zoomController != null){
				double factor = zoomController.zoom.doubleValue();

				//current_x = ((current_x + current_x * scrollPane.getHvalue())) / factor;
				//current_y = ((current_y + current_y * scrollPane.getVvalue())) / factor;
				
				current_x = (current_x + pane.getWidth() * scrollPane.getHvalue() * factor) / factor;
				current_y = (current_y + pane.getHeight() * scrollPane.getVvalue() * factor) / factor;
				
				/*
				System.out.println("ROOM POINT CLICKED");
				System.out.println("P" + pane.getWidth());
				System.out.println("P" + pane.getHeight());
				System.out.println(mouseEvent.getX());
				System.out.println(mouseEvent.getY());
				System.out.println("Hvalue: " + scrollPane.getHvalue());
				System.out.println("Vvalue: " + scrollPane.getVvalue());
				System.out.println("Zoom Value: " + zoomController.zoom.doubleValue());
				System.out.println(current_x);
				System.out.println(current_y);
				*/
			}
		} 
	}

	
	public void mouseRelesed(MouseEvent mouseEvent) {
		if (drawPolygon) {
			currentRoom.addValue(current_x);
			currentRoom.addValue(current_y);
			
			pane.getChildren().remove(currentRoom.getRoomShape());
			pane.getChildren().add(currentRoom.getRoomShape());
			pane.getChildren().add(currentRoom.addAnchorCircle());
		} else if (wc_drawRoom) {
			wc_room.addValue(current_x);
			wc_room.addValue(current_y);

			pane.getChildren().remove(wc_room.getRoomShape());
			pane.getChildren().add(wc_room.getRoomShape());
			pane.getChildren().add(wc_room.addAnchorCircle());

		} else if (wc_drawHorizontalCalibrationLine
				&& horizontalCalibrationLine.getRoomShape().getPoints().size() < 4) {
			horizontalCalibrationLine.addValue(current_x);
			horizontalCalibrationLine.addValue(current_y);

			pane.getChildren().remove(horizontalCalibrationLine.getRoomShape());
			pane.getChildren().add(horizontalCalibrationLine.getRoomShape());
			pane.getChildren().add(horizontalCalibrationLine.addAnchorCircle());
		} else if (wc_drawVerticalCalibrationLine && verticalCalibrationLine.getRoomShape().getPoints().size() < 4) {
			verticalCalibrationLine.addValue(current_x);
			verticalCalibrationLine.addValue(current_y);

			pane.getChildren().remove(verticalCalibrationLine.getRoomShape());
			pane.getChildren().add(verticalCalibrationLine.getRoomShape());
			pane.getChildren().add(verticalCalibrationLine.addAnchorCircle());
		} else if (drawObstaclePolygon) {
			currentObstacle.addValue(current_x);
			currentObstacle.addValue(current_y);

			pane.getChildren().remove(currentObstacle.getObstacleShape());
			pane.getChildren().add(currentObstacle.getObstacleShape());
			pane.getChildren().add(currentObstacle.addAnchorCircle());
		} else if (drawDistanceLine
				&& distanceMeasuremetLine.getRoomShape().getPoints().size() < 4) {
			distanceMeasuremetLine.addValue(current_x);
			distanceMeasuremetLine.addValue(current_y);

			pane.getChildren().remove(distanceMeasuremetLine.getRoomShape());
			pane.getChildren().add(distanceMeasuremetLine.getRoomShape());
			pane.getChildren().add(distanceMeasuremetLine.addAnchorCircle());
		}
	}

	public void a_hideShowAgents() {
		if (a_areAgentsHidden) { 
			a_areAgentsHidden = false;agents.show();
			a_showHideAgents_Button.setText("Hide Agents");
		}
		else {
			a_showHideAgents_Button.setText("Show Agents");
			a_areAgentsHidden = true; agents.hide();
		}
	}

	public void p_hideShowPlace() {
		if (p_arePlaceHidden) {
			p_arePlaceHidden = false; places.show();
			p_showHidePlaces_Button.setText("Hide Places");
		} 
		else {
			p_arePlaceHidden = true; places.hide();
			p_showHidePlaces_Button.setText("Show Places");
		}
	}

	public void wc_hideShowMainRoom() {
		if (wc_isMainRoomHidden) {
			if (wc_room != null)
				this.wc_room.show();
			wc_isMainRoomHidden = false;
			wc_hideRoomShape_Button.setText("Hide Room");
		} else {
			if (wc_room != null)
				;
			this.wc_room.hide();
			wc_isMainRoomHidden = true;
			wc_hideRoomShape_Button.setText("Show Room");
		}
	}

	public void hideShowMainRooms() {
		if (areRoomsHidden) {
			if (rooms != null) {
				this.rooms.showAllRooms();
				this.doors.showAllDoors();
			}
			areRoomsHidden = false;
			hideRoomShape_Button.setText("Hide Rooms");
		} else {
			if (rooms != null) {
				rooms.hideAllRooms();
				doors.hideAllDoors();
			}
			areRoomsHidden = true;
			hideRoomShape_Button.setText("Show Rooms");
		}
	}

	public void hideShowMainObstacles() {
		if (areObstaclesHidden) {
			if (obstacles != null) {
				this.obstacles.showAllObstacles();
				hideObstacleShape_Button.setText("Hide Obstacles");
			}
			areObstaclesHidden = false;
		} else {
			if (obstacles != null) {
				obstacles.hideAllObstacles();
				hideObstacleShape_Button.setText("Show Obstacles");
			}
			areObstaclesHidden = true;
		}
	}

	public void hideShowHorizontalCalibrationLine() {
		if (wc_isHorizontalCalibrationLineHidden) {
			if (horizontalCalibrationLine != null)
				this.horizontalCalibrationLine.show();
			wc_isHorizontalCalibrationLineHidden = false;
			wc_hideHorizontal_Button.setText("Hide");
		} else {
			if (horizontalCalibrationLine != null)
				;
			horizontalCalibrationLine.hide();
			wc_isHorizontalCalibrationLineHidden = true;
			wc_hideHorizontal_Button.setText("Show");
		}
	}
	
	public void hideShowDistanceLine() {
		if (drawDistanceLine) {
			if (distanceMeasuremetLine != null)
				this.distanceMeasuremetLine.show();
			drawDistanceLine = false;
			showHide_distLine_ToggleButton.setText("Hide");
		} else {
			if (distanceMeasuremetLine != null)
			distanceMeasuremetLine.hide();
			drawDistanceLine = true;
			showHide_distLine_ToggleButton.setText("Show");
		}
	}

	public void hideShowVerticalCalibrationLine() {
		if (wc_isVerticalCalibrationLineHidden) {
			if (verticalCalibrationLine != null)
				this.verticalCalibrationLine.show();
			wc_isVerticalCalibrationLineHidden = false;
			wc_hideVertical_Button.setText("Hide");
		} else {
			if (verticalCalibrationLine != null)
				;
			verticalCalibrationLine.hide();
			wc_isVerticalCalibrationLineHidden = true;
			wc_hideVertical_Button.setText("Show");
		}
	}
	
	public void setMessage(boolean isSuccess, String message, Label messageLabel) {
		messageLabel.setText(message);
		if (isSuccess) {messageLabel.setTextFill(SUCCESS_COLOR);}
		else {messageLabel.setTextFill(FAIL_COLOR);}
		
		if (!areLabelsPopulated) {
			addLabelsToAllLabels();
			areLabelsPopulated = true;
		}
		
		// deselect the rest of the messages
		for (int i = 0; i < allLabels.size(); ++i){
			if (!allLabels.get(i).equals(messageLabel))allLabels.get(i).setText("");
		}
			
		
		
		Sensor currentActiveSensor = sensors.getCurrentActiveSensor();
		if (currentActiveSensor != null){
			Label currentActiveSensorLabel = sensors.getCurrentActiveSensor().getLabel();
			if((currentActiveSensorLabel != null) && (!currentActiveSensorLabel.equals(messageLabel))){
				currentActiveSensorLabel.setText("");
			}
		}
	}
	
	public void increaseAnchorSize(){
		if (anchorSize < 30) anchorSize += 2;	
		for (int i = 0; i < allRoomAnchors.size(); ++i) allRoomAnchors.get(i).setRadius(anchorSize);
		for (int i = 0; i < allObstacleAnchors.size(); ++i) allObstacleAnchors.get(i).setRadius(anchorSize);
	}
	
	public void decreaseAnchorSize(){
		if (anchorSize > 4) anchorSize -= 2;
		for (int i = 0; i < allRoomAnchors.size(); ++i) allRoomAnchors.get(i).setRadius(anchorSize);
		for (int i = 0; i < allObstacleAnchors.size(); ++i) allObstacleAnchors.get(i).setRadius(anchorSize);
	}
	
	public void addLabelsToAllLabels(){
		allLabels.add(resetIdLabel);						// 0
		allLabels.add(doorPanelMessageLabel);				// 1
		allLabels.add(resetObstacleIdLabel);				// 2
		allLabels.add(wc_horizontalCalibrationLine_Label);	// 6
		allLabels.add(a_addAgent_Label);					// 8
		allLabels.add(a_modifyAgent_Label);					// 9
		allLabels.add(p_addPlace_Label);					// 10
		allLabels.add(p_modifyPlace_Label);					// 11
		allLabels.add(ca_addAction_Label);					// 12
		allLabels.add(ma_addAction_Label);					// 13
		allLabels.add(sim_update_startDate_Label);			// 14
		allLabels.add(outputMessage_actDef_Label);			// 15
		allLabels.add(outputMessage_compAct_Label);			// 16
		allLabels.add(outputMessage_modAct_Label);			// 17
		allLabels.add(output_instAct_def_Label);			// 18
		allLabels.add(output_instAct_mod_Label);			// 19
		allLabels.add(distanceLinePoints_Label);			// 20
		allLabels.add(distanceLineMeter_Label);			// 21
	}
	
	
	public void sensorSetHoverOverListeners(ImageView dbImageView){
		dbImageView.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				String sensorType = dbImageView.getId();
				if (sensorType.length() >= 3 && sensorType.substring(sensorType.length() - 3, sensorType.length()).equals("Old"))
						sensorType = sensorType.substring(0, sensorType.length() - 3);
				sensorPanelOver_On(dbImageView, sensorType);
			}
		});

		dbImageView.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				String sensorType = dbImageView.getId();
				if (sensorType.length() >= 3 && sensorType.substring(sensorType.length() - 3, sensorType.length()).equals("Old"))
						sensorType = sensorType.substring(0, sensorType.length() - 3);
				sensorPanelOver_Off(dbImageView, sensorType);
			}
		});

		dbImageView.setCursor(Cursor.CLOSED_HAND);
		sensorPanelOver_Off(dbImageView, dbImageView.getId());
	}
	
	
	public void createActivityDef(){
		ActivityDefinition newActivity = new ActivityDefinition(this);
		if (newActivity.isValidActivity()) activities.addActivity(newActivity);
		
		defTabExpanded();
	}
	
	public void addActivityCompAct(){
		String compActToExtend_str = activityName_compAct_ChoiceBox.getSelectionModel().getSelectedItem().toString();
		ActivityDefinition compActToExtend = null;
		if ((compActToExtend_str != null) && (!compActToExtend_str.equals(""))) 
			compActToExtend = activities.getActivityByID(compActToExtend_str);
		else{
			setMessage(false, "Parent Activity Missing", outputMessage_compAct_Label);
			return;
		}
		
		String compActToChild_str = activityToAddName_compAct_ChoiceBox.getSelectionModel().getSelectedItem().toString();
		ActivityDefinition compActToChild = null;
		
		if ((compActToChild_str != null) && (!compActToChild_str.equals(""))) 
			compActToChild = activities.getActivityByID(compActToChild_str);
		else{
			setMessage(false, "Child Activity Missing", outputMessage_compAct_Label);
			return;
		}

		if (compActToExtend_str.equals(compActToChild_str)){
			setMessage(false, "Can't add itself as subactivity", outputMessage_compAct_Label);
			return;
		}
		
		compActToExtend.addSubActivity(compActToChild.getActivityId());
		
		activityName_compAct_ChoiceBox.getSelectionModel().clearSelection();
		activityToAddName_compAct_ChoiceBox.getSelectionModel().clearSelection();

		setMessage(true, "Subactivity Added", outputMessage_compAct_Label);
		defTabExpanded();
	}
	

	public void deleteActDefModification(){
		String compActToParent_str = activityName_modAct_ChoiceBox.getSelectionModel().getSelectedItem().toString();
		ActivityDefinition compActToParent = null;
		if ((compActToParent_str != null) && (!compActToParent_str.equals(""))) 
			compActToParent = activities.getActivityByID(compActToParent_str);
		else{
			setMessage(false, "Parent Activity Missing", outputMessage_modAct_Label);
			return;
		}
				
		String compActToChild_str = subActivityName_modAct_ChoiceBox.getSelectionModel().getSelectedItem().toString();
		
		if ((compActToChild_str != null) && (!compActToChild_str.equals(""))) 
		{
			if (compActToChild_str.equals(compActToParent.getActivityId()))
				activities.removeActivity(compActToParent);
			else compActToParent.removeSubactivityByiD(compActToChild_str);
		}
		else{
			setMessage(false, "Child Activity Missing", outputMessage_compAct_Label);
			return;
		}
		
		activityName_modAct_ChoiceBox.getSelectionModel().clearSelection();
		subActivityName_modAct_ChoiceBox.getSelectionModel().clearSelection();
				
		defTabExpanded();
	}
	
	@SuppressWarnings("unchecked")
	public void defTabExpanded(){
		ArrayList<String> added_activity_ids = new ArrayList<String>();
		for (int i = 0; i < activities.getActivities().size(); ++i){
			added_activity_ids.add(activities.getActivities().get(i).getActivityId());
		}
		
		ArrayList<String> src_activity_ids = new ArrayList<String>();
		src_activity_ids.addAll(core_activity_ids);
		src_activity_ids.addAll(added_activity_ids);
		activityType_actDef_ChoiceBox.setItems(FXCollections.observableArrayList(src_activity_ids));
		
		populateArraysForActionChackBoxes();
		
		ArrayList<String> complexActivitiesIds = new ArrayList<String>();
		ArrayList<ActivityDefinition> complexActivities = activities.getComplexActivities();
		
		for(int i = 0; i < complexActivities.size(); ++i)
			complexActivitiesIds.add(complexActivities.get(i).getActivityId());
		
		activityName_compAct_ChoiceBox.setItems(FXCollections.observableArrayList(complexActivitiesIds));
		activityToAddName_compAct_ChoiceBox.setItems(FXCollections.observableArrayList(added_activity_ids));
		activityName_modAct_ChoiceBox.setItems(FXCollections.observableArrayList(added_activity_ids));
		
		activityName_modAct_ChoiceBox.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
			public void changed(ObservableValue ov, Number value, Number new_value) {
				ArrayList<String> added_activity_ids = new ArrayList<String>();
				for (int i = 0; i < activities.getActivities().size(); ++i)
					added_activity_ids.add(activities.getActivities().get(i).getActivityId());
				
				subActivityName_modAct_ChoiceBox.setItems(FXCollections.observableArrayList(added_activity_ids));
				int new_value_int = new_value.intValue();
				if (new_value_int >= 0) {
					String selectedActivityID = added_activity_ids.get(new_value_int);
					ActivityDefinition selectedActivity = activities.getActivityByID(selectedActivityID);
					activities.setCurrentActiveActivity(selectedActivity);
					ArrayList<String> subActivities_ids = selectedActivity.getSubActivitiesIds();
					subActivityName_modAct_ChoiceBox.setItems(FXCollections.observableArrayList(subActivities_ids));
					subActivityName_modAct_ChoiceBox.getSelectionModel().select(0);
				}
			}
		});
	}
	
	
	
	
	
	@SuppressWarnings("unchecked")
	/*Activity Instance Tab Extended or Refresh action
	 * !!!!!!!!!!LEAVE TO THE END
	 * */
	public void instTabExpanded(){
		
		ArrayList<String> added_activity_ids = new ArrayList<String>();
		for (int i = 0; i < activities.getActivities().size(); ++i)
			added_activity_ids.add(activities.getActivities().get(i).getActivityId());
		
		actvityName_def_ChoiceBox.setItems(FXCollections.observableArrayList(added_activity_ids));
		actvityName_def_ChoiceBox.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
			public void changed(ObservableValue ov, Number value, Number new_value) {
				ArrayList<String> added_activity_ids = new ArrayList<String>();
				for (int i = 0; i < activities.getActivities().size(); ++i){
					added_activity_ids.add(activities.getActivities().get(i).getActivityId());
				}
				subActivityName_modAct_ChoiceBox.setItems(FXCollections.observableArrayList(added_activity_ids));
				int new_value_int = new_value.intValue();
				if (new_value_int >= 0) {
					
					populateArraysForActionChackBoxes();

					ArrayList<String> target_ids = new ArrayList<String>();
					for (int i = 0; i < places.getPlaces().size(); ++i)
						target_ids.add(places.getPlaces().get(i).getPlaceId());
					for (int i = 0; i < rooms.getRooms().size(); ++i)
						target_ids.add(rooms.getRooms().get(i).getRoomId());
					for (int i = 0; i < sensors.getSensors().size(); ++i)
						target_ids.add(sensors.getSensors().get(i).getSensorId());
					
					
					String selectedActivityID = added_activity_ids.get(new_value_int);
					ActivityDefinition selectedActivity = activities.getActivityByID(selectedActivityID);
					activities.setCurrentActiveActivity(selectedActivity);
					ArrayList<String> subActivities_ids = selectedActivity.getSubActivitiesIds();
					
					subactivity_def_FlowPane.getChildren().clear();
					
					for(int i = 0; i < subActivities_ids.size(); ++i){
						Label l = new Label();
						l.setPrefWidth(235);
						l.setText(subActivities_ids.get(i));
						subactivity_def_FlowPane.getChildren().add(l);
						ChoiceBox c = new ChoiceBox();
						c.setPrefWidth(235);
						c.setItems(FXCollections.observableArrayList(target_ids));
						subactivity_def_FlowPane.getChildren().add(c);
						TextField t = new TextField();
						t.setPrefWidth(235);
						//t.setText(value);
						subactivity_def_FlowPane.getChildren().add(t);
					}
				}
			}
		});
		
		
		ArrayList<String> activityInstances_str = new ArrayList<String>(); 
		for(int i = 0; i < activityInstances.getactivityInstancies().size(); ++i){
			activityInstances_str.add(activityInstances.getactivityInstancies().get(i).getActivityInstanceId());
			
		}
		
		
		actvityInstanceId_mod_ChoiceBox.setItems(FXCollections.observableArrayList(activityInstances_str));
		actvityInstanceId_mod_ChoiceBox.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
			public void changed(ObservableValue ov, Number value, Number new_value) {
				int new_value_int = new_value.intValue();
				if (new_value_int >= 0) {
					ActivityInstance act_ints = activityInstances.getactivityInstancies().get(new_value_int);	
					ArrayList<String> actDef_arr = act_ints.getActivityDefinitions();
					ArrayList<String> actDef_str = new ArrayList<String>();
					for (int  i = 0; i < actDef_arr.size(); ++i){
						String actDef_current = actDef_arr.get(i);
						
						if (actDef_current != null) {
							actDef_str.add(actDef_current);
						}
						else{
							actDef_str.add(act_ints.getActivityInstanceId());
							
						}
					}	
					actvityType_mod_ChoiceBox.setItems(FXCollections.observableArrayList(actDef_str));
					populateArraysForActionChackBoxes();

					ArrayList<String> target_ids = new ArrayList<String>();
					for (int i = 0; i < places.getPlaces().size(); ++i)
						target_ids.add(places.getPlaces().get(i).getPlaceId());
					for (int i = 0; i < rooms.getRooms().size(); ++i)
						target_ids.add(rooms.getRooms().get(i).getRoomId());
					for (int i = 0; i < sensors.getSensors().size(); ++i)
						target_ids.add(sensors.getSensors().get(i).getSensorId());
					
					actvityTarget_mod_ChoiceBox.setItems(FXCollections.observableArrayList(target_ids));
					
					
					actvityType_mod_ChoiceBox.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
						public void changed(ObservableValue ov, Number value, Number new_value) {
							try{
								int new_value_int = new_value.intValue();
								if (new_value_int >= 0) {
									String toSelect = act_ints.getTargets().get(new_value_int);
									actvityTarget_mod_ChoiceBox.getSelectionModel().select(toSelect);
									actvityTimer_mod_TextField.setText(act_ints.getActionParameter().get(new_value_int));
								}
							}catch(Exception e){}
						}
					});
	
					String selectedActivityID = added_activity_ids.get(new_value_int);
					ActivityDefinition selectedActivity = activities.getActivityByID(selectedActivityID);
					activities.setCurrentActiveActivity(selectedActivity);
					ArrayList<String> subActivities_ids = selectedActivity.getSubActivitiesIds();
					
					subactivity_def_FlowPane.getChildren().clear();
					
					for(int i = 0; i < subActivities_ids.size(); ++i){
						Label l = new Label();
						l.setPrefWidth(235);
						l.setText(subActivities_ids.get(i));
						subactivity_def_FlowPane.getChildren().add(l);
						ChoiceBox c = new ChoiceBox();
						c.setPrefWidth(235);
						c.setItems(FXCollections.observableArrayList(target_ids));
						subactivity_def_FlowPane.getChildren().add(c);
					}
				}
			}
		});
		
		// clean up fields
		/*
		actvityInstanceId_def_TextField.setText("");
		actvityName_def_ChoiceBox.getSelectionModel().clearSelection();
		subactivity_def_FlowPane.getChildren().clear();
		actvityInstanceId_mod_ChoiceBox.getSelectionModel().clearSelection();
		actvityType_mod_ChoiceBox.getSelectionModel().clearSelection();
		actvityTarget_mod_ChoiceBox.getSelectionModel().clearSelection();
		*/
		
	}
	
	/*NOT IN USE*/
	public void actvityName_def_Change(){System.out.println("actvityName_def_Change");}
	
	
	
	/*
	 * ON CREATE ACTIVITY INSTANCE
	 * MODIFIED TO INCLUDE EXTRA TEXT FIELD??
	 */
	public void create_def_actInstance(){
		ObservableList<Node> elements = subactivity_def_FlowPane.getChildren();
		
		ArrayList<Label> labels = new ArrayList<Label>();
		ArrayList<ChoiceBox> choiceBoxes = new ArrayList<ChoiceBox>();
		ArrayList<TextField> textFields = new ArrayList<TextField>();
		
		
		// gets the content stored in UI
		for(int i = 0; i < elements.size(); ++i){
			if (i % 3 == 0) labels.add((Label)elements.get(i));
			else if (i % 3 == 1) choiceBoxes.add((ChoiceBox) elements.get(i));
			else textFields.add((TextField) elements.get(i));
		}
		
		
		// Validate the contect of choice boxes. If empty/notSelected found, then error
		boolean emptyValueFound = false;
		for (int i = 0; ((i < choiceBoxes.size()) && (!emptyValueFound)); ++i){
			if (choiceBoxes.get(i).getSelectionModel().isEmpty()){
				emptyValueFound = true;
				setMessage(false, "Target Location Not Selected", output_instAct_def_Label);
				return;
			}
		}
		
		// check for id is populated and uniques
		String actInstanceId = actvityInstanceId_def_TextField.getText().trim();
		if (actInstanceId.equals("") || actInstanceId == null){
			setMessage(false, "Account Instance Id missing", output_instAct_def_Label);
			return;
		}
		
		
		if (activityInstances.isIdInList(actInstanceId)){
			setMessage(false, "Id not unique", output_instAct_def_Label);
			return;
		}
		
		//ArrayList<ActivityDefinition> actDefs = new ArrayList<ActivityDefinition>();
		ArrayList<String> actDefs = new ArrayList<String>();
		ArrayList<String> actTargs = new ArrayList<String>();
		ArrayList<String> actTimers = new ArrayList<String>();
		
		for (int i = 0; i < labels.size(); ++i){
			actDefs.add(labels.get(i).getText());
			actTargs.add(choiceBoxes.get(i).getSelectionModel().getSelectedItem().toString());
			
			try{
				String timerTemp = textFields.get(i).getText();
				actTimers.add(timerTemp);
			}
			catch(Exception e){
				actTimers.add("");
			}
			
			
		}
		
		// create activity instance object
		ActivityInstance actInst = new ActivityInstance(this, actDefs, actTargs, actTimers, actInstanceId);
		activityInstances.addActivityInstance(actInst);
		
		setMessage(true, "Account instance created", output_instAct_def_Label);
		
		actvityInstanceId_def_TextField.clear();
		actvityName_def_ChoiceBox.getSelectionModel().clearSelection();
		subactivity_def_FlowPane.getChildren().clear();
		
		instTabExpanded();
	}
	
	/*Text Field included*/
	@SuppressWarnings("unused")
	public void submitActModAction(){
		String selectedActivityInstance = "";
		
		try{selectedActivityInstance = actvityInstanceId_mod_ChoiceBox.getSelectionModel().getSelectedItem().toString();}
		catch (Exception e){
			setMessage(false, "Activity Not Selected", output_instAct_mod_Label);
			return;
		}

		String selectedSubActivityInstance = "";
		
		try{selectedSubActivityInstance = actvityType_mod_ChoiceBox.getSelectionModel().getSelectedItem().toString();}
		catch (Exception e){
			setMessage(false, "Sub-Activity Not Selected", output_instAct_mod_Label);
			return;
		}
		
		String selecteNewTarget = actvityTarget_mod_ChoiceBox.getSelectionModel().getSelectedItem().toString();
		String modifiedText = actvityTimer_mod_TextField.getText();
		
		ActivityInstance actInst_temp = activityInstances.getActivityInstanceByID(selectedActivityInstance);
		
		int index = actInst_temp.getActivityDefinitionsIndexOf(selectedSubActivityInstance);
		
		actInst_temp.getTargets().set(index, selecteNewTarget);
		actInst_temp.getActionParameter().set(index, modifiedText);
		setMessage(true, "Modification Saved", output_instAct_mod_Label);
		
		instTabExpanded();
		actvityInstanceId_def_TextField.setText("");
		actvityName_def_ChoiceBox.getSelectionModel().clearSelection();
		subactivity_def_FlowPane.getChildren().clear();
		actvityInstanceId_mod_ChoiceBox.getSelectionModel().clearSelection();
		actvityType_mod_ChoiceBox.getSelectionModel().clearSelection();
		actvityTarget_mod_ChoiceBox.getSelectionModel().clearSelection();
	}
	
	public void deleteActModAction(){
		String selectedActivityInstance = "";
		try{selectedActivityInstance = actvityInstanceId_mod_ChoiceBox.getSelectionModel().getSelectedItem().toString();}
		catch (Exception e){
			setMessage(false, "Activity Not Selected", output_instAct_mod_Label);
			return;
		}
		
		activityInstances.removeActivityInstance(activityInstances.getActivityInstanceByID(selectedActivityInstance));
		setMessage(true, "Activity Removed", output_instAct_mod_Label);
		instTabExpanded();
	}
	
	public void toggleDrawDistanceLine(){
		if (draw_distLine_ToggleButton.isSelected()) {
			drawDistanceLine = true;

			if (distanceMeasuremetLine != null)
				distanceMeasuremetLine.removeItself();
			distanceMeasuremetLine = new InteractableLine(pane, null,
					null, null,
					null, null, null,
					null, null, this, true);
		} else
			drawDistanceLine = false;
	}
	
	public void toggleShowHideCallibrationLine(){System.out.println("showHide_distLine_ToggleButton: ");}
	
	
	public void wasTabExpanded(){System.out.println("wasTabExpanded");}
}
