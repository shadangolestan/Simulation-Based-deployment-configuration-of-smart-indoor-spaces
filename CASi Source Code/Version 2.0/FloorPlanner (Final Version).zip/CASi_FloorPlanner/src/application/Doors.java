package application;

import java.util.ArrayList;

public class Doors {
	private ArrayList<Door> doors;
	private int currentActiveDoor;
	
	public Doors(){
		this.doors = new ArrayList<Door>();
		this.currentActiveDoor = -1;
	}
	
	public void addDoor(Door Door){doors.add(Door);currentActiveDoor = doors.size() - 1;}
	public void removeDoor(Door Door){doors.remove(Door);}
	public void removeDoorByIndex(int index){doors.remove(index);}
	public ArrayList<Door> getDoors(){return doors;}
	public void setCurrentActiveDoor(int currentActiveDoor){this.currentActiveDoor = currentActiveDoor;}
	public int getCurrentActiveDoorIndex(){return this.currentActiveDoor;}
	public Door getCurrentActiveDoor(){return doors.get(currentActiveDoor);}
	
	public boolean isIdInList(String id){
		for (int i = 0; i < doors.size(); ++i) if (doors.get(i).getDoorID().equals(id)) return true;
		return false;
	}
	
	public void setCurrentActiveDoor(Door door){
		for(int i = 0; i < doors.size(); ++i) 
			if ((doors.get(i).equals(door))) {currentActiveDoor = i; return;}
		
		currentActiveDoor = -1;
	}
	
	public Door getDoorByEdgeID(int edgeID){
		for(int i = 0; i <doors.size(); ++i){
			if (doors.get(i).edgeID == edgeID) return doors.get(i);
		}
		return null;
	}
	
	public void hideAllDoors(){for(int i = 0; i < doors.size(); ++i) doors.get(i).hide();}
	public void showAllDoors(){for(int i = 0; i < doors.size(); ++i) doors.get(i).show();}

}
