package application;


import java.util.ArrayList;



public class Agents {
	private ArrayList<Agent> agents;
	private Agent currentActiveAgent;
	
	
	public Agents(){agents = new ArrayList<Agent>();currentActiveAgent = null;}
	
	public void saveAgentConfiguration() {
		Agent agent_temp = this.getCurrentActiveAgent();
		agent_temp.validateAndRecordAgent(false);
	}
	
	
	public void addAgent(Agent agent){agents.add(agent);}
	public void removeAgent (Agent agent){agents.remove(agent);}
	public void removeAgentByIndex(int index){agents.remove(index);}
	public ArrayList<Agent> getAgents(){return agents;}
	public void setCurrentActiveAgent(Agent currentActiveAgent){this.currentActiveAgent = currentActiveAgent;}
	public Agent getCurrentActiveAgent(){return currentActiveAgent;}
	public void hide(){for (int i = 0; i < this.agents.size(); ++i) agents.get(i).hide();}
	public void show(){for (int i = 0; i < agents.size(); ++i) agents.get(i).show();}
	
	
	public boolean isIdInList(String id){
		for (int i = 0; i < agents.size(); ++i)
		if (agents.get(i).getAgentId().equals(id))
			return true;
		return false;
	}
	
	
	public Agent getAgentById(String agentID)
	{
		Agent agent = null;
		boolean agentFound = false;
		for (int i = 0; ((i < agents.size()) && (!agentFound)); ++i){
			agent = agents.get(i);
			if (agent.getAgentId().equals(agentID)){
				agentFound = true;
				return agent;
			}
		}
		return null;
	}
	
	
	public Agent getAgentByName(String agentName)
	{
		Agent agent = null;
		boolean agentFound = false;
		for (int i = 0; ((i < agents.size()) && (!agentFound)); ++i){
			agent = agents.get(i);
			if (agent.getAgentName().equals(agentName)){
				agentFound = true;
				return agent;
			}
		}
		return null;
	}
}
