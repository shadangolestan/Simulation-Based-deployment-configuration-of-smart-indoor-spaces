package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;

/**
 * 
 * @author Alexandr Petcovici This class starts the application and loads the
 *         GUI
 *
 */
public class Main extends Application {

	Parent root;

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws IOException, ParserConfigurationException, SAXException, TransformerException {


		File fxmlUrl = new File(getClass().getResource("/application/Main.fxml").getPath());
		File xmlFile = fxmlUrl;
		
		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
		Document document = documentBuilder.parse(xmlFile);
		
		Element rootElement = document.getDocumentElement();
		//Node sensorFlowPane = rootElement.getElementsByTagName("FlowPane").item(0);
		
		Node sensorScrollPane = rootElement.getElementsByTagName("ScrollPane").item(1);
		Element scrollPaneElement = (Element)sensorScrollPane;
		Node sensorFlowPane = scrollPaneElement.getElementsByTagName("FlowPane").item(0);
		
		File file = new File("@../../Sensors");
		
		String[] directories = file.list(new FilenameFilter() {
		  @Override
		  public boolean accept(File current, String name) {
		    return new File(current, name).isDirectory();
		  }
		});
		
		for(int i = 0; i < directories.length; ++i){
			Element newSensor = document.createElement("ImageView");	
			newSensor.setAttribute("fitWidth", "30.0");
			newSensor.setAttribute("fx:id", directories[i]);
			newSensor.setAttribute("fitHeight", "30.0");
			
			newSensor.setAttribute("onDragDetected", "#sensorDrag");
			newSensor.setAttribute("onMouseEntered", "#sensorPanelOver_On");
			newSensor.setAttribute("onMouseExited", "#sensorPanelOver_Off");
			newSensor.setAttribute("pickOnBounds", "true");
			newSensor.setAttribute("preserveRatio", "true");
			newSensor.setAttribute("onMouseClicked", "#setSensorDescription");
			
			
			
			Element imageParent = document.createElement("image");
			
			Element imageChild = document.createElement("Image");
			imageChild.setAttribute("url", "@../../Sensors/" + directories[i] + "/Image/image.png");

			Element cursorParent = document.createElement("cursor");
			Element cursorChild = document.createElement("Cursor");
			cursorChild.setAttribute("fx:constant", "CLOSED_HAND");
			
			imageParent.appendChild(imageChild);
			newSensor.appendChild(imageParent);
			
			cursorParent.appendChild(cursorChild);
			newSensor.appendChild(cursorParent);
			
			sensorFlowPane.getChildNodes().item(1).appendChild(newSensor);
		}
		
		

		
		
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		
		
		DOMSource source = new DOMSource(rootElement);
		
		
		StreamResult streamResult = new StreamResult(new File("@../../src/application/Main2.fxml"));
		
		
		
		transformer.transform(source, streamResult);
		
		
		PrintWriter writer = new PrintWriter("@../../src/application/Main3.fxml", "UTF-8");
		writer.println(getFileContentModifie("@../../src/application/Main2.fxml"));
		writer.close();
		
		root = FXMLLoader.load(getClass().getResource("/application/Main3.fxml"));
		
		Scene scene = new Scene(root);

		primaryStage.setTitle("CASi Floor Planner");
		primaryStage.setScene(scene);

		primaryStage.setResizable(false);
		primaryStage.show();
	}

	
	
	@SuppressWarnings("resource")
	public String getFileContent(String filePath) throws FileNotFoundException, IOException{
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		StringBuilder sb = new StringBuilder();
		String line = br.readLine();
		while (line != null) {
			sb.append(line);
		    sb.append(System.lineSeparator());
		    line = br.readLine();
		}
		return sb.toString();
		
	}
	
	
	@SuppressWarnings("resource")
	public String getFileContentModifie(String filePath) throws FileNotFoundException, IOException{
		String replacer = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" 
				+ "<?import javafx.scene.Cursor?>"
				+ "<?import javafx.scene.Group?>"
				+ "<?import javafx.scene.control.Accordion?>\n"
				+ "<?import javafx.scene.control.Button?>\n"
				+ "<?import javafx.scene.control.ChoiceBox?>\n"
				+ "<?import javafx.scene.control.CheckBox?>\n"
				+ "<?import javafx.scene.control.DatePicker?>\n"
				+ "<?import javafx.scene.control.Label?>\n"
				+ "<?import javafx.scene.control.ScrollPane?>"
				+ "<?import javafx.scene.control.Menu?>\n"
				+ "<?import javafx.scene.control.MenuBar?>\n"
				+ "<?import javafx.scene.control.MenuItem?>\n"
				+ "<?import javafx.scene.control.Separator?>\n"
				+ "<?import javafx.scene.control.TextField?>\n"
				+ "<?import javafx.scene.control.TitledPane?>\n"
				+ "<?import javafx.scene.control.ToggleButton?>\n"
				+ "<?import javafx.scene.control.TextArea?>\n"
				+ "<?import javafx.scene.image.Image?>\n"
				+ "<?import javafx.scene.image.ImageView?>\n"
				+ "<?import javafx.scene.layout.AnchorPane?>\n"
				+ "<?import javafx.scene.layout.FlowPane?>\n"
				+ "<?import javafx.scene.layout.Pane?>\n"
				+ "<?import javafx.scene.control.SeparatorMenuItem?>\n"
				+ "<?import javafx.scene.text.Font?>"
				+ "<?import javafx.scene.control.TableColumn?>"
				+ "<?import javafx.scene.control.TableView?>"
				+ "<?import javafx.scene.control.ListView?>"
				+ "<?import javafx.scene.control.RadioButton?>"
				+ "<?import javafx.scene.control.ToggleButton?>"
				+ "<?import javafx.scene.control.ToggleGroup?>";
		
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		StringBuilder sb = new StringBuilder();
		String line = br.readLine();
		int lineCounter = 0;
		while (line != null) {
			if (lineCounter == 0)
			{
				line = line.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", replacer);
			}
			sb.append(line);
		    sb.append(System.lineSeparator());
		    line = br.readLine();
		}
		return sb.toString();
		
	}
}
