package application;

import java.util.ArrayList;
import java.util.List;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.StrokeLineCap;

public class InteractableLine {

	Pane pane; 
	TextField wc_p1_xCoord_TextField;
	TextField wc_p1_yCoord_TextField;
	TextField wc_p2_xCoord_TextField; 
	TextField wc_p2_yCoord_TextField;
	TextField wc_distance_TextField; 
	Button wc_save_Button;
	Button wc_hide_Button;
	Label wc_update_Label;
	
	//private List<Double> values;
	private Polygon line;
	private ArrayList<AnchorDrawShape> lineAnchors;
	
	InteractableLine itself;
	
	public ArrayList<DoubleProperty> xPropertyListener;
	ArrayList<DoubleProperty> yPropertyListener;
	double distance;
	
	GroupController gc;
	boolean isDistanceLine;
	
	public InteractableLine(Pane pane, TextField wc_p1_xCoord_TextField, 
			TextField wc_p1_yCoord_TextField, TextField wc_p2_xCoord_TextField, 
			TextField wc_p2_yCoord_TextField, TextField wc_distance_TextField, 
			Button wc_save_Button, Button wc_hide_Button, Label wc_update_Label,
			GroupController gc, boolean isDistanceLine){
		this.isDistanceLine = isDistanceLine;
		//this.values = new ArrayList<Double>();
		this.line = new Polygon();
		this.lineAnchors = new ArrayList<AnchorDrawShape>();
		this.itself = this;
		this.xPropertyListener = new ArrayList<DoubleProperty>();
		this.yPropertyListener = new ArrayList<DoubleProperty>();	
		this.pane = pane;

		this.wc_p1_xCoord_TextField = wc_p1_xCoord_TextField; 
		this.wc_p1_yCoord_TextField = wc_p1_yCoord_TextField;
		this.wc_p2_xCoord_TextField = wc_p2_xCoord_TextField;
		this.wc_p2_yCoord_TextField = wc_p2_yCoord_TextField;
		this.wc_distance_TextField = wc_distance_TextField;
		this.wc_save_Button = wc_save_Button;
		this.wc_hide_Button = wc_hide_Button;
		this.wc_update_Label = wc_update_Label;
		this.gc = gc;
		
		distance = 0;
		setSelectedStyle();
		
		line.setOnMouseClicked(new EventHandler<MouseEvent>(){
			@Override
			public void handle(MouseEvent event) {
				if (event.getButton() == MouseButton.SECONDARY) {
 		        	pane.getChildren().remove(line);
 		        	removeAnchorsFromPane();
 		        	itself.removeAnchorsFromAllAchors();
				}
 		        else if (event.getButton() == MouseButton.PRIMARY){}
		        	
			}
        });
		
		
		if (this.wc_save_Button != null)this.wc_save_Button.setOnAction(new EventHandler<ActionEvent>(){
	   			@Override
				public void handle(ActionEvent event) {
	   				saveButtonAction();
	   			}
    	});
	}
	
	public void saveButtonAction(){
		try{
				double newDistance = Double.parseDouble(wc_distance_TextField.getText());
				if (newDistance > 0) {
					distance = newDistance;
					wc_update_Label.setText("Distance Saved");
					wc_update_Label.setTextFill(Color.web("#008B00"));
				}	 		   				
				else{
					wc_update_Label.setText("Distance must be > 0");
					wc_update_Label.setTextFill(Color.web("#CD0000"));
				}
			}
			catch (Exception e)
			{
				wc_update_Label.setText("Distance must be a number");
				wc_update_Label.setTextFill(Color.web("#CD0000"));
			}
	}
	
	
	public void addValue(double value) {line.getPoints().add(value);}
	public Polygon getRoomShape (){return line;}
	public void addAnchor (AnchorDrawShape anchor) {lineAnchors.add(anchor);}
	
	public void removeAnchor (AnchorDrawShape anchor) {lineAnchors.remove(anchor); lineAnchors.remove(anchor);}
	public ArrayList<AnchorDrawShape> getAnchors () {return lineAnchors;}
	public ArrayList<DoubleProperty> get_Xcoord(){return this.xPropertyListener;}
	public ArrayList<DoubleProperty> get_Ycoord(){return this.yPropertyListener;}
	public InteractableLine getItself(){return this.itself;} 

	
	public void removeAnchorsFromPane(){for(int i = 0 ; i < lineAnchors.size(); ++i)pane.getChildren().remove(lineAnchors.get(i));}
	public void removeAnchorsFromAllAchors(){for(int i = 0 ; i < lineAnchors.size(); ++i)lineAnchors.remove(lineAnchors.get(i));}
	
	public void hide(){
		this.removeAnchorsFromPane();
		pane.getChildren().remove(line);
	}
	
	public void show(){
		for(int i = 0; i < lineAnchors.size(); i++){
			pane.getChildren().add(lineAnchors.get(i));
		}
		pane.getChildren().add(line);
	}
	
	
	public void removeItself()
	{
		//rooms.removeRoom(itself);
     	pane.getChildren().remove(line);
     	removeAnchorsFromPane();
     	itself.removeAnchorsFromAllAchors();
	}
	
	
	public AnchorDrawShape addAnchorCircle(){
		
		ObservableList<Double> currentPoints = line.getPoints();
		AnchorDrawShape newPoint = createControlAnchorsFor(currentPoints);
		lineAnchors.add(newPoint);
		 //allAnchors.add(newPoint);
		return newPoint;
	}
	
	public void updateDisplayedDistanceValue(){
		 if ((itself.xPropertyListener.size() == 2) && (itself.yPropertyListener.size() == 2)) {
			 distance = Math.sqrt(
					 Math.pow((itself.get_Xcoord().get(0).doubleValue() - itself.get_Xcoord().get(1).doubleValue()), 2) + 
					 Math.pow((itself.get_Ycoord().get(0).doubleValue() - itself.get_Ycoord().get(1).doubleValue()), 2));
			 gc.distanceLinePoints_Label.setText(distance + " points");
			 gc.distanceLinePoints_Label.setTextFill(Color.BLUE);
			 
			 if (gc.horizontalCalibrationLine == null){
				 gc.distanceLineMeter_Label.setText("Horizontal Calibration Line is not set");
			 }
			 else{
				 	ArrayList<DoubleProperty> xPoints = gc.horizontalCalibrationLine.get_Xcoord();
					Double distanceCalLine = gc.horizontalCalibrationLine.getDistance();
					
					double pointDiff = Math.abs(xPoints.get(1).doubleValue() - xPoints.get(0).doubleValue());
					
					// calculate the number of points in a meter
					double coefficient =  (distanceCalLine / pointDiff);// * 1000;
					
				 
				 gc.distanceLineMeter_Label.setText(Math.sqrt(
						 Math.pow((itself.get_Xcoord().get(0).doubleValue() - itself.get_Xcoord().get(1).doubleValue()), 2) + 
						 Math.pow((itself.get_Ycoord().get(0).doubleValue()  - itself.get_Ycoord().get(1).doubleValue()), 2)) 
						 * coefficient + " meters");
				 
			 }
			 gc.distanceLineMeter_Label.setTextFill(Color.BLUE);
		 }
	}
	
	private AnchorDrawShape createControlAnchorsFor(final ObservableList<Double> points) {
    	
    	int index = points.size() - 2;
    
    	DoubleProperty xProperty = new SimpleDoubleProperty(points.get(index));
        DoubleProperty yProperty = new SimpleDoubleProperty(points.get(index + 1));
        
        AnchorDrawShape a_out = null;;
        if (lineAnchors.size() == 0){
	        xProperty.addListener(new ChangeListener<Number>() {
	        	@Override
	            public void changed(ObservableValue<? extends Number> ov, Number oldX, Number x) {
	        		points.set(index, (double) x);
	        		double distance = 0;
	        		if (!isDistanceLine){
	        			wc_p1_xCoord_TextField.setText(x + "");
	        			wc_distance_TextField.setText(distance + "");
	        		}
	        		 else{
	        			 updateDisplayedDistanceValue();
	        		 }
	        	}
	         });
	
	         yProperty.addListener(new ChangeListener<Number>() {
	        	 @Override
	             public void changed(ObservableValue<? extends Number> ov, Number oldY, Number y) {
	        		 points.set(index + 1, (double) y);
	        		 double distance = 0;
	        		 if (!isDistanceLine){
	        			 wc_p1_yCoord_TextField.setText(y + "");
	        			 wc_distance_TextField.setText(distance + "");
	        		 }
	        		 else{
	        			 updateDisplayedDistanceValue();
	        		 }
	        	 }
	         });
	         
	         AnchorDrawShape a = new AnchorDrawShape(xProperty, yProperty, lineAnchors, gc.anchorSize);
	         //setSelected();
	         a.setOpacity(1);
	         
	         a.setOnMouseClicked(new EventHandler<MouseEvent>(){
	 			@Override
	 			public void handle(MouseEvent e) {
	 			//	setSelected();
	 				if (e.getButton() == MouseButton.PRIMARY){
	 					if (!isDistanceLine){
	 						wc_p1_xCoord_TextField.setText(points.get(index) + "");
	 	        			wc_p1_yCoord_TextField.setText(points.get(index + 1) + "");
	 					}
	 	         		a.setSelected();
	 				}
	 		        e.consume();
	 			}
	         });
	         
	         if (this.wc_save_Button != null) this.wc_save_Button.setOnMouseClicked(new EventHandler<MouseEvent>(){
	  			@Override
	  			public void handle(MouseEvent e) {
	  				if (e.getButton() == MouseButton.PRIMARY){
	  					
	  						double x_coord_new = Double.parseDouble(wc_p1_xCoord_TextField.getText());
	  						double y_coord_new = Double.parseDouble(wc_p1_yCoord_TextField.getText());
	  						
	  						a.setCenterX(x_coord_new);a.setCenterY(y_coord_new);

	  				}
	  		        e.consume();
	  			}
	          });
	         a_out = a;
	        
        }
        else //if (lineAnchors.size() == 1)
        {
	        xProperty.addListener(new ChangeListener<Number>() {
	        	@Override
	            public void changed(ObservableValue<? extends Number> ov, Number oldX, Number x) {
	        		
	        		points.set(index, (double) x);
	        		double distance = 0;
	        		if (!isDistanceLine){
	        			wc_p2_xCoord_TextField.setText(x + "");
	        			wc_distance_TextField.setText(distance + "");
	        		}
	        		 else{
	        			 updateDisplayedDistanceValue();
	        		 }
	        		
	        	}
	         });
	
	         yProperty.addListener(new ChangeListener<Number>() {
	        	 @Override
	             public void changed(ObservableValue<? extends Number> ov, Number oldY, Number y) {
	        		 points.set(index + 1, (double) y);
		        		double distance = 0;
		        		if (!isDistanceLine){
		        			wc_p2_yCoord_TextField.setText(y + "");
		        			wc_distance_TextField.setText(distance + "");
		        		}
		        		 else{
		        			 updateDisplayedDistanceValue();
		        		 }
	        	 }
	         });
	         
	         AnchorDrawShape a = new AnchorDrawShape(xProperty, yProperty, lineAnchors, gc.anchorSize);
	         //setSelected();
	         a.setOpacity(1);
	         
	         a.setOnMouseClicked(new EventHandler<MouseEvent>(){
	 			@Override
	 			public void handle(MouseEvent e) {
	 			//	setSelected();
	 				if (e.getButton() == MouseButton.PRIMARY){
	 					if (!isDistanceLine){
	 						wc_p2_xCoord_TextField.setText(points.get(index) + "");
	 						wc_p2_yCoord_TextField.setText(points.get(index + 1) + "");
	 					}
	 	        		a.setSelected();
	 				}
	 		        e.consume();
	 			}
	         });
	         
	         
	         // second click?
	         if (this.wc_save_Button != null) this.wc_save_Button.setOnMouseClicked(new EventHandler<MouseEvent>(){
	  			@Override
	  			public void handle(MouseEvent e) {
	  				if (e.getButton() == MouseButton.PRIMARY){
	  					double x_coord_new = Double.parseDouble(wc_p2_xCoord_TextField.getText());
	  					double y_coord_new = Double.parseDouble(wc_p2_yCoord_TextField.getText());
	  					
	  					a.setCenterX(x_coord_new);a.setCenterY(y_coord_new);

	  				}
	  		        e.consume();
	  			}
	          });
	         a_out = a;
	         
        }
         

        xPropertyListener.add(xProperty);
        yPropertyListener.add(yProperty);
        
        if (!isDistanceLine){

         if (yPropertyListener.size() == 1){
        	 gc.wc_horizontal_p1_xCoord_TextField.setText(xProperty.doubleValue() + "");
        	 gc.wc_horizontal_p1_yCoord_TextField.setText(yProperty.doubleValue() + "");
         }else if (yPropertyListener.size() == 2){
        	 gc.wc_horizontal_p2_xCoord_TextField.setText(xProperty.doubleValue() + "");
        	 gc.wc_horizontal_p2_yCoord_TextField.setText(yProperty.doubleValue() + "");
         }
         
        }
        else{
        	if (yPropertyListener.size() == 2){
        		updateDisplayedDistanceValue();
        	}
        }
       
       return a_out;
    }

	
	public double getDistance(){
		return this.distance;}
	
	public void setDistance (double newDistance){
		this.distance = newDistance;
	}
	
	
	public void setSelectedStyle(){
		line.setStroke(Color.DARKGREEN);
		line.setStrokeWidth(1);
		line.setStrokeLineCap(StrokeLineCap.ROUND);
		line.setFill(Color.AQUAMARINE.deriveColor(0, 1.2, 1, 0.6));
	}
	
	
	public double getPointDifference(){
		double pointDiff = Math.sqrt(
				 Math.pow((itself.get_Xcoord().get(0).doubleValue() - itself.get_Xcoord().get(1).doubleValue()), 2) + 
				 Math.pow((itself.get_Ycoord().get(0).doubleValue()  - itself.get_Ycoord().get(1).doubleValue()), 2)) ;
				
				return pointDiff;
	}
}
