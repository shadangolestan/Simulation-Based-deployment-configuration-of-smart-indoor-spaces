package application;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;


public class Agent {
	private final String AGENT_IMAGE_PATH_HOVER_OVER = "@../../image/person/agent_icon_ho.png";
	private final String AGENT_IMAGE_PATH = "@../../image/person/agent_icon.png";
	
	Agent itself;
	private ImageView imageView;
	private String agentID; 
	private String agentName; 
	private String agentType; 
	private double XCoord;
	private double YCoord;
	private GroupController gc;
	private boolean isValidAgent;
	
	
	public Agent(GroupController gc){
		this.gc = gc;
		this.itself = this;
		this.isValidAgent = false;
		
		this.isValidAgent = validateAndRecordAgent(true);
		if (isValidAgent)
		{
			try {
				File file = new File(AGENT_IMAGE_PATH);
				URL url = file.toURI().toURL();
				this.imageView = new ImageView(new Image(url.toExternalForm()));
				gc.getMainPane().getChildren().add(imageView);
				imageView.setLayoutX(XCoord);
				imageView.setLayoutY(YCoord);
				imageView.setFitHeight(30);
				imageView.setFitWidth(30);
				
			}
			catch (Exception e) {gc.a_agentID_TextField.setText("Image Not found");}

			setListeners();
		}
	} 

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void setListeners() {
		itself.imageView = imageView;
		
		this.imageView.setOnDragDetected(new EventHandler() {
        	@Override
			public void handle(Event event) {
        		itself.imageView.setId("agent_iconOld");
        		itself.gc.agents.setCurrentActiveAgent(itself);
        		itself.gc.sensorDrag(event);
			}
        });
		
		imageView.setOnMouseClicked(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				if (e.getButton() == MouseButton.SECONDARY) {
					gc.getMainPane().getChildren().remove(imageView);
					gc.agents.removeAgent(itself);

					gc.a_agentIDModified_TextField.setText("");
					gc.a_agentNameModified_TextField.setText("");
					gc.a_agentRoleModified_TextField.setText("");
					gc.a_XCoordModified_TextField.setText("");
					gc.a_YCoordModified_TextField.setText("");
				} else if (e.getButton() == MouseButton.PRIMARY) {
					gc.agents.setCurrentActiveAgent(itself);
					gc.a_agentIDModified_TextField.setText(itself.agentID);
					gc.a_agentNameModified_TextField.setText(itself.agentName);
					gc.a_agentRoleModified_TextField.setText(itself.agentType);
					gc.a_XCoordModified_TextField.setText(itself.XCoord + "");
					gc.a_YCoordModified_TextField.setText(itself.YCoord + "");
				}
				e.consume();
			}
		});
		imageView.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				try {
					File file = new File(AGENT_IMAGE_PATH_HOVER_OVER);
					URL url = file.toURI().toURL();
					itself.getImageView().setImage(new Image(url.toExternalForm()));
				} catch (MalformedURLException e1) {
					e1.printStackTrace();
				}
			}
		});

		imageView.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {

				try {
					File file = new File(AGENT_IMAGE_PATH);
					URL url = file.toURI().toURL();
					itself.getImageView().setImage(new Image(url.toExternalForm()));
				} catch (MalformedURLException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		
	}
	
	public boolean validateAndRecordAgent(boolean isNew){
		String agentID_temp = ""; 
		String agentName_temp = ""; 
		String agentType_temp = "";
		String XCoord_temp = "";
		String YCoord_temp = "";
		Label messageLabel = null;
		
		if (isNew){
			agentID_temp = gc.a_agentID_TextField.getText().trim();
			agentName_temp = gc.a_agentName_TextField.getText().trim();
			agentType_temp = gc.a_agentRole_TextField.getText().trim();
			XCoord_temp = gc.a_XCoord_TextField.getText().trim();
			YCoord_temp = gc.a_YCoord_TextField.getText().trim();
			messageLabel = gc.a_addAgent_Label;
		}
		else{
			agentID_temp = gc.a_agentIDModified_TextField.getText().trim();
			agentName_temp = gc.a_agentNameModified_TextField.getText().trim();
			agentType_temp = gc.a_agentRoleModified_TextField.getText().trim();
			XCoord_temp = gc.a_XCoordModified_TextField.getText().trim();
			YCoord_temp = gc.a_YCoordModified_TextField.getText().trim();
			messageLabel = gc.a_modifyAgent_Label;
		}
		
		if (agentID_temp.equals("") || agentID_temp == null){
			gc.setMessage(false, "Agent ID not enterred", messageLabel);
			return false;
		}
		
		if ((gc.agents.isIdInList(agentID_temp)) && itself.getAgentId() != null && (!itself.getAgentId().equals(agentID_temp))){
			gc.setMessage(false, "Agent ID already exits", messageLabel);
			return false;
		}
		
		if (agentName_temp.equals("") || agentName_temp == null){
			gc.setMessage(false, "Agent Name not enterred", messageLabel);return false;
		}
		
		if (agentType_temp.equals("") || agentType_temp == null){
			gc.setMessage(false, "Agent Type not enterred", messageLabel);return false;
		}
		
		if (XCoord_temp.equals("") || XCoord_temp == null){
			gc.setMessage(false, "X coordinate not enterred", messageLabel);return false;
		}
		
		double agentX_Coord = -1;
		try{agentX_Coord = Double.parseDouble(XCoord_temp);}
		catch (Exception e){gc.setMessage(false, "Coordinates must be numbers", messageLabel);return false;}
		
		if (YCoord_temp.equals("") || YCoord_temp == null){
			gc.setMessage(false, "Y coordinate not enterred", messageLabel);return false;
		}
		double agentY_Coord = -1;
		try{agentY_Coord = Double.parseDouble(YCoord_temp);}
		catch (Exception e){gc.setMessage(false, "Coordinates must be numbers",messageLabel);return false;}
		this.agentID = agentID_temp; 
		this.agentName = agentName_temp; 
		this.agentType = agentType_temp; 
		this.XCoord = agentX_Coord;
		this.YCoord = agentY_Coord;
		
		if (!isNew) updateImageViewCoord();
		String successMessage = "";
		
		if (isNew) successMessage = "Agent Added!";
		else successMessage = "Agent Modified!";
		
		gc.setMessage(true, successMessage, messageLabel);
		gc.agents.setCurrentActiveAgent(itself);
		return true;
	}
	
	
	public void setImageView(ImageView imageView)
	{
		this.imageView = imageView;
	}
	
	public ImageView getImageView(){return this.imageView;}

	public String getAgentId(){return this.agentID;}
	
	public void hide(){gc.pane.getChildren().remove(this.imageView);}
	public void show(){gc.pane.getChildren().add(this.imageView);}
	
	public Agent getItself(){return this.itself;}
	public String getAgentName(){return this.agentName;}
	public void setAgentName(String a){this.agentName = a;}
	public String getAgentType(){return this.agentType;}
	public void setAgentType(String a){this.agentType = a;}
	public boolean isValid(){return this.isValidAgent;}
	
	public void updateImageViewCoord(){
		imageView.setLayoutX(XCoord);
		imageView.setLayoutY(YCoord);
		imageView.setFitHeight(30);
		imageView.setFitWidth(30);
	}
	
	public void updateAgentCoordinates(){
		itself.XCoord = itself.imageView.getLayoutX();
		itself.YCoord = itself.imageView.getLayoutY();
	}
	
}
