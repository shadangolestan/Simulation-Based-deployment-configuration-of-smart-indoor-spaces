package application;

import geometry.Point;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import rooms.Room;

public class Door {

	public double x;
	public double y;
	public int edgeID;
	public String doorID;
	public String doorSize;
	private ImageView imageView;
	@SuppressWarnings("unused")
	private Room room;
	private Door itself;
	private GroupController gc;
	
	
	//public Door(int x, int y){this.x = x; this.y = y;}
	//public Door(int x, int y, int edgeID){this.x = x; this.y = y; this.edgeID = edgeID;}
	
	
	public Door(Point p, ImageView imageView, Room room, GroupController gc){
		this.gc = gc;
		this.x = p.x; this.y = p.y; this.edgeID = p.edgeID;
		this.imageView = imageView;
		this.room = room;
		this.itself = this;
		this.doorSize = "5";
		
		if (!gc.getMainPane().getChildren().contains(imageView)) gc.getMainPane().getChildren().add(imageView);
	
		setListeners(imageView);
	}
	
	
	
	public Door() {this.x = -1; this.y = -1; this.edgeID = -1;}
	public void setX (int x){this.x = x;}
	public void setY (int y){this.y = y;}
	public void setEdeID (int id){this.edgeID = id;}
	public double getX(){return this.x;}
	public double getY(){return this.y;}
	public int getEdgeID(){return this.edgeID;}
	public void setDoorID(String doorID){this.doorID = doorID;}
	public String getDoorID (){return this.doorID;}
	public String getDoorSize() {return this.doorSize;}
	public void setDoorSize(String doorSiez){this.doorSize = doorSize;}
	//public void setDoorSize(String doorSiez){this.doorSize = doorSize;}
	
	
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void setListeners(ImageView imageView){
		this.imageView = imageView;
		
		this.imageView.setOnDragDetected(new EventHandler() {
        	@Override
			public void handle(Event event) {
        		itself.imageView.setId("simpleDoorImageViewOld");
        		itself.gc.doors.setCurrentActiveDoor(itself);
        		itself.gc.sensorDrag(event);
			}
        });
		
        
		this.imageView.setOnMouseClicked(new EventHandler<MouseEvent>(){
 			@Override
 			public void handle(MouseEvent e) {
 				if (e.getButton() == MouseButton.SECONDARY){
 					itself.gc.getMainPane().getChildren().remove(imageView);
 					gc.doors.getDoors().remove(itself);
 				}
 				else if (e.getButton() == MouseButton.PRIMARY){
 					itself.gc.currentDoorID.setText(doorID);
 					itself.gc.currentDoor_Xcoord_textField.setText("" + x);
 					itself.gc.currentDoor_Ycoord_textField.setText("" + y);
 					itself.gc.currentDoorSize.setText(doorSize);
 					
 					itself.gc.saveDoorIdButton.setOnAction(new EventHandler<ActionEvent>(){
	 		   			@Override
	 					public void handle(ActionEvent event) {
	 		   				String newID = itself.gc.currentDoorID.getText();
	 		   				String newDoorSize = itself.gc.currentDoorSize.getText();
	 		   				 
	 		   				if ((!itself.gc.doors.isIdInList(newID)) || ((itself.gc.doors.isIdInList(newID) && newID.equals(itself.getDoorID())))
	 		   						&& (newDoorSize != null) && (!newDoorSize.equals(""))) {
	 		   					doorID = newID; 
	 		   					doorSize = newDoorSize;
	 		   					itself.gc.setMessage(true, "Door saved", itself.gc.doorPanelMessageLabel);
	 		   				}	 		   				
	 		   				else{
	 		   					itself.gc.setMessage(false, "Door already Exists", itself.gc.doorPanelMessageLabel);
	 		   				}
	 		   			}
		        	});	
 				}
 		        e.consume();
 			}
         });
	}
	
	
	public void hide(){
		this.gc.pane.getChildren().remove(imageView);
	}
	
	public void show(){
		this.gc.pane.getChildren().add(imageView);
	}
}
