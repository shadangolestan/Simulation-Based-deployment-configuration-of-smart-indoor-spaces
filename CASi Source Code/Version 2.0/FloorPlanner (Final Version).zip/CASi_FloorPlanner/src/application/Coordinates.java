package application;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;


public class Coordinates {
	private Double posX, posY;
	private Label posX_Label, posY_Label;
	private TextField posX_TextField, posY_TextField;
	
	public Coordinates(){}
	
	public Coordinates(Double posX, Double posY){
		this.posX = posX; this.posY = posY;
	}

	public void setX(Double posX){this.posX = posX;}
	public void setY(Double posY){this.posY = posY;}
	
	public Double getPosX(){return this.posX;}
	public Double getPosY(){return this.posY;}
	

	public void setX_TextField(TextField posX_textField){this.posX_TextField = posX_TextField;}
	public void setY_TextField(TextField posY_textField){this.posY_TextField = posY_TextField;}
	

	public TextField getTextFieldX(){return this.posX_TextField;}
	public TextField getTextFieldY(){return this.posY_TextField;}
	
	
}
